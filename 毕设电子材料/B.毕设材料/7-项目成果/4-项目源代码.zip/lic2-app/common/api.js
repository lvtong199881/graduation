var host = "http://39.101.179.30:3000/mock/17/app"; //mock地址
var host1 = "https://lic2.luckyzune.com/app"; //实际地址

var conFig = {
	host,
	host1,
	login: `${host1}/mine/login`, //登录
	uploadPicture: `https://lic2.luckyzune.com/oss/photo`, //图片上传接口
	getNewVersion: `${host1}/mine/getNewVersion`, //获取新版本

	getStudentInfo: `${host1}/mine/getStudentInfo`, //获取学生信息
	getCountryList: `${host1}/mine/getCountryList`, //获取国家或地区列表
	getLanguageList: `${host1}/mine/getLanguageList`, //获取语言列表
	changeName: `${host1}/mine/changeName`, //修改姓名
	changePhone: `${host1}/mine/changePhone`, //修改手机号
	changeCountry: `${host1}/mine/changeCountry`, //修改国家或地区
	changeLanguage: `${host1}/mine/changeLanguage`, //修改语言
	changeHobbies: `${host1}/mine/changeHobbies`, //修改兴趣爱好
	getHobbyList: `${host1}/mine/getHobbyList`, //获取兴趣爱好列表
	changePassword: `${host1}/mine/changePassword`, //修改密码
	changePicture: `${host1}/mine/changePicture`, //修改头像
	getAnalysisData: `${host1}/mine/getAnalysisData`, //获取学生分析数据
	getVocabulary: `${host1}/mine/getVocabulary`, //获取测试字词

	getCourseList: `${host1}/home/getCourseList`, //获取课程列表
	getMineDoneTopic: `${host1}/mine/getMineDoneTopic`, //获取我做过的题目
	getMineDoneTest: `${host1}/mine/getMineDoneTest`, //获取我做过的试卷
	getCollectTopic: `${host1}/mine/getCollectTopic`, //获取收藏的题目
	getCollectTest: `${host1}/mine/getCollectTest`, //获取收藏的试卷
	getWrongBookTopic: `${host1}/mine/getWrongBookTopic`, //获取错题本中的题目

	getRecommendTopic: `${host1}/find/getRecommendTopic`, //获取推荐题目
	getSearchTopic: `${host1}/find/onlySearch`, //获取搜索出题题目
	getRandomTopic: `${host1}/find/getRandomTopic`, //获取随机出题题目
	getKPFirstList: `${host1}/find/getKPFirstList`, //获取知识点一级分类列表
	getKPSecondList: `${host1}/find/getKPSecondList`, //获取知识点二级分类列表
	getKPThirdList: `${host1}/find/getKPThirdList`, //获取知识点三级分类列表
	getKPTopicList: `${host1}/find/getKPTopicList`, //获取知识点关联的题目列表


	getCourseActivityList: `${host1}/home/getCourseActivityList`, //获取课程活动列表
	getCourseMaterialList: `${host1}/home/getCourseMaterialList`, //获取课程资料列表
	getVocabularySortList: `${host}/home/getVocabularySortList`, //获取课程字词分类列表
	getVocabularyList: `${host}/home/getVocabularyList`, //获取课程字词列表
	getVocabularyDetail: `${host1}/home/getVocabularyDetail`, //获取课程字词详情
	getTopicDetail: `${host1}/common/getTopicDetail`, //获取题目详情
	submitTopicAnswer: `${host1}/common/submitTopicAnswer`, //提交题目答案

	getTestDetail: `${host1}/common/getTestDetail`, //获取试卷详情
	getTestData: `${host1}/common/getTestData`, //获取考试试卷数据
	submitTestAnswer: `${host1}/common/submitTestAnswer`, //提交试卷答案
	completeTest: `${host1}/common/completeTest`, //完成试卷
	// getTestTopicDetail:`${host1}/common/getTestTopicDetail`,//获取试卷中的题目详情
	
	collect:`${host1}/common/collect`, //收藏题目或试卷
	unCollect:`${host1}/common/uncollect`, //取消收藏题目或试卷
	updataLearnTime:`${host1}/common/updataLearnTime`, //更新学习时间
}

module.exports = conFig;
