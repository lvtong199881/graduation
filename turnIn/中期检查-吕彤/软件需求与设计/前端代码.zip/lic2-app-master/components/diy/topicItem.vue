<template>
	<view class="uni-flex uni-column">
		<view class="uni-flex uni-row topicInfo">
			<view style="display: flex; align-items: center;">
				<image class="icon" v-bind:src="topicUrl" mode="aspectFill"></image>
			</view>
			<view class="uni-flex uni-column" style="flex: 1;margin-left: 20rpx;">
				<text class="topic_para" style="font-size: 24rpx;">题目：{{ topicName }}</text>
				<text class="topic_para" style="font-size: 24rpx;">知识点：{{ topicKnowledgePoint }}</text>
				<text class="topic_para" style="font-size: 24rpx;">关键词：{{ topicKeyWord }}</text>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
	export default {
		name: 'topicItem',
		data() {
			return {
			}
		},
		props: {
			topicUrl: {
				type: String,
				default: '../../static/ic_topic.png'
			},
			topicName: {
				type: String,
				default: '暂无数据'
			},
			topicKnowledgePoint: {
				type: String,
				default: '暂无数据'
			},
			topicKeyWord: {
				type: String,
				default: '暂无数据'
			},
			showDivider:{
				type:Boolean,
				default:true
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.topicInfo {
	padding: 20rpx;
	background-color: #ffffff;
}
.icon{
	width: 80rpx;
	height: 80rpx;
}
.topic_para{
	flex: 1;
	flex-wrap: wrap;
}
</style>
