<template>
	<view class="uni-flex uni-column">
		<view class="uni-flex uni-row materialInfo">
			<view style="display: flex; align-items: center;"><image class="icon" v-bind:src="materialUrl" mode="aspectFill"></image></view>
			<view class="uni-flex uni-column" style="flex: 1;margin-left: 20rpx;">
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
					<text class="text">{{ materialName }}</text>
					<text class="text">{{ materialTime }}</text>
				</view>
				<text class="text">{{ materialDesc }}</text>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	name: 'materialItem',
	data() {
		return {};
	},
	props: {
		materialUrl: {
			type: String,
			default: '/static/ic_material.png'
		},
		materialName: {
			type: String,
			default: '暂无数据'
		},
		materialTime: {
			type: String,
			default: '暂无数据'
		},
		materialDesc: {
			type: String,
			default: '暂无数据'
		},
		showDivider: {
			type: Boolean,
			default: true
		}
	},
	methods: {}
};
</script>

<style>
.materialInfo {
	padding: 20rpx;
	background-color: #ffffff;
}
.icon {
	width: 80rpx;
	height: 80rpx;
}
.text {
}
</style>
