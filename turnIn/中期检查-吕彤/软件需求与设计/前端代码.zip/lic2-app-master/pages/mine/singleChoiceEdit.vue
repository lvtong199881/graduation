<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view slot="right" @click="submit()">提交</view>
		</NavBar>
		<view class="uni-list">
			<radio-group @change="radioChange">
				<label class="uni-list-cell uni-list-cell-pd" v-for="(item, index) in singleList" :key="item.id">
					<view><radio :value="item.id" :checked="index === current" /></view>
					<view>{{ item.name }}</view>
				</label>
			</radio-group>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import ApiManager from '../../common/api.js';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '',
			placeholder: ',',
			inputValue: '',
			current: 0,
			singleList: [],
			pageInfo: {
				pageId: 1,
				pageName: ''
			}
		};
	},
	onLoad: function(e) {
		this.pageInfo.pageId = e.pageId;
		this.pageInfo.pageName = e.pageName;
		this.title = '选择' + e.pageName;
		if (e.pageId == 3) {
			//获取国家和地区列表
			uni.request({
				url: ApiManager.getCountryList,
				method: 'GET',
				data: {},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					var countryList = content.countryList;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.singleList = countryList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
		} else if (e.pageId == 4) {
			//获取语言
			uni.request({
				url: ApiManager.getLanguageList,
				method: 'GET',
				data: {},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					var languageList = content.languageList;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.singleList = languageList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		radioChange(evt) {
			for (let i = 0; i < this.singleList.length; i++) {
				if (this.singleList[i].id === evt.target.value) {
					this.current = i;
					break;
				}
			}
		},
		submit() {
			if (this.pageInfo.pageId == 3) {
				uni.showLoading({
					title: '提交中',
					mask: false
				});
				uni.request({
					url: ApiManager.changeCountry,
					method: 'POST',
					data: {
						studentNumber: getApp().globalData.studentInfo.studentNumber,
						countryId: this.singleList[this.current].id,
						countryName: this.singleList[this.current].name
					},
					success: res => {
						var errorCode = res.data.errorCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '提交成功',
								icon: 'none'
							});
							uni.navigateBack({
								delta: 1
							});
						}
					},
					fail: () => {},
					complete: () => {
						uni.hideLoading();
					}
				});
			} else if (this.pageInfo.pageId == 4) {
				uni.showLoading({
					title: '提交中',
					mask: false
				});
				uni.request({
					url: ApiManager.changeLanguage,
					method: 'POST',
					data: {
						studentNumber: getApp().globalData.studentInfo.studentNumber,
						languageId: this.singleList[this.current].id,
						languageName: this.singleList[this.current].name
					},
					success: res => {
						var errorCode = res.data.errorCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '提交成功',
								icon: 'none'
							});
							uni.navigateBack({
								delta: 1
							});
						}
					},
					fail: () => {},
					complete: () => {
						uni.hideLoading();
					}
				});
			}
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
</style>
