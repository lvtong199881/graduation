<template>
	<view class="uni-flex uni-row" style="padding: 20rpx;">
		<canvas
			:canvas-id="canvasId"
			class="canvas"
			disable-scroll="false"
			@touchmove="touchMove"
			@touchstart="touchStart($event)"
			@touchend="touchEnd"
			@touchcancel="touchCancel"
			@longtap="tap"
			@error="error"
		></canvas>
		<view class="uni-flex uni-column" style="-webkit-flex: 1;flex: 1;">
			<button class="button" @tap="save">保存</button>
			<button class="button" @tap="clear">清空</button>
		</view>
	</view>
</template>

<script>
var content = null;
var touchs = [];
var canvasw = 0;
var canvash = 0;
//获取系统信息
uni.getSystemInfo({
	success: function(res) {
		//data - 各种参数
		canvasw = res.windowWidth;
		canvash = res.windowHeight;
	}
});
export default {
	name: 'writingArea',
	props: {
		visible: {
			type: Boolean,
			default: false
		},
		canvasId: {
			type: String,
			default: 'firstCanvas'
		}
	},
	data() {
		return {
			show: false,
			visibleSync: false,
			signImage: '',
			hasDh: false
		};
	},
	created(options) {
		this.visibleSync = this.visible;
		this.getInfo();
		setTimeout(() => {
			this.show = this.visible;
		}, 100);
	},
	methods: {
		getInfo() {
			//获得Canvas的上下文
			content = uni.createCanvasContext(this.canvasId, this);
			//设置线的颜色
			content.setStrokeStyle('#000');
			//设置线的宽度
			content.setLineWidth(5);
			//设置线两端端点样式更加圆润
			content.setLineCap('round');
			//设置两条线连接处更加圆润
			content.setLineJoin('round');
		},
		// 画布的触摸移动开始手势响应
		touchStart(e) {
			let point = {
				x: e.touches[0].x,
				y: e.touches[0].y
			};
			touchs.push(point);
			this.hasDh = true;
		},
		// 画布的触摸移动手势响应
		touchMove: function(e) {
			let point = {
				x: e.touches[0].x,
				y: e.touches[0].y
			};
			touchs.push(point);
			if (touchs.length >= 2) {
				this.draw(touchs);
			}
		},
		// 画布的触摸移动结束手势响应
		touchEnd: function(e) {
			//清空轨迹数组
			for (let i = 0; i < touchs.length; i++) {
				touchs.pop();
			}
		},
		// 画布的触摸取消响应
		touchCancel: function(e) {
			// console.log("触摸取消" + e)
		},
		error: function(e) {
			// console.log("画布触摸错误" + e)
		},
		//绘制
		draw: function(touchs) {
			let point1 = touchs[0];
			let point2 = touchs[1];
			// console.log(JSON.stringify(touchs))
			content.moveTo(point1.x, point1.y);
			content.lineTo(point2.x, point2.y);
			content.stroke();
			content.draw(true);
			touchs.shift();
		},
		//清除操作
		clear: function() {
			//清除画布
			content.clearRect(0, 0, canvasw, canvash);
			content.draw(true);
			// this.close()
			this.hasDh = false;
			this.$emit('clear');
		},
		save() {
			uni.showToast({
				title: '保存',
				icon: 'none'
			});
		}
	}
};
</script>

<style>
.button {
	font-size: 28rpx;
	margin: auto;
	background-color: #dd4037;
	color: #ffffff;
}
.canvas {
	width: 500rpx;
	height: 500rpx;
	background-image: url(../../static/田字格.png);
	background-size: 100% 100%;
	background-color: #fff;
}
</style>
