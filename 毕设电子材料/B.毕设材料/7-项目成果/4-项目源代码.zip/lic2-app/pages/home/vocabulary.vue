<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<picker @change="bindPickerChange" :value="index" :range="VbSortList" range-key="name">
			<view class="uni-flex uni-row picker_part">
				<text class="picker_view">{{ VbSortList[index].name }}</text>
				<uniIcons type="arrowdown" color="#666666" size="24"></uniIcons>
			</view>
		</picker>

		<view class="uni-list">
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in VbList" :key="index" @tap="openVbInfo" :data-id="item.id" :data-name="item.name">
				<view class="uni-flex uni-row">
					<view style="margin: 20rpx;">{{ item.name }}</view>
					<view style="margin: 20rpx;">{{ item.pinyin }}</view>
					<view style="margin: 20rpx;">{{ item.english }}</view>
				</view>
				<view class="common-divider-line"></view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '字词',
			VbSortList: [{ id: -1, name: '暂无数据' }],
			VbList: [],
			index: 0,
			courseId: -1
		};
	},
	onLoad: function(e) {
		var that=this;
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		this.courseId = e.courseId;
		console.log(this.courseId);
		//获取字词分类
		uni.request({
			url: ApiManager.getVocabularySortList,
			method: 'POST',
			data: {
				courseId: parseInt(that.courseId)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.hideLoading();
						this.VbSortList = content;
						this.requestList();
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},

	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		requestList() {
			var that =this;
			uni.request({
				url: ApiManager.getVocabularyList,
				method: 'POST',
				data: {
					courseId: parseInt(that.courseId),
					sortId: parseInt(that.VbSortList[that.index].id)
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '加载成功',
								mask: true
							});
							that.VbList = content;
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		bindPickerChange: function(e) {
			console.log('picker发送选择改变，携带值为：' + e.target.value);
			that.index = e.target.value;
			that.requestList();
		},
		openVbInfo: function(e) {
			uni.navigateTo({
				url: './vocabularyDetail?id=' + e.currentTarget.dataset.id,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.picker_part {
	justify-content: center;
	background-color: #ffffff;
	align-items: center;
}
</style>
