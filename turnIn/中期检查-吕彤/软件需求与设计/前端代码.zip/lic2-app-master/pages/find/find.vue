<template>
	<view class="common-content uni-column">
		<view class="status_bar"><!-- 这里是状态栏 --></view>
		<!--带课程选择的导航栏-->
		<view class="uni-flex" style="height: 44px; background-color: #DD4037;">
			<view style="background-color: #DD4037;padding-left: 20rpx;">
				<picker @change="bindPickerChange" :value="lessonArray[index].courseId" :range="lessonArray" range-key="courseName">
					<text class="picker_view">{{ lessonArray[index].courseName }}</text>
					<uniIcons type="arrowdown" color="#ffffff" size="24"></uniIcons>
				</picker>
			</view>
			<view style="display: flex; flex: 1; align-items: center;background: #DD4037;text-align: center;justify-content: center;">
				<text style="color: #FFFFFF;font-size: 32rpx;padding-right: 150rpx;">{{ title }}</text>
			</view>
		</view>
		<!-- 四大子功能-->
		<view class="uni-flex uni-row" style="background-color: #FFFFFF;">
			<!-- 搜索出题-->
			<view class="uni-flex uni-column sub_class" @click="gotoSearch()">
				<image v-bind:src="subFeaturesArray[0].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[0].text }}</text>
			</view>
			<!-- 知识点出题-->
			<view class="uni-flex uni-column sub_class" @click="gotoKnowledgePointSearch()">
				<image v-bind:src="subFeaturesArray[1].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[1].text }}</text>
			</view>
			<!-- 随机出题-->
			<view class="uni-flex uni-column sub_class" @click="gotoRandom()">
				<image v-bind:src="subFeaturesArray[2].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[2].text }}</text>
			</view>
			<!-- 智能组卷-->
			<view class="uni-flex uni-column sub_class" @click="gotoAiTest()">
				<image v-bind:src="subFeaturesArray[3].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[3].text }}</text>
			</view>
		</view>
		<!--推荐题目-->
		<view class="uni-flex uni-column">
			<text class="recommend_label">推荐</text>
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in recommendArray" :key="index" @tap="openinfo" :data-newsid="item.topicId">
				<topicItem topicUrl="../../static/ic_topic.png" :topicName="item.topicName" :topicKnowledgePoint="item.knowledgePoint" :topicKeyWord="item.keyWord"></topicItem>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import topicItem from '../../components/diy/topicItem.vue';

export default {
	components: {
		uniIcons,
		topicItem
	},
	data() {
		return {
			title: '发现',
			index: 0,
			lessonArray: [],
			subFeaturesArray: [
				{
					id: 1,
					text: '搜索出题',
					iconRes: '../../static/find_search.png'
				},
				{
					id: 2,
					text: '知识点出题',
					iconRes: '../../static/find_knowledge_point.png'
				},
				{
					id: 3,
					text: '随机出题',
					iconRes: '../../static/find_random_search.png'
				},
				{
					id: 4,
					text: '智能组卷',
					iconRes: '../../static/find_ai_test.png'
				}
			],
			recommendArray: []
		};
	},
	onLoad() {
		uni.request({
			url: ApiManager.getCourseList,
			method: 'POST',
			data: {
				studentNumber:getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.lessonArray = content.courseList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.request({
			url: ApiManager.getRecommendTopic,
			method: 'POST',
			data: {
				studentNumber:getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.recommendArray = content.topicList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		bindPickerChange: function(e) {
			console.log('picker发送选择改变，携带值为：' + e.target.value);
			this.index = e.target.value;
		},
		gotoSearch() {
			uni.navigateTo({
				url: './onlySearch?currentLessonIndex='+this.index,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoKnowledgePointSearch() {
			uni.navigateTo({
				url: './kPointSortOne',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoRandom() {
			uni.navigateTo({
				url: './randomSearch?currentLessonIndex='+this.index,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoAiTest() {
			uni.navigateTo({
				url: './aiTest?currentLessonIndex='+this.index,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openinfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.sub_class {
	justify-content: center;
	align-items: center;
	flex: 1;
	width: 100%;
	margin: 0rpx 0rpx;
	padding: 0rpx 20rpx;
	padding-bottom: 20rpx;
	text-align: center;
	font-size: 26rpx;
}
.sub_image_class {
	width: 80rpx;
	height: 80rpx;
	padding: 20rpx;
}
.recommend_label {
	margin: 10rpx;
}
.picker_view {
	color: #ffffff;
}
</style>
