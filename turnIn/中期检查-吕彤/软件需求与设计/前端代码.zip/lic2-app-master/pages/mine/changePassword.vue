<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="修改密码" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>

		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<input style="margin-bottom: 20rpx;" password placeholder="输入旧密码" class="uni-input" v-model="password.oldPassword" @input="onKeyOldPswdInput" />
			<input style="margin-bottom: 20rpx;" password placeholder="输入新密码" class="uni-input" v-model="password.newPassword" @input="onKeyNewPswdInput" />
			<input style="margin-bottom: 20rpx;" password placeholder="确认新密码" class="uni-input" v-model="password.newPasswordAgain" @input="onKeynewPswdAgainInput" />
			<button class="button_determine" @click="tryChangePassword()">确定修改</button>
		</view>
	</view>
</template>

<script>
		import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			password: {
				oldPassword: '',
				newPassword: '',
				newPasswordAgain: ''
			}
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onKeyOldPswdInput: function(event) {
			this.oldPassword = event.target.value;
		},
		onKeyNewPswdInput: function(event) {
			this.newPassword = event.target.value;
		},
		onKeynewPswdAgainInput: function(event) {
			this.newPasswordAgain = event.target.value;
		},
		tryChangePassword() {
			if (this.password.oldPassword == '') {
				uni.showModal({
					title: '修改失败',
					content: '旧密码不能为空',
					showCancel: false
				});
			} else if (this.password.newPassword == '') {
				uni.showModal({
					title: '修改失败',
					content: '新密码不能为空',
					showCancel: false
				});
			} else if (this.password.newPasswordAgain == '') {
				uni.showModal({
					title: '修改失败',
					content: '确认新密码不能为空',
					showCancel: false
				});
			} else if (this.password.newPasswordAgain != this.password.newPassword) {
				uni.showModal({
					title: '修改失败',
					content: '新密码输入不一致',
					showCancel: false
				});
			}else{
				uni.request({
					url: ApiManager.changePassword,
					method: 'POST',
					data: {
						studentNumber:getApp().globalData.studentInfo.studentNumber,
						oldPassword:this.oldPassword,
						newPassword:this.newPassword
					},
					success: res => {
						var errorCode = res.data.errorCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else{
						uni.showToast({
							title: "修改成功",
							icon: 'none'
						});
						uni.navigateBack({
							delta: 1
						});
						}
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.button_determine {
	width: 100%;
	font-size: 28rpx;
	color: #ffffff;
	background-color: #dd4037;
}
</style>
