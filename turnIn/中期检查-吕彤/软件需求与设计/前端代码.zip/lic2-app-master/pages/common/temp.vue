<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-column topic_info_part">
			<view class="uni-flex uni-row">
				<text style="width: 100%;font-size: 40rpx;">书面表达,作文</text>
				<view style="width: 100%;text-align: end;color: #DD4037">00:59:59</view>
			</view>
			<text>题目：29</text>
			<text>词语：母亲节、礼物、裙子</text>
						<image style="width: 600rpx;height: 600rpx;background-color: #FFFFFF;" src="../../static/1.png" mode="widthFix"></image>
			<image style="width: 600rpx;height: 600rpx;background-color: #FFFFFF;margin-top: 20rpx;" mode="widthFix"></image>
		</view>
			<button style="	background-color: #ffffff;color: #dd4037;margin: 10rpx;" @click="show()">上传答案</button>
		<view class="uni-flex uni-row">
			<button class="topic_navigation_class">上一题</button>
			<button class="topic_navigation_class">29/29</button>
			<button class="topic_navigation_class">上一题</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: ''
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		show(){
			uni.showModal({
				title: '提示',
				content: '您确定要交卷吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '交卷',
				confirmColor:"#DD4037",
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.topic_info_part {
	padding: 20rpx;
}
.topic_navigation_class {
	flex: 1;
	margin: 10rpx;
	background-color: #ffffff;
	color: #dd4037;
}
</style>
