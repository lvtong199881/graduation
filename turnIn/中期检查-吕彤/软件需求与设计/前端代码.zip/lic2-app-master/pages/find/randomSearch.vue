<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<uniIcons slot="right" type="reload" color="#ffffff" size="24" @click="refresh()"></uniIcons>
		</NavBar>
		<view style="margin-top: 20rpx;"></view>
		<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topciId">
			<topicItem topicUrl="../../static/ic_topic.png" :topicName="item.topicName" :topicKnowledgePoint="item.knowledgePoint" :topicKeyWord="item.keyWord"></topicItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import topicItem from '../../components/diy/topicItem.vue';
export default {
	components: {
		NavBar,
		uniIcons,
		topicItem
	},
	data() {
		return {
			title: '随机出题',
			topicList: []
		};
	},
	onLoad: function(e) {
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getRecommendTopic,
			method: 'POST',
			data: {
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.topicList = content.topicList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		openTopicInfo(e) {
			uni.showToast({
				title: e.currentTarget.dataset.newsid,
				icon: 'none'
			});
		},
		refresh() {
			uni.showLoading({
				title: '加载中...',
				mask: false
			});
			uni.request({
				url: ApiManager.getRecommendTopic,
				method: 'POST',
				data: {
					studentNumber: getApp().globalData.studentInfo.studentNumber
				},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.topicList = content.topicList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
			uni.hideLoading();
		}
	}
};
</script>

<style></style>
