<template>
	<view class="login_class" :style="{ height: screenHeight + 'px' }">
		<view class="uni-flex uni-column inputPart">
			<image style="width: 100%;" src="../../static/login_logo_03.png" mode="aspectFit"></image>
			<view class="uni-flex uni-column common-card" style="margin-bottom: 40rpx;">
				<text style="color: #666666;font-size: 30rpx;">学号</text>
				<input type="number" placeholder="请输入账号" placeholder-class="input_placeholder" v-model="userName" class="input" @input="onKeyUserNameInput" />
				<text style="color: #666666;font-size: 30rpx;">密码</text>
				<view class="uni-flex uni-row" style="display: flex; align-items: center;">
					<input
						:password="hidePassword"
						placeholder="请输入密码"
						placeholder-class="input_placeholder"
						class="input"
						v-model="password"
						@input="onKeyUserPasswordInput"
					/>
					<image :src="showIconUrl" class="class_switch_password" @click="switchPassword"></image>
				</view>
			</view>
			<button class="button_login" @click="goToLogin()">登录</button>
			<view class="uni-flex info">
				本系统是根据留学生的教学大纲和教学模式开发的智能教学辅助系统，实现包括学生信息管理、自主学习、课程考试等功能，学习数据与学生关联，故需要登录使用。
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		formItem
	},
	data() {
		return {
			userName: '',
			password: '',
			hidePassword: true,
			showIconUrl: '../../static/ic_view_off.png',
			screenHeight: 1920
		};
	},
	onLoad: function(e) {
		var that = this;
		//获取屏幕高度
		uni.getSystemInfo({
			success: res => {
				this.screenHeight = res.screenHeight;
				console.log('页面高度=' + this.screenHeight);
			}
		});
		//页面加载完成，获取本地存储的学号及密码
		const studentNumber = uni.getStorageSync('studentNumber');
		const studentPassword = uni.getStorageSync('studentPassword');
		if (studentNumber && studentPassword) {
			that.userName = studentNumber;
			that.password = studentPassword;
			// console.log(that.userName+that.password);
		} else {
			that.userName = '';
			that.password = '';
		}
	},
	methods: {
		onKeyUserNameInput: function(event) {
			var value = event.target.value;
			setTimeout(() => {
				this.userName = value.replace(/\s+/g, '');
			}, 10);
		},
		onKeyUserPasswordInput: function(event) {
			var value = event.target.value;
			setTimeout(() => {
				this.password = value.replace(/\s+/g, '');
			}, 10);
		},
		switchPassword() {
			this.hidePassword = !this.hidePassword;
			this.showIconUrl = this.hidePassword ? '../../static/ic_view_off.png' : '../../static/ic_view.png';
		},
		goToLogin() {
			if (this.userName == '') {
				uni.showToast({
					title: '请输入用户名',
					icon: 'none'
				});
			} else if (this.password == '') {
				uni.showToast({
					title: '请输入密码',
					icon: 'none'
				});
			} else {
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				uni.request({
					url: ApiManager.login,
					method: 'POST',
					data: {
						studentNumber: parseInt(this.userName),
						studentPassword: this.password
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + ':' + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								getApp().globalData.studentInfo.studentNumber = this.userName;
								uni.showToast({
									title: '登录成功',
									mask: true
								});
								uni.setStorageSync('studentNumber', this.userName);
								uni.setStorageSync('studentPassword', this.password);
								setTimeout(function() {
									uni.reLaunch({
										url: '../mine/mine',
										fail: () => {
											uni.showToast({
												title: '跳转失败',
												icon: 'none'
											});
										}
									});
								}, 1000);
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '登录失败',
							icon: 'none'
						});
					},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.button_login {
	width: 100%;
	font-size: 36rpx;
	color: #ffffff;
	background-color: #dd4037;
}
.info {
	/* background-color: rgba(248, 248, 248, 0.6); */
	color: #ffffff;
	padding: 20rpx;
	border-radius: 10rpx;
	margin-top: 20rpx;
}
.input_placeholder {
	color: #000000;
	font-size: 32rpx;
}
.input {
	padding: 20rpx;
	font-size: 32rpx;
	background: #fff;
	flex: 1;
}
.class_switch_password {
	width: 52rpx;
	height: 52rpx;
}
.login_class {
	height: auto;
	/* #ifdef H5||MP-WEIXIN*/
	background-image: url('https://licres.luckyzune.com/photo/1TQOTIFW4QI.jpg');
	/*#endif*/
	/*#ifdef APP-PLUS*/
	background-image: url(../../static/bg_login.png);
	/*#endif*/
	background-size: 100% 100%;
	background-repeat: no-repeat;
	background-origin: content-box;
	font-family: 'siyuanStyle';
}
.inputPart {
	padding: 20rpx;
}
</style>
