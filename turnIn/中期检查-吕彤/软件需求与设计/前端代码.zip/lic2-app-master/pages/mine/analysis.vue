<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="qiun-bg-white qiun-title-bar"><view class="qiun-title-dot-light">正确率</view></view>
		<view class="qiun-charts">
			<!--#ifdef MP-ALIPAY -->
			<canvas
				canvas-id="canvasPie"
				id="canvasPie"
				class="charts"
				:width="cWidth * pixelRatio"
				:height="cHeight * pixelRatio"
				:style="{ width: cWidth + 'px', height: cHeight + 'px' }"
				@touchstart="touchPie($event, 'canvasPie')"
			></canvas>
			<!--#endif-->
			<!--#ifndef MP-ALIPAY -->
			<canvas canvas-id="canvasPie" id="canvasPie" class="charts" @touchstart="touchPie($event, 'canvasPie')"></canvas>
			<!--#endif-->
		</view>
		<view class="qiun-bg-white qiun-title-bar"><view class="qiun-title-dot-light">最近学习情况</view></view>
		<view class="qiun-charts" style="background-color: #FFFFFF;">
			<!--#ifdef MP-ALIPAY -->
			<canvas
				canvas-id="canvasColumn"
				id="canvasColumn"
				class="charts"
				:width="cWidth * pixelRatio"
				:height="cHeight * pixelRatio"
				:style="{ width: cWidth + 'px', height: cHeight + 'px' }"
				@touchstart="touchIt($event, 'canvasColumn')"
			></canvas>
			<!--#endif-->
			<!--#ifndef MP-ALIPAY -->
			<canvas canvas-id="canvasColumn" id="canvasColumn" class="charts" @touchstart="touchIt($event, 'canvasColumn')"></canvas>
			<!--#endif-->
		</view>
		<!--条形图-->
	</view>
</template>

<script>
import uCharts from '../../components/u-charts/u-charts.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import ApiManager from '../../common/api.js';
var _self;
var canvasObj = {};
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '学生分析',
			cWidth: '',
			cHeight: '',
			tips: '',
			pixelRatio: 1,
			serverData: '',
			itemCount: 30, //x轴单屏数据密度
			sliderMax: 50
		};
	},
	onLoad() {
		_self = this;
		//#ifdef MP-ALIPAY
		uni.getSystemInfo({
			success: function(res) {
				if (res.pixelRatio > 1) {
					//正常这里给2就行，如果pixelRatio=3性能会降低一点
					//_self.pixelRatio =res.pixelRatio;
					_self.pixelRatio = 2;
				}
			}
		});
		//#endif
		this.cWidth = uni.upx2px(750);
		this.cHeight = uni.upx2px(500);
		this.cWidth2 = uni.upx2px(700);
		this.cHeight2 = uni.upx2px(1100);
		this.cWidth3 = uni.upx2px(250);
		this.cHeight3 = uni.upx2px(250);
		this.arcbarWidth = uni.upx2px(24);
		this.gaugeWidth = uni.upx2px(30);

		//this.fillData(Data);
	},
	onReady() {
		this.getServerData();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		getServerData() {
			uni.showLoading({
				title: '正在加载数据...'
			});
			uni.request({
				url: ApiManager.getAnalysisData,
				method: 'GET',
				data: {
					studentNumber: getApp().globalData.studentInfo.studentNumber
				},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.fillData(content);
					}
				},
				fail: () => {},
				complete: () => {
					uni.hideLoading();
				}
			});
			var data = {
				Pie: {
					series: [{ name: '正确', data: 50 }, { name: '错误', data: 30 }]
				},
				Column: {
					categories: ['12.01', '12.02', '12.03', '12.04', '12.05', '12.06', '12.07'],
					series: [
						{
							name: '题数',
							data: [15, 20, 45, 50, 43, 34, 25]
						}
					]
				}
			};
		},
		fillData(data) {
			this.serverData = data;
			let Pie = {
				series: []
			};
			let Column = {
				categories: [],
				series: []
			};

			Pie.series = data.Pie.series;
			Column.categories = data.Column.categories;
			Column.series = data.Column.series;
			this.showPie('canvasPie', Pie);
			this.showColumn('canvasColumn', Column);
		},
		showPie(canvasId, chartData) {
			canvasObj[canvasId] = new uCharts({
				$this: _self,
				canvasId: canvasId,
				type: 'pie',
				fontSize: 11,
				padding: [15, 15, 0, 15],
				legend: {
					show: true,
					padding: 5,
					lineHeight: 11,
					margin: 0
				},
				background: '#FFFFFF',
				pixelRatio: _self.pixelRatio,
				series: chartData.series,
				animation: false,
				width: _self.cWidth * _self.pixelRatio,
				height: _self.cHeight * _self.pixelRatio,
				dataLabel: true,
				extra: {
					pie: {
						lableWidth: 15
					}
				}
			});
		},
		touchPie(e, id) {
			canvasObj[id].showToolTip(e, {
				format: function(item) {
					return item.name + ':' + item.data;
				}
			});
		},
		showColumn(canvasId, chartData) {
			canvasObj[canvasId] = new uCharts({
				$this: _self,
				canvasId: canvasId,
				type: 'column',
				padding: [15, 15, 0, 15],
				legend: {
					show: true,
					padding: 5,
					lineHeight: 11,
					margin: 0
				},
				fontSize: 11,
				background: '#FFFFFF',
				pixelRatio: _self.pixelRatio,
				animation: false,
				categories: chartData.categories,
				series: chartData.series,
				xAxis: {
					disableGrid: true
				},
				yAxis: {
					format: val => {
						return val.toFixed(0);
					}
				},
				dataLabel: true,
				width: _self.cWidth * _self.pixelRatio,
				height: _self.cHeight * _self.pixelRatio,
				extra: {
					column: {
						type: 'group',
						width: (_self.cWidth * _self.pixelRatio * 0.45) / chartData.categories.length
					}
				}
			});
		},
		touchIt(e, id) {
			canvasObj[id].touchLegend(e, {
				animation: false
			});
			canvasObj[id].showToolTip(e, {
				format: function(item, category) {
					if (typeof item.data === 'object') {
						return category + ' ' + item.name + ':' + item.data.value;
					} else {
						return category + ' ' + item.name + ':' + item.data;
					}
				}
			});
		}
	}
};
</script>

<style>
.qiun-columns {
	display: flex;
	flex-direction: column !important;
}

.qiun-bg-white {
	background: #ffffff;
}

.qiun-title-bar {
	width: 96%;
	margin-top: 20rpx;
	flex-wrap: nowrap;
}

.qiun-title-dot-light {
	border-left: 10upx solid #0ea391;
	padding-left: 10upx;
	font-size: 32upx;
	color: #000000;
}

/* 通用样式 */
.qiun-charts {
	width: 750upx;
	height: 500upx;
	background-color: #ffffff;
}

.charts {
	width: 750upx;
	height: 500upx;
	background-color: #ffffff;
}
</style>
