<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<!--成绩部分-->
		<view class="grade_part">
			<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
				<text>作答时间:{{ durtion }}分钟</text>
				<text>满分:{{ totalScore }}分</text>
			</view>
			<view v-if="showGrade" class="grade_text_class">{{ grade }}分</view>
			<view class="common-divider-line"></view>
		</view>
		<!--试卷内容-->
		<view class="test_content">
			<view class="uni-flex uni-column test_part" v-for="(item, index) in partList" :key="index">
				<view class="uni-flex uni-column">
					<view class="uni-flex uni-row">
						<text>{{ item.partName }}</text>
						<text style="padding-left: 20rpx;">{{ item.topicNumber }}题</text>
						<text style="padding-left: 20rpx;">总分:{{ item.partTotalScore }}</text>
					</view>
					<view v-for="(item, index) in item.subPartList" :key="index">
						<view style="padding-left: 20rpx;">
							<view class="uni-flex uni-row">
								<text style="flex:1">{{ item.subPartName }}</text>
								<text style="flex:1">{{ item.subTopicNumber }}题</text>
								<text style="flex:1">总分:{{ item.subPartTotalScore }}</text>
								<text v-if="showGrade" style="flex:1">得分:{{ item.subGrade }}</text>
							</view>
						</view>
					</view>
				</view>
				<view class="common-divider-line"></view>
			</view>
		</view>
		<button class="start_test_button" @click="gotoStartTest()">{{ button_text }}</button>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '试卷详情',
			testId: -1,
			button_text: '开始做题',
			durtion: '60',
			totalScore: '100',
			grade: '70',
			showGrade: false,
			partList: []
		};
	},
	onLoad: function(e) {
		this.testId = e.testId;
		uni.request({
			url: ApiManager.getTestDetail,
			method: 'POST',
			data: {
				testId: e.testId,
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.durtion = content.durtion;
					this.totalScore = content.totalScore;
					this.grade = content.grade;
					this.showGrade = content.showGrade;
					this.partList = content.partList;
					if(this.showGrade){
						this.button_text = "查看答案"
					}else{
						this.button_text = "开始做题"
					}
				}
			},
			fail: () => {},
			complete: () => {}
		});
		// this.partList = [
		// 	{
		// 		partName: '听力理解',
		// 		topicNumber: 16,
		// 		partTotalScore: 32,
		// 		subPartList: [
		// 			{
		// 				subPartName: '听句子',
		// 				subPartTotalScore: 4,
		// 				subTopicNumber: 2,
		// 				subGrade: 4
		// 			},
		// 			{
		// 				subPartName: '听短对话',
		// 				subPartTotalScore: 4,
		// 				subTopicNumber: 2,
		// 				subGrade: 4
		// 			},
		// 			{
		// 				subPartName: '听长对话',
		// 				subPartTotalScore: 12,
		// 				subTopicNumber: 6,
		// 				subGrade: 12
		// 			},
		// 			{
		// 				subPartName: '听讲话',
		// 				subPartTotalScore: 12,
		// 				subTopicNumber: 6,
		// 				subGrade: 10
		// 			}
		// 		]
		// 	},
		// 	{
		// 		partName: '综合阅读',
		// 		topicNumber: 17,
		// 		partTotalScore: 38,
		// 		subPartList: [
		// 			{
		// 				subPartName: '理解词语',
		// 				subPartTotalScore: 10,
		// 				subTopicNumber: 5,
		// 				subGrade: 10
		// 			},
		// 			{
		// 				subPartName: '完成句子',
		// 				subPartTotalScore: 10,
		// 				subTopicNumber: 5,
		// 				subGrade: 10
		// 			},
		// 			{
		// 				subPartName: '理解段落',
		// 				subPartTotalScore: 8,
		// 				subTopicNumber: 4,
		// 				subGrade: 8
		// 			},
		// 			{
		// 				subPartName: '理解短文',
		// 				subPartTotalScore: 10,
		// 				subTopicNumber: 3,
		// 				subGrade: 10
		// 			}
		// 		]
		// 	},
		// 	{
		// 		partName: '书面表达',
		// 		topicNumber: 3,
		// 		partTotalScore: 30,
		// 		subPartList: [
		// 			{
		// 				subPartName: '写汉字',
		// 				subPartTotalScore: 10,
		// 				subTopicNumber: 2,
		// 				subGrade: 0
		// 			},
		// 			{
		// 				subPartName: '作文',
		// 				subPartTotalScore: 20,
		// 				subTopicNumber: 1,
		// 				subGrade: 0
		// 			}
		// 		]
		// 	}
		// ];
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		gotoStartTest() {
			uni.showModal({
				title: '提示',
				content: '确定要开始考试吗？',
				showCancel: true,
				cancelText: '取消',
				cancelColor: '#999999',
				confirmText: '确定',
				confirmColor: '#DD4037',
				success: res => {
					uni.navigateTo({
						url: './testTopicDetail',
						success: res => {},
						fail: () => {},
						complete: () => {}
					});
				},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.grade_part {
	padding: 20rpx;
}
.grade_text_class {
	width: 100%;
	text-align: center;
	color: #dd4037;
	font-size: 56rpx;
	padding: 20rpx;
}
.test_content {
	padding: 20rpx;
}
.start_test_button {
	background-color: #dd4037;
	border-radius: 20rpx;
	margin: 20rpx;
	color: #ffffff;
}
.test_part {
	padding-bottom: 20rpx;
}
</style>
