<script>
import Util from './common/util.js';
export default {
	onLaunch: function() {
		console.log('App Launch');
		//#ifdef APP-PLUS
		Util.checkUpdate();
		//#endif
	},
	onShow: function() {
		console.log('App Show');
	},
	onHide: function() {
		console.log('App Hide');
	},
	globalData: {
		kpSortIndex: {
			firstIndex: '-1',
			secondIndex: '-1',
			thirdIndex: '-1'
		},
		studentInfo: {
			studentNumber: ''
		}
	}
};
</script>

<style>
/*字体:思源黑体*/
@import './common/siyuanFont.css';
/*每个页面公共css*/
@import './common/uni.css';
</style>
