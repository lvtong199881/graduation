<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="收藏" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-row">
			<button v-if="current == 0" class="viewPage_checked" @click="getTopicList()">题目</button>
			<button v-else class="viewPage" @click="getTopicList()">题目</button>
			<button v-if="current == 1" class="viewPage_checked" @click="getPaperList()">考试</button>
			<button v-else class="viewPage" @click="getPaperList()">考试</button>
		</view>
		<swiper :style="{ height: swiperHeight + 'px' }" class="swiper" circular="true" :current="current" duration="300" @change="onswiperchange">
			<swiper-item item-id="0" style="margin-top: 20rpx;">
				<view class="topic_list_class">
					<view v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topicId">
						<topicItem topicUrl="../../static/ic_topic.png" :topicName="item.topicName" :topicKnowledgePoint="item.knowledgePoint"></topicItem>
					</view>
				</view>
			</swiper-item>

			<swiper-item item-id="1" style="margin-top: 20rpx;">
				<view class="paper_list_class">
					<view v-for="(item, index) in paperList" :key="index" @tap="openPaperInfo" :data-newsid="item.testId">
						<paperItem paperUrl="../../static/ic_paper.png" :paperName="item.testName" :paperTime="item.date"></paperItem>
					</view>
				</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import paperItem from '../../components/diy/paperItem.vue';
export default {
	components: {
		topicItem,
		NavBar,
		paperItem
	},
	data() {
		return {
			topicList: [],
			paperList: [],
			current: 1,
			swiperHeight: 0 //外部的高度
		};
	},
	onLoad: function() {
		uni.showLoading({
			title: '加载中....'
		});
		uni.request({
			url: ApiManager.getCollectTopic,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功'
						});
						this.topicList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
		uni.request({
			url: ApiManager.getCollectTest,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
			},
			success: res => {
				var errorCode = res.data.errCode;
				var errorMsg = res.data.errMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					uni.showToast({
						title: '加载成功'
					});
					this.paperList = content;
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	onShow: function() {
		this.current = 0;
	},
	watch: {
		topicList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.topic_list_class');
			});
		},
		paperList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.paper_list_class');
			});
		}
	},
	methods: {
		initSwiperHeight(list) {
			let _this = this;
			let info = uni.createSelectorQuery().select(list);
			info.boundingClientRect(function(data) {
				if (_this.swiperHeight < data.height + 50) {
					_this.swiperHeight = data.height + 50;
				}
			}).exec();
		},
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onswiperchange(e) {
			this.current = e.detail.current;
			if (this.current == 0) {
				this.initSwiperHeight('.topic_list_class');
			} else {
				this.initSwiperHeight('.paper_list_class');
			}
		},
		openTopicInfo(e) {
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + e.currentTarget.dataset.newsid,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openPaperInfo(e) {
			uni.navigateTo({
				url: '../common/testDetail?testId=' + e.currentTarget.dataset.newsid,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		getTopicList() {
			//请求接口:获取收藏的题目列表
			this.current = 0;
		},
		getPaperList() {
			//请求接口:获取收藏的试卷列表
			this.current = 1;
		}
	}
};
</script>

<style>
.viewPage {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
}
.viewPage_checked {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
	font-weight: bold;
}
.swiper {
	display: flex;
}
</style>
