<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="修改密码" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>

		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<input style="margin-bottom: 20rpx;" password placeholder="输入旧密码" class="input_class" v-model="password.oldPassword" @input="onKeyOldPswdInput" />
			<input style="margin-bottom: 20rpx;" password placeholder="输入新密码" class="input_class" v-model="password.newPassword" @input="onKeyNewPswdInput" />
			<input style="margin-bottom: 20rpx;" password placeholder="确认新密码" class="input_class" v-model="password.newPasswordAgain" @input="onKeynewPswdAgainInput" />
			<button class="button_determine" @click="tryChangePassword()">确定修改</button>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			password: {
				oldPassword: '',
				newPassword: '',
				newPasswordAgain: ''
			}
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onKeyOldPswdInput: function(event) {
			this.oldPassword = event.target.value;
		},
		onKeyNewPswdInput: function(event) {
			this.newPassword = event.target.value;
		},
		onKeynewPswdAgainInput: function(event) {
			this.newPasswordAgain = event.target.value;
		},
		tryChangePassword() {
			if (this.password.oldPassword == '') {
				uni.showToast({
					title: '旧密码不能为空',
					icon: 'none'
				});
			} else if (this.password.newPassword == '') {
				uni.showToast({
					title: '新密码不能为空',
					icon: 'none'
				});
			} else if (this.password.newPasswordAgain == '') {
				uni.showToast({
					title: '确认新密码不能为空',
					icon: 'none'
				});
			} else if (this.password.newPasswordAgain != this.password.newPassword) {
				uni.showToast({
					title: '新密码两次输入不一致',
					icon: 'none'
				});
			} else {
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				uni.request({
					url: ApiManager.changePassword,
					method: 'POST',
					data: {
						studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
						oldPassword: this.oldPassword,
						newPassword: this.newPassword
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + ':' + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '修改成功',
									icon: 'none'
								});
								setTimeout(function() {
									uni.navigateBack({
										delta: 1
									});
								}, 1000);
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '修改失败',
							icon: 'none'
						});
					},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.input_class {
	height: auto;
	padding: 20rpx;
	line-height: 50rpx;
	font-size: large;
	background: #fff;
	border-radius: 10rpx;
	flex: 1;
}
.button_determine {
	width: 100%;
	font-size: 28rpx;
	color: #ffffff;
	padding: 10rpx;
	background-color: #dd4037;
}
</style>
