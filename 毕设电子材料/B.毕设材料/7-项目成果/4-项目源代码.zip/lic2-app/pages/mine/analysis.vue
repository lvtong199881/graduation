<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" title="学生分析" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="qiun-title-dot-light">做题正确率</view>
		<view class="qiun-charts">
			<!--#ifdef MP-ALIPAY -->
			<canvas
				canvas-id="canvasPie"
				id="canvasPie"
				class="charts"
				:width="cWidth * pixelRatio"
				:height="cHeight * pixelRatio"
				:style="{ width: cWidth + 'px', height: cHeight + 'px' }"
				@touchstart="touchPie($event, 'canvasPie')"
			></canvas>
			<!--#endif-->
			<!--#ifndef MP-ALIPAY -->
			<canvas canvas-id="canvasPie" id="canvasPie" class="charts" @touchstart="touchPie($event, 'canvasPie')"></canvas>
			<!--#endif-->
		</view>
		<view class="qiun-title-dot-light">近七日做题情况</view>
		<view class="qiun-charts">
			<!--#ifdef MP-ALIPAY -->
			<canvas
				canvas-id="canvasColumn"
				id="canvasColumn"
				class="charts"
				:width="cWidth * pixelRatio"
				:height="cHeight * pixelRatio"
				:style="{ width: cWidth + 'px', height: cHeight + 'px' }"
				@touchstart="touchIt($event, 'canvasColumn')"
			></canvas>
			<!--#endif-->
			<!--#ifndef MP-ALIPAY -->
			<canvas canvas-id="canvasColumn" id="canvasColumn" class="charts" @touchstart="touchIt($event, 'canvasColumn')"></canvas>
			<!--#endif-->
		</view>
	</view>
</template>

<script>
import uCharts from '../../components/u-charts/u-charts.js';
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
var that = this;
var canvasObj = {};

export default {
	components: {
		NavBar
	},
	data() {
		return {
			cWidth: '',
			cHeight: '',
			pixelRatio: 1,
			serverData: {
				pie: {
					series: [
						{
							name: '正确',
							data: 0
						},
						{
							name: '错误',
							data: 0
						}
					]
				},
				column: {
					categories: new Array(),
					series: [
						{
							name: '题数',
							data: new Array()
						}
					]
				}
			},
			itemCount: 30, //x轴单屏数据密度
			sliderMax: 50
		};
	},
	onLoad() {
		that = this;
		//#ifdef MP-ALIPAY
		uni.getSystemInfo({
			success: function(res) {
				if (res.pixelRatio > 1) {
					//正常这里给2就行，如果pixelRatio=3性能会降低一点
					//that.pixelRatio =res.pixelRatio;
					that.pixelRatio = 2;
				}
			}
		});
		//#endif
		this.cWidth = uni.upx2px(750);
		this.cHeight = uni.upx2px(500);
		this.initData();
	},
	onReady() {
		this.getServerData();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		initData() {
			var that = this;
			var date = new Date();
			for (var i = 7; i > 0; i--) {
				//当前日期
				var tempDate = new Date(date);
				tempDate.setDate(tempDate.getDate() - i);
				//当前日期格式化为月日
				var tempCategories = tempDate.getMonth() + 1 + '月' + tempDate.getDate() + '日';
				//categories赋值
				that.serverData.column.categories.push(tempCategories);
				that.serverData.column.series[0].data.push(0);
			}
			console.log(that.serverData);
		},
		getServerData() {
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			uni.request({
				url: ApiManager.getAnalysisData,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '加载成功'
							});
							if (content != null && content != '') {
								for (var i = 0; i < that.serverData.pie.series.length; i++) {
									that.serverData.pie.series[i].data = content.pie[i];
								}
								for (var i = 0; i < that.serverData.column.series[0].data.length; i++) {
									that.serverData.column.series[0].data[i] = content.column[i];
								}
							}
							that.fillData(that.serverData);
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		fillData(data) {
			let Column = {
				categories: [],
				series: []
			};
			let Pie = {
				series: []
			};
			Column.categories = this.serverData.column.categories;
			Column.series = this.serverData.column.series;
			Pie.series = this.serverData.pie.series;
			this.showColumn('canvasColumn', Column);
			this.showPie('canvasPie', Pie);
		},
		showColumn(canvasId, chartData) {
			canvasObj[canvasId] = new uCharts({
				$this: that,
				canvasId: canvasId,
				type: 'column',
				padding: [15, 15, 0, 15],
				legend: {
					show: true,
					padding: 5,
					lineHeight: 11,
					margin: 0
				},
				fontSize: 11,
				background: '#FFFFFF',
				pixelRatio: that.pixelRatio,
				animation: false,
				categories: chartData.categories,
				series: chartData.series,
				xAxis: {
					disableGrid: true
				},
				yAxis: {
					format: val => {
						return val.toFixed(0);
					}
				},
				dataLabel: true,
				width: that.cWidth * that.pixelRatio,
				height: that.cHeight * that.pixelRatio,
				extra: {
					column: {
						type: 'group',
						width: (that.cWidth * that.pixelRatio * 0.45) / chartData.categories.length
					}
				}
			});
		},
		showPie(canvasId, chartData) {
			canvasObj[canvasId] = new uCharts({
				$this: that,
				canvasId: canvasId,
				type: 'pie',
				fontSize: 11,
				padding: [15, 15, 0, 15],
				legend: {
					show: true,
					padding: 5,
					lineHeight: 11,
					margin: 0
				},
				background: '#FFFFFF',
				pixelRatio: that.pixelRatio,
				series: chartData.series,
				animation: false,
				width: that.cWidth * that.pixelRatio,
				height: that.cHeight * that.pixelRatio,
				dataLabel: true,
				extra: {
					pie: {
						lableWidth: 15
					}
				}
			});
		},
		touchIt(e, id) {
			canvasObj[id].touchLegend(e, {
				animation: false
			});
			canvasObj[id].showToolTip(e, {
				format: function(item, category) {
					if (typeof item.data === 'object') {
						return category + ' ' + item.name + ':' + item.data.value;
					} else {
						return category + ' ' + item.name + ':' + item.data;
					}
				}
			});
		},
		touchPie(e, id) {
			canvasObj[id].showToolTip(e, {
				format: function(item) {
					return item.name + ':' + item.data;
				}
			});
		}
	}
};
</script>

<style>
.qiun-title-dot-light {
	border-left: 10upx solid #0ea391;
	padding-left: 10upx;
	font-size: 32upx;
	color: #000000;
}

/* 通用样式 */
.qiun-charts {
	width: 750upx;
	height: 500upx;
	background-color: #ffffff;
}

.charts {
	width: 750upx;
	height: 500upx;
	background-color: #ffffff;
}
</style>
