<template>
	<!--知识点出题题目列表-->
	<view class="common-content">
		<NavBar :title="title" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view slot="left">
				<uniIcons style="margin-right: 20rpx;" type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
				<uniIcons type="home" color="#ffffff" size="24" @click="home()"></uniIcons>
			</view>
		</NavBar>
		<view style="margin-top: 20rpx;" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topicId">
			<topicItem
				:topicId="item.topicId"
				:topicName="item.topicName"
				:topicKnowledgePoint="item.knowledgePoint"
				showCollect
				@collect="tryCollect(index)"
				@uncollect="tryUnCollect(index)"
			></topicItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		topicItem,
		uniIcons
	},
	data() {
		return {
			title: '关联题目列表',
			topicList: []
		};
	},
	onLoad: function() {
		var firstId = getApp().globalData.kpSortIndex.firstIndex;
		var secondId = getApp().globalData.kpSortIndex.secondIndex;
		var thirdId = getApp().globalData.kpSortIndex.thirdIndex;
		uni.showLoading({
			title: '加载中....'
		});
		uni.request({
			url: ApiManager.getKPTopicList,
			method: 'POST',
			data: {
				firstIndex: firstId,
				secondIndex: secondId,
				thirdIndex: thirdId
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功'
						});
						this.topicList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		home() {
			getApp().globalData.kpSortIndex.firstIndex = '';
			getApp().globalData.kpSortIndex.secondIndex = '';
			getApp().globalData.kpSortIndex.thirdIndex = '';
			uni.switchTab({
				url: './find',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openTopicInfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
</style>
