<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<uniIcons slot="right" type="list" color="#ffffff" size="24" @click="show()"></uniIcons>
		</NavBar>
		<Drawer :visible="showDrawer" mode="right"></Drawer>

		<!--题目内容-->
		<view style="padding: 20rpx;background-color: #FFFFFF;">
			<view class="uni-flex uni-column topic_info_part">
				<!-- <view style="width: 100%;text-align: end;">00:59:59</view> -->
				<!-- 	<text>当前题目ID：{{ topicInfo.topicId }}</text> -->
				<view class="uni-flex uni-row">
					<text style="width: 100%;font-size: 40rpx;">综合阅读,理解短文</text>
					<view style="width: 100%;text-align: end;color: #DD4037">00:59:59</view>
				</view>
				<text>题目：{{ topicInfo.topicId }}</text>
				<text>{{ topicInfo.topicDesc }}</text>
			</view>
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.question" :key="index" @tap="openinfo" :data-newsid="item.questionId">
				<view class="question">
					<view class="uni-flex uni-row" style="align-items: center;">
						<view>问题{{ index + 1 }}.{{ item.questionDesc }}</view>
<!-- 						<uniIcons type="sound" size="24"></uniIcons> -->
					</view>

					<checkbox-group @change="checkboxChange">
						<label class="uni-list-cell uni-list-cell-pd" v-for="item in item.optionList" :key="item.value">
							<view><checkbox :value="item.value" :checked="item.checked" /></view>
							<view>{{ item.name }}</view>
						</label>
					</checkbox-group>
				</view>
			</view>
		</view>
		<view class="uni-flex uni-row">
			<button class="topic_navigation_class">上一题</button>
			<button class="topic_navigation_class">{{topicInfo.topicId}}/29</button>
			<button class="topic_navigation_class">上一题</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import Drawer from '../../components/uni-drawer/uni-drawer.vue';
export default {
	components: {
		NavBar,
		uniIcons,
		Drawer
	},
	data() {
		return {
			showDrawer:false,
			title: '试卷详情',
			showAnswer: true,
			topicInfo: {
				topicId: 23,
				topicName: '',
				topicDesc: '4条地铁新线于12月28日正式开通运营，全长63公里，设车站48座，其中换乘站10座。今年新线开通与往年不同，具有线路多、里程长、换乘站多，集中在城市中心区等特点。新线开通后，不仅地铁交通路网密度进一步提升，而且在换乘站对路面交通也会产生一定的影响。',
				topicType: 1,
				topicTypeString: '',
				topicDifficultType: '中等',
				topicUrl: [],
				question: [
					{
						questionId: 1,
						questionDesc: '新开通的地铁线有什么特点？',
						questionAudioUrl: '',
						optionList: [
							{
								value: 'A',
								name: '线路短'
							},
							{
								value: 'B',
								name: '价格高'
							},
							{
								value: 'C',
								name: '多数在市区'
							},
							{
								value: 'D',
								name: '运行时间长'
							}
						]
					},
					{
						questionId: 2,
						questionDesc: '新开通了几条地铁线？',
						questionAudioUrl: '',
						optionList: [
							{
								value: 'A',
								name: '4条'
							},
							{
								value: 'B',
								name: '10条'
							},
							{
								value: 'C',
								name: '48条'
							},
							{
								value: 'D',
								name: '63条'
							}
						]
					},
					{
						questionId: 3,
						questionDesc: '新开通的地铁线对什么有影响？',
						questionAudioUrl: '',
						optionList: [
							{
								value: 'A',
								name: '航班'
							},
							{
								value: 'B',
								name: '空气'
							},
							{
								value: 'C',
								name: '加油站'
							},
							{
								value: 'D',
								name: '路面交通'
							}
						]
					}
				]
			}
		};
	},
	methods: {
		back() {
			uni.showModal({
				title: '提示',
				content: '退出将丢失所有答题信息，确定退出吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '退出',
				confirmColor: '#DD4037',
				success: res => {
					uni.navigateBack({
						delta: 1
					});
				},
				fail: () => {},
				complete: () => {}
			});
		},
		show(){
			this.showDrawer = true
		},
		showAnswerSheet() {
			uni.showToast({
				title: '展开答题卡',
				icon: 'none'
			});
		},
		checkboxChange: function(e) {
			var items = this.items,
				values = e.detail.value;
			for (var i = 0, lenI = items.length; i < lenI; ++i) {
				const item = items[i];
				if (values.includes(item.value)) {
					this.$set(item, 'checked', true);
				} else {
					this.$set(item, 'checked', false);
				}
			}
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
.topic_info_part {
	background-color: #ffffff;
}
.question {
	background-color: #ffffff;
	margin-top: 20rpx;
}
.topic_navigation_class{
	flex: 1;
	margin: 10rpx;
	background-color: #FFFFFF;
	color: #DD4037;
}
</style>
