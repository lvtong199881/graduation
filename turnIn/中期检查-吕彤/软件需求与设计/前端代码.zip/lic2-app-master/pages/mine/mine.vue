<template>
	<view class="common-content ">
		<view class="status_bar"><!-- 这里是状态栏 --></view>

		<view class="uni-flex uni-row personalInfo" @click="gotoPersonalInfo()">
			<image class="student_avatar" v-bind:src="studentInfo.avatarIcon" mode="aspectFill"></image>
			<view class="uni-flex uni-column student_simple_info">
				<text class="stuedent_name_and_num">{{ studentInfo.name }} {{ studentInfo.number }}</text>
				<text class="stuedent_class_name">{{ studentInfo.className }}</text>
			</view>
			<view style="display: flex; align-items: center;">
				<image class="student_analysis" v-bind:src="analysisIcon" mode="aspectFill" @click.native.stop="gotoAnalysis()"></image>
			</view>
		</view>
		<view class="common-divider-line"></view>
		<view style="margin-top: 20rpx;">
			<formItem showIcon="true" labelText="我做过的" labelIconRes="../../static/mine_question_done.png" showClick="true" @click.native="gotoQuestionDone()"></formItem>
			<formItem showIcon="true" labelText="收藏" labelIconRes="../../static/mine_collection.png" showClick="true" @click.native="gotoCollection()"></formItem>
			<formItem showIcon="true" labelText="错题本" labelIconRes="../../static/mine_wrong_book.png" showClick="true" @click.native="gotoWrongBook()"></formItem>
			<formItem showIcon="true" labelText="识字量在线测试" labelIconRes="../../static/mine_word_test.png" showClick="true" @click.native="gotoWordTest()"></formItem>
			<view style="margin-top: 20rpx;">
				<formItem showIcon="true" labelText="设置" labelIconRes="../../static/mine_settings.png" showClick="true" @click.native="gotoSettings()"></formItem>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		formItem
	},
	data() {
		return {
			analysisIcon: '../../static/student_analysis.png',
			studentInfo: {
				avatarIcon: '../../static/student_avatar.png',
				name: '暂无数据',
				number: '暂无数据',
				className: '暂无数据'
			}
		};
	},
	onLoad: function(e) {
		this.studentInfo.studentNumber = getApp().globalData.studentInfo.studentNumber;
		uni.showToast({
			title: this.studentInfo.studentNumber,
			icon: 'none'
		});
		//请求接口获取用户基本信息
		uni.request({
			url: ApiManager.getStudentInfo,
			method: 'POST',
			data: {
				studentNumber: this.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				var studentInfo = content.studentInfo;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.studentInfo.number = studentInfo.number;
					this.studentInfo.avatarIcon = studentInfo.avatar;
					this.studentInfo.name = studentInfo.name;
					this.studentInfo.className = studentInfo.className;
				}
			},
			fail: () => {},
			complete: () => {}
		});
	},
	methods: {
		gotoAnalysis() {
			//跳转到学生分析页
			uni.navigateTo({
				url: './analysis',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoPersonalInfo() {
			//跳转到个人信息页
			uni.navigateTo({
				url: './personalInfo',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoQuestionDone() {
			//跳转到我做过的页
			uni.navigateTo({
				url: './mineDone',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoCollection() {
			//跳转到收藏页
			uni.navigateTo({
				url: './collection',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoWrongBook() {
			//跳转到错题本页
			uni.navigateTo({
				url: './wrongBook',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoWordTest() {
			//跳转到识字量在线测试页
			uni.navigateTo({
				url: './wordTest',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoSettings() {
			//跳转到设置页
			uni.navigateTo({
				url: './settings',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.personalInfo {
	padding-top: 50rpx;
	padding-bottom: 50rpx;
	padding-left: 20rpx;
	padding-right: 20rpx;
	background-color: #dd4037;
}
.student_avatar {
	width: 100rpx;
	height: 100rpx;
	padding: 20rpx;
}
.student_simple_info {
	flex-wrap: wrap;
	width: 100%;
	height: 100rpx;
	flex: 1;
}
.stuedent_name_and_num {
	height: 50rpx;
	justify-content: center;
	align-items: flex-start;
	color: #ffffff;
}
.stuedent_class_name {
	height: 50rpx;
	justify-content: center;
	color: #ffffff;
}
.student_analysis {
	width: 52rpx;
	height: 52rpx;
}
</style>
