<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
<!-- 			<view v-if="singleList != null" slot="right" @click="submit()">确定</view> -->
		</NavBar>
		<view class="uni-list" style="margin-top: 20rpx;">
			<radio-group @change="radioChange">
				<label class="uni-list-cell uni-list-cell-pd" v-for="(item, index) in singleList" :key="item.id">
					<view><radio :value="index.toString()" :checked="index === current" /></view>
					<view>{{ item.name }}</view>
				</label>
			</radio-group>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import ApiManager from '../../common/api.js';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '选择国家或地区',
			current: 0,
			singleList: []
		};
	},
	onLoad: function(e) {
		uni.showLoading({
			title: '加载中...',
			mask: true
		});
		//获取国家和地区列表
		uni.request({
			url: ApiManager.getCountryList,
			method: 'GET',
			data: {},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功',
							mask: true
						});
						this.singleList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		radioChange(evt) {
			console.log(evt);
			this.current = evt.target.value;
			this.submit();
		},
		submit() {
			var that = this;
			if (that.singleList == null || that.singleList.length == 0) {
				return;
			}
			uni.showLoading({
				title: '提交中',
				mask: false
			});
			uni.request({
				url: ApiManager.changeCountry,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					countryId: this.singleList[this.current].id,
					countryName: this.singleList[this.current].name
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '提交成功',
								mask: true
							});
							setTimeout(function() {
								that.back();
							}, 1000);
						}
					}
				},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
</style>
