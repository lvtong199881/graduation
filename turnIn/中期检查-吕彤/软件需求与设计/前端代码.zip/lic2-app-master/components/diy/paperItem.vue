<template>
	<view class="uni-flex uni-column">
		<view class="uni-flex uni-row paperInfo">
			<view style="display: flex; align-items: center;"><image class="icon" v-bind:src="paperUrl" mode="aspectFill"></image></view>
			<view class="uni-flex uni-column" style="flex: 1;margin-left: 20rpx;">
				<text style="font-size: 24rpx;">{{ paperName }}</text>
				<text  style="font-size: 24rpx;">{{ paperTime }}</text>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	name: 'paperItem',
	data() {
		return {};
	},
	props: {
		paperUrl: {
			type: String,
			default: '/static/logo.png'
		},
		paperName: {
			type: String,
			default: '暂无数据'
		},
		paperTime: {
			type: String,
			default: '暂无数据'
		},
		showDivider:{
			type:Boolean,
			default:true
		}
		
	},
	methods: {}
};
</script>

<style>
	.paperInfo {
		padding: 20rpx;
		background-color: #ffffff;
	}
	.icon{
		width: 80rpx;
		height: 80rpx;
	}
</style>
