<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="识字量在线测试" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="estimated_vocabulary">
			预计词汇量：
			<text style="color: #DD4037;">{{ estimatedVocabulary }}</text>
		</view>
		<view class="uni-flex uni-column word_part">
			<view class="word_pinyin">{{ wordInfo.wordPinYin }}</view>
			<view class="word_name">{{ wordInfo.wordName }}</view>
		</view>
		<!--按钮区域-->
		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<view class="uni-flex uni-row">
				<button class="can_not_button_class" @click="isCanNot()">不认识</button>
				<button class="can_button_class" @click="isCan()">认识</button>
			</view>
			<button class="seem_button_class" @click="isSeem()">模糊</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			estimatedVocabulary: 100,
			wordInfo: {
				wordId: '',
				wordPinYin: 'tǎn tè',
				wordName: '忐忑'
			}
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		isCanNot() {
			//请求接口
			uni.showToast({
				title: '不认识',
				icon: 'none'
			});
		},
		isCan() {
			//请求接口
			uni.showToast({
				title: '认识',
				icon: 'none'
			});
		},
		isSeem() {
			//请求接口
			uni.showToast({
				title: '模糊',
				icon: 'none'
			});
		}
	}
};
</script>

<style>
.can_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-left: 10rpx;
	background-color: #dd4037;
	color: #ffffff;
}
.can_not_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-right: 10rpx;
	background-color: #dd4037;
	color: #ffffff;
}
.seem_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-top: 20rpx;
	background-color: #dd4037;
	color: #ffffff;
}
.word_pinyin {
	width: 100%;
	text-align: center;
	font-size: 96rpx;
}
.word_name {
	width: 100%;
	text-align: center;
	font-size: 192rpx;
}
.word_part {
	align-items: center;
	padding-bottom: 100rpx;
	background-color: #ffffff;
}
.estimated_vocabulary {
	width: 100%;
	text-align: center;
	padding-top: 40rpx;
	padding-bottom: 40rpx;
}
</style>
