<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="设置" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<formItem labelText="退出登录" showClick="true" showEditIcon="true" @click.native="trySignOut()" textColor="#dd4037"></formItem>
			<formItem labelText="修改密码" showClick="true" showEditIcon="true" @click.native="gotoChangePassword()" textColor="#dd4037"></formItem>
			<formItem labelText="检查新版本" showClick="true" showEditIcon="true" value="111" @click.native="checkNewVersion()"></formItem>
			<formItem labelText="关于" showClick="true" showEditIcon="true" @click.native="gotoAboutPage()"></formItem>
		</view>
	</view>
</template>

<script>
	import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		NavBar,
		formItem
	},
	data() {
		return {};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		checkNewVersion() {
			//检查新版本
			uni.showLoading({
				title: '正在获取最新版本信息',
				mask: true
			});
			uni.request({
				url: ApiManager.getNewVersion,
				method: 'GET',
				data: {},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						var versionId = content.versionId;
						var versionDesc = content.versionDesc;
						var versionUrl = content.versionUrl;
						if(versionId == getApp().globalData.version){
							uni.showToast({
								title: '当前已是最新版本',
								icon: 'none'
							});
						}else{
							uni.showModal({
								title: '新版本:' + versionId,
								content: '版本信息:\n' + versionDesc,
								showCancel: true,
								cancelText: '取消',
								confirmText: '更新',
								confirmColor: '#DD4037',
								success: res => {
									if (res.confirm) {
										//下载
										uni.showToast({
											title: '下载',
											icon: 'none'
										});
										plus.runtime.openURL(versionUrl);
									}
								},
								fail: () => {},
								complete: () => {}
							});
						}
					}
				},
				fail: () => {},
				complete: () => {
					uni.hideLoading();
				}
			});
		},
		trySignOut() {
			//尝试退出登录
			uni.showModal({
				title: '提示',
				content: '确定要退出登录吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '确定',
				confirmColor: '#DD4037',
				success: function(res) {
					if (res.confirm) {
						uni.reLaunch({
							url: '../login/login',
							success() {},
							fail() {},
							complete() {}
						});
					} else if (res.cancel) {
						console.log('用户点击取消');
					}
				},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChangePassword() {
			//跳转到修改密码页
			uni.navigateTo({
				url: './changePassword',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoAboutPage() {
			//跳转到关于页
			uni.navigateTo({
				url: './aboutPage',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
