<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<input :placeholder="placeholder" class="uni-input" v-model="inputValue" @input="onKeyInput" 
			:type="type"/>
			<view class="uni-flex uni-row">
				<uniIcons type="info" color="#dd4037" size="24"></uniIcons>
				<view style="display: flex; align-items: center;"><text>保存成功后不可撤销，请谨慎修改！</text></view>
			</view>
			<button class="button_determine" @click="tryChange()">确定修改</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '',
			placeholder: ',',
			inputValue: '',
			type:'text',
			pageInfo: {
				pageId: 1,
				pageName: ''
			}
		};
	},
	onLoad: function(e) {
		this.pageInfo.pageId = e.pageId;
		this.pageInfo.pageName = e.pageName;
		this.title = '修改' + e.pageName;
		this.placeholder = '请输入' + e.pageName;
		if (e.pageId == 1) {
			this.type = 'text'
		} else if(e.pageId == 2){
			this.type = 'number'
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onKeyInput: function(event) {
			this.inputValue = event.target.value;
		},
		tryChange() {
			if (this.pageInfo.pageId == 1) {
				//修改名字
				uni.showToast({
					title: '修改名字:'+this.inputValue,
					icon: 'none'
				});
			} else if (this.pageInfo.pageId == 2) {
				//修改手机号
				uni.showToast({
					title: '修改手机号:'+this.inputValue,
					icon: 'none'
				});
			}
		}
	}
};
</script>

<style>
.button_determine {
	width: 100%;
	font-size: 32rpx;
	color: #ffffff;
	background-color: #dd4037;
}
</style>
