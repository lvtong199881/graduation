var host = "http://huadaapi.luckyzune.com";
// var host= "http://192.168.31.162:8080";

var conFig = {
    host,
    question: `${host}/question`,
    teacherquestion: `${host}/finishtest`,//学生端 点击完成考试
	teststate: `${host}/teststate`,//获取小测
	usertest: `${host}/usertest`,//获取试卷
	insertanswer: `${host}/insertanswer`,
	finishtest: `${host}/finshtest`,
	photo: `${host}/oss/photo`,//上传图片
	mp3: `${host}/oss/mp3`,
	code: `${host}/sms/send/code`,
	login: `${host}/sms/login`,//验证码登录
	regist: `${host}/pwd/login/student`,//学生注册
	pwdLogin: `${host}/pwd/login`,//密码登录
	course: `${host}/course`,//
	userinfo: `${host}/userinfo`,//获得手机号码
	courseName: `${host}/courseName`,//获得课程名称
	userpost: `${host}/userpost`,//修改密码
	testDescribes: `${host}/testdescribes`,//显示试卷详情
	insertWriteAnswer: `${host}/insertwriteanswer`,//用于传写汉字的答案
	appphoto: `${host}/oss/appphoto`,//上传图片2.0
}

module.exports = conFig;