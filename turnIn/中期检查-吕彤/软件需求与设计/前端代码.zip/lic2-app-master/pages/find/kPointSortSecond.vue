<template>
	<!--知识点出题二级分类-->
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view v-for="(item, index) in sortSecondList" :key="index" @tap="openSecondinfo" :data-id="item.id">
			<view style="background-color: #FFFFFF;">
				<view style="padding: 20rpx;">
					<text style="font-size: 30rpx;">{{ item.name }}</text>
				</view>
				<view class="common-divider-line"></view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '知识点出题二级分类',
			firstId: -1,
			sortSecondList: []
		};
	},
	onLoad: function(e) {
		var firstId = getApp().globalData.kpSortIndex.firstIndex;
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getKPSecondList,
			method: 'POST',
			data: {
				firstIndex:firstId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.sortSecondList = content.secondList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		openSecondinfo(e) {
			var secondId = e.currentTarget.dataset.id;
			getApp().globalData.kpSortIndex.secondIndex = secondId;
			uni.navigateTo({
				url: './kPointSortThird',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
