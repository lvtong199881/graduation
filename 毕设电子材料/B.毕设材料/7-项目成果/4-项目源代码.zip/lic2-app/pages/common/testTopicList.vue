<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<view v-for="(item, index) in topicList" :key="index" @tap="openinfo" :data-newsid="item" style="display: inline-block;flex-direction: column;width:50%">
				<view class="uni-flex uni-row topicList_class" hover-class="topic_hover_class">
					<view class="common-tag">{{ index + 1 }}</view>
					<view>：题号{{ item }}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
export default {
	components: {
		topicItem,
		NavBar
	},
	data() {
		return {
			topicList: [],
			title: '考试题目列表',
			testId: -1
		};
	},
	onLoad: function(e) {
		console.log(e.testId);
		this.testId = e.testId;
		this.getTestData();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		getTestData() {
			uni.showLoading({
				title: '加载中....'
			});
			uni.request({
				url: ApiManager.getTestData,
				method: 'POST',
				data: {
					testId: parseInt(this.testId)
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功'
						});
						this.topicList = content.topicIdList;
						this.title= (content.testName==null || content.testName=='')?this.title:content.testName;
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		openinfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?showAnswer=true&topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		tryCollect(index) {
			console.log('收藏ID' + this.topicList[index].topicId);
			uni.request({
				url: ApiManager.collect,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					topicId: this.topicList[index].topicId
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '收藏成功',
							icon: 'none'
						});
					}
				},
				fail: () => {
					uni.showToast({
						title: '收藏失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		tryUnCollect(index) {
			console.log('取消收藏ID' + this.topicList[index].topicId);
			uni.request({
				url: ApiManager.unCollect,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					topicId: this.topicList[index].topicId
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '取消收藏成功',
							icon: 'none'
						});
					}
				},
				fail: () => {
					uni.showToast({
						title: '取消收藏失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.topic_hover_class {
	background-color: #dd4037 !important;
	padding: 20rpx;
	border-radius: 20rpx;
	margin: 0rpx 20rpx 20rpx 20rpx;
}
.topicList_class {
	background-color: #ffffff;
	padding: 20rpx;
	border-radius: 20rpx;
	margin: 0rpx 20rpx 20rpx 20rpx;
}
.index_class {
	text-align: center;
	font-size: 28rpx;
	border-radius: 10rpx;
	border-style: solid;
	color: #dd4037;
	border-width: thin;
	border-color: #dd4037;
	padding: 5rpx;
}
</style>
