<template name="courseItem">
	<view>
		<view class="form-item">
			<view class="uni-flex uni-row">
				<image class="item_image" v-bind:src="labelIconRes" mode="aspectFit"></image>
				<text class="text_label" style="-webkit-flex: 1;flex: 1;">{{ labelText }}</text>

				<view class="badge">
					<text class="badge_text">{{ badge_text }}</text>
				</view>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	props: {
		showDivider: {
			type: Boolean,
			default: true
		},
		labelText: {
			type: String,
			default: '暂无数据'
		},
		labelIconRes: {
			type: String,
			default: '/static/ic_course.png'
		},
		badge_text: {
			type: String,
			default: '1'
		}
	},
	methods: {}
};
</script>

<style>
.item_image {
	width: 80rpx;
	height: 80rpx;
	margin-right: 20rpx;
	background-color: rgba(248, 248, 248, 0.3);
	border-radius: 20rpx;
}
.text_label {
	flex: 1;
	align-self: center;
	width: 0;
	text-overflow: ellipsis;
	overflow: hidden;
}
.text_value {
	justify-content: flex-end;
	text-align: right;
	font-size: 28rpx;
}
.image_icon {
	width: 30rpx;
	height: 30rpx;
	padding: 10rpx;
	align-items: center;
}
.form-item {
	padding: 20rpx;
	background: #ffffff;
}
.badge {
	display: flex;
	align-items: center;
}
.badge_text {
	color: #ffffff;
	min-width: 30rpx;
	font-size: 24rpx;
	text-align: center;
	background-color: #dd524d;
	border-radius: 20rpx;
	padding-left: 5rpx;
	padding-right: 5rpx;
}
</style>
