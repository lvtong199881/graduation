<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<input :placeholder="placeholder" class="input" v-model="inputValue" @input="onKeyInput" :type="type" />
			<view class="uni-flex uni-row">
				<uniIcons type="info" color="#dd4037" size="20"></uniIcons>
				<view style="padding-left: 10rpx; display: flex; align-items: center;"><text>修改成功后不可撤销，请谨慎修改！</text></view>
			</view>
			<button class="button_determine" @click="tryChange()">确定修改</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import ApiManager from '../../common/api.js';
import Util from '../../common/util.js';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '',
			placeholder: ',',
			inputValue: '',
			type: 'text',
			pageInfo: {
				pageId: 1,
				pageName: ''
			}
		};
	},
	onLoad: function(e) {
		this.pageInfo.pageId = e.pageId;
		this.pageInfo.pageName = e.pageName;
		this.title = '修改' + e.pageName;
		this.placeholder = '请输入' + e.pageName;
		if (e.pageId == 1) {
			this.type = 'text';
		} else if (e.pageId == 2) {
			this.type = 'number';
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onKeyInput: function(event) {
			var value = event.target.value;
			setTimeout(() => {
				this.inputValue = value.replace(/\s+/g, '');
			}, 0);
		},
		tryChange() {
			var that = this;
			if (this.inputValue == '') {
				uni.showToast({
					title: this.placeholder,
					icon: 'none'
				});
				return;
			}
			if (this.pageInfo.pageId == 1) {
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				//修改名字
				uni.request({
					url: ApiManager.changeName,
					method: 'POST',
					data: {
						studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
						name: this.inputValue
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + ':' + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '修改成功',
									mask: true
								});
								setTimeout(function() {
									that.back();
								}, 1000);
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '修改失败',
							mask: true
						});
					},
					complete: () => {}
				});
			} else if (this.pageInfo.pageId == 2) {
				if (!Util.checkPhone(this.inputValue)) {
					uni.showToast({
						title: '手机号格式错误',
						icon: 'none'
					});
					return;
				}
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				//修改手机号
				uni.request({
					url: ApiManager.changePhone,
					method: 'POST',
					data: {
						studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
						phone: parseInt(this.inputValue)
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + ':' + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '修改成功',
									mask: true
								});
								setTimeout(function() {
									that.back();
								}, 1000);
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '修改失败',
							mask: true
						});
					},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.button_determine {
	width: 100%;
	font-size: 32rpx;
	color: #ffffff;
	background-color: #dd4037;
	padding: 10rpx;
}
.input {
	height: auto;
	padding: 20rpx;
	line-height: 50rpx;
	font-size: large;
	background: #fff;
	border-radius: 10rpx;
	flex: 1;
}
</style>
