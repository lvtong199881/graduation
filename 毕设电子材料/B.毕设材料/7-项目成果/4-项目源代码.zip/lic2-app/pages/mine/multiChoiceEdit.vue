<template>
	<view class="common-content-auto" style="margin-bottom: 100rpx;">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<!-- 			<view slot="right" @click="submit()">提交</view> -->
		</NavBar>
		<view style="margin-top: 20rpx;background-color: #FFFFFF;">
			<checkbox-group @change="checkboxChange">
				<label class="uni-list-cell uni-list-cell-pd" v-for="(item, index) in multiList" :key="item.value">
					<view><checkbox color="#DD4037" :value="index.toString()" :checked="item.checked" /></view>
					<view>{{ item.name }}</view>
				</label>
			</checkbox-group>
		</view>
		<button class="start_test_button" :style="{ width: screenWidth - 20 + 'px' }" @click="submit()">提交</button>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '',
			placeholder: ',',
			inputValue: '',
			multiList: [],
			checkedList: [],
			pageInfo: {
				pageId: 1,
				pageName: ''
			},
			screenHeight: -1,
			screenWidth: -1
		};
	},
	onLoad: function(e) {
		//获取屏幕高度
		uni.getSystemInfo({
			success: res => {
				this.screenHeight = res.screenHeight;
				this.screenWidth = res.screenWidth;
				console.log('页面高度=' + this.screenHeight);
				console.log('页面宽度=' + this.screenWidth);
			}
		});
		this.pageInfo.pageId = e.pageId;
		this.pageInfo.pageName = e.pageName;
		this.title = '选择' + e.pageName;
		// if (e.pageId == 5) {
		//获取兴趣爱好列表
		uni.showLoading({
			title: '加载中...',
			mask: true
		});
		uni.request({
			url: ApiManager.getHobbyList,
			method: 'GET',
			data: {},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功',
							mask: true
						});
						this.multiList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
		// }
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		checkboxChange: function(e) {
			console.log(e);
			this.checkedList = e.detail.value;
		},
		submit() {
			var that = this;
			if (that.multiList == null || that.multiList.length == 0) {
				return;
			}
			if (this.checkedList.length == 0) {
				uni.showToast({
					title: '请先选择兴趣爱好',
					icon: 'none'
				});
				return;
			}
			console.log(this.checkedList);
			console.log(this.checkedList.length);
			//选中的id数组修改为
			var hobbyList = new Array(this.checkedList.length);
			for (var i = 0; i < this.checkedList.length; i++) {
				hobbyList[i] = this.multiList[parseInt(this.checkedList[i])];
			}
			console.log(hobbyList);
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			uni.request({
				url: ApiManager.changeHobbies,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					hobbyList: hobbyList
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '修改成功',
								mask: true
							});
							setTimeout(function() {
								that.back();
							}, 1000);
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '修改失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
.start_test_button {
	background-color: #dd4037;
	margin: 20rpx;
	color: #ffffff;
	position: fixed;
	bottom: 0;
	left: 0;
	z-index: 500;
}
</style>
