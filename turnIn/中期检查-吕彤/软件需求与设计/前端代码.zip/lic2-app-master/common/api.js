// var host = "http://huadaapi.luckyzune.com";
// var host= "http://192.168.31.162:8080";
var host = "http://yapi.demo.qunar.com/mock/66733/app"; //mock地址

var conFig = {
	host,
	login: `${host}/login/login`, //登录
	
	getStudentInfo: `${host}/mine/getStudentInfo`, //获取学生信息
	getCountryList: `${host}/mine/getCountryList`, //获取国家或地区列表
	getLanguageList: `${host}/mine/getLanguageList`, //获取语言列表
	changeCountry: `${host}/mine/changeCountry`, //修改国家或地区
	changeLanguage: `${host}/mine/changeLanguage`, //修改语言
	getHobbyList: `${host}/mine/getHobbyList`, //获取兴趣爱好列表
	changeHobbies: `${host}/mine/changeHobbies`, //修改兴趣爱好
	getNewVersion: `${host}/mine/getNewVersion`, //获取新版本
	changePassword: `${host}/mine/changePassword`, //修改密码
	getAnalysisData:`${host}/mine/getAnalysisData`, //获取学生分析数据

	getCourseList: `${host}/home/getCourseList`, //获取课程列表
	getMineDoneTopic: `${host}/mine/getMineDoneTopic`, //获取我做过的题目
	getMineDoneTest: `${host}/mine/getMineDoneTest`, //获取我做过的试卷
	getCollectTopic: `${host}/mine/getCollectTopic`, //获取收藏的题目
	getCollectTest: `${host}/mine/getCollectTest`, //获取收藏的试卷
	getWrongBookTopic: `${host}/mine/getWrongBookTopic`, //获取错题本中的题目

	getRecommendTopic: `${host}/find/getRecommendTopic`, //获取推荐题目
	getRandomTopic: `${host}/find/getRandomTopic`, //获取随机出题题目
	getKPFirstList: `${host}/find/getKPFirstList`, //获取知识点一级分类列表
	getKPSecondList: `${host}/find/getKPSecondList`, //获取知识点二级分类列表
	getKPThirdList: `${host}/find/getKPThirdList`, //获取知识点三级分类列表
	getKPList: `${host}/find/getKPList`, //获取知识点列表
	getKPTopicList: `${host}/find/getKPTopicList`, //获取知识点关联的题目列表


	getCourseActivityList: `${host}/home/getCourseActivityList`, //获取课程活动列表
	getCourseMaterialList: `${host}/home/getCourseMaterialList`, //获取课程资料列表
	getVocabularySortList: `${host}/home/getVocabularySortList`, //获取课程字词分类列表
	getVocabularyList: `${host}/home/getVocabularyList`, //获取课程字词列表
	getVocabularyDetail: `${host}/home/getVocabularyDetail`, //获取课程字词详情
	getTestDetail: `${host}/common/getTestDetail`, //获取试卷详情
	getTopicDetail: `${host}/common/getTopicDetail`, //获取题目详情

}

module.exports = conFig;
