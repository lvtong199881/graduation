<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		globalData: {
			kpSortIndex:{
				firstIndex:-1,
				secondIndex:-1,
				thirdIndex:-1,
				kpointId:-1
			},
			version: '1.0.0',
			studentInfo:{
				studentNumber:'',
				name:'',
				phone:'',
				classId:0,
				className:'',
				countryId:'',
				countryName:'',
				languageId:'',
				languageName:'',
				collegeId:'',
				collegeName:'',
				divisionId:0,
				divisionName:'',
				registrationTime:'',
				learnedTime:'',
				hobbies:''
			}
		}
	}
</script>

<style>
	/*每个页面公共css */
	    @import './common/uni.css';
</style>
