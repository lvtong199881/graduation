<template>
	<view class="common-content">
		<NavBar :title="title" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view class="uni-flex uni-row" slot="left">
				<uniIcons type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
				<view class="vocabulary_class" @click="gotoVocabulary">词</view>
			</view>
		</NavBar>
		<view class="uni-flex uni-row">
			<button v-if="current == 0" class="viewPage_checked" @click="getActivityList()">课程活动</button>
			<button v-else class="viewPage" @click="getActivityList()">课程活动</button>
			<button v-if="current == 1" class="viewPage_checked" @click="getMaterialList()">课程资料</button>
			<button v-else class="viewPage" @click="getMaterialList()">课程资料</button>
		</view>
		<swiper :style="{ height: swiperHeight + 'px' }" class="swiper" circular="true" :current="current" duration="300" @change="onswiperchange">
			<swiper-item item-id="0" style="margin-top: 20rpx;">
				<view class="activity_list_class">
					<view v-for="(item, index) in indexList" :key="index">
						<view style="padding: 0rpx 20rpx 20rpx 20rpx;">{{ item.name }}</view>
						<view class="common-divider-line" style="margin-bottom: 20rpx;width: auto;margin-left: 20rpx;margin-right: 20rpx;"></view>
						<view v-if="item.data.length != 0" v-for="(item2, index2) in item.data" :key="index2" @tap="openTestInfo" :data-newsid="item2.id" :data-type="index">
							<testItem
								testIconRes="../../static/ic_test.png"
								:testName="item2.name"
								:testTime="item2.time"
								:testState="item2.stateString"
								:testDurtion="item2.duration.toString()"
							></testItem>
						</view>
					</view>
				</view>
			</swiper-item>

			<swiper-item item-id="1" style="margin-top: 20rpx;">
				<view class="material_list_class">
					<view hover-class="uni-list-cell-hover" v-for="(item, index) in materialList" :key="index" @click="openMaterialInfo" :data-newsid="index">
						<materialItem
							materialUrl="../../static/ic_material.png"
							:materialName="item.name"
							:materialTime="item.time"
							:materialDesc="item.description"
						></materialItem>
					</view>
				</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import testItem from '../../components/diy/testItem.vue';
import materialItem from '../../components/diy/materialItem.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		testItem,
		materialItem,
		uniIcons
	},
	data() {
		return {
			courseId: 0,
			title: '课程详情',
			activityList: [],
			materialList: [],
			current: 0,
			swiperHeight: 0, //外部的高度
			indexList: [
				{
					name: '未开始',
					data: new Array()
				},
				{
					name: '进行中',
					data: new Array()
				},
				{
					name: '已结束',
					data: new Array()
				}
			]
		};
	},
	onLoad: function(e) {
		var that = this;
		this.courseId = e.courseId;
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getCourseActivityList,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
				courseId: parseInt(this.courseId)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功',
							mask: true
						});
						that.activityList = content;
						if (content != null && content.length != 0) {
							for (var i = 0; i < content.length; i++) {
								if (that.activityList[i].stateString == '未开始') {
									that.indexList[0].data.push(that.activityList[i]);
								} else if (that.activityList[i].stateString == '进行中') {
									that.indexList[1].data.push(that.activityList[i]);
								} else {
									that.indexList[2].data.push(that.activityList[i]);
								}
							}
						}
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					mask: true
				});
			},
			complete: () => {}
		});
		uni.request({
			url: ApiManager.getCourseMaterialList,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
				courseId: parseInt(this.courseId)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功',
							mask: true
						});
						this.materialList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	onShow: function() {
		this.current = 0;
	},
	watch: {
		activityList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.activity_list_class');
			});
		},
		materialList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.material_list_class');
			});
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		initSwiperHeight(list) {
			let _this = this;
			let info = uni.createSelectorQuery().select(list);
			info.boundingClientRect(function(data) {
				if (_this.swiperHeight < data.height + 50) {
					_this.swiperHeight = data.height + 50;
				}
			}).exec();
		},
		onswiperchange(e) {
			this.current = e.detail.current;
			if (this.current == 0) {
				this.initSwiperHeight('.activity_list_class');
			} else {
				this.initSwiperHeight('material_list_class');
			}
		},
		getActivityList() {
			this.current = 0;
		},
		getMaterialList() {
			this.current = 1;
		},
		openTestInfo(e) {
			console.log(e.currentTarget.dataset.newsid);
			console.log(e.currentTarget.dataset.type);
			uni.navigateTo({
				url: '../common/testDetail?testId=' + e.currentTarget.dataset.newsid + '&state=' + e.currentTarget.dataset.type,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openMaterialInfo(e) {
			var that = this;
			uni.showModal({
				title: '提示',
				content: '确定要下载【' + that.materialList[e.currentTarget.dataset.newsid].name + '】吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '下载',
				success: res => {
					if (res.confirm) {
						uni.showLoading({
							title: '下载中...',
							mask: false
						});
						uni.downloadFile({
							url: that.materialList[e.currentTarget.dataset.newsid].downloadUrl,
							success: res => {
								uni.hideLoading();
								if (res.statusCode === 200) {
									uni.showToast({
										title: '下载成功',
										icon: 'none'
									});
									console.log(res.tempFilePath);
									uni.openDocument({
										filePath: res.tempFilePath,
										success: function(res) {
											uni.showToast({
												title: '打开文档成功',
												icon: 'none'
											});
										},
										fail: function(res) {
											console.log(res);
										}
									});
								} else {
									uni.showToast({
										title: res.statusCode,
										icon: 'none'
									});
								}
							},
							fail: res => {
								uni.hideLoading();
								uni.showToast({
									title: '下载失败',
									icon: 'none'
								});
							}
						});
					}
				},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoVocabulary() {
			uni.navigateTo({
				url: './vocabulary?courseId=' + this.courseId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.viewPage {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
}
.viewPage_checked {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
	font-weight: bold;
}
.swiper {
	display: flex;
}
.vocabulary_class {
	padding: 20rpx;
	font-size: 32rpx;
}
</style>
