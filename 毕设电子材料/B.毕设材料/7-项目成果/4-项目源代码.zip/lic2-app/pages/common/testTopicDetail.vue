<template>
	<view style="height: auto;padding-bottom: 130rpx;">
		<NavBar :title="sheetList.testName" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view class="uni-flex uni-row" slot="left">
				<uniIcons type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
				<uniIcons type="list" color="#ffffff" size="24" @click="showAnswerSheet()" style="margin-left: 20rpx;"></uniIcons>
			</view>
		</NavBar>
		<!--悬浮按钮:切换上下题-->
		<view class="uni-flex uni-row fab" :style="{ width: screenWidth - 20 + 'px' }">
			<button style="-webkit-flex: 1;flex: 1;" @click="switchLastTopic">上一题</button>
			<button style="-webkit-flex: 1;flex: 1;color: #DD4037;" disabled="true">{{ topicIndex + 1 }}/{{ topicNumber }}</button>
			<button style="-webkit-flex: 1;flex: 1;" @click="switchNexTopic">下一题</button>
		</view>
		<view class="test_class">
			<!--模块名称与倒计时-->
			<view class="uni-flex uni-row common-card-f8f8f8">
				<text style="-webkit-flex: 1;flex: 1;font-size: 28rpx;font-weight: bold;align-self: center;" @click="showModuleInfo">{{ currentModule }}</text>
				<uni-countdown
					:showDay="false"
					:showColon="false"
					color="#dd4037"
					background-color="#f8f8f8"
					:minute="sheetList.testDuration"
					@timeup="countdownTimeUp('时间到')"
				></uni-countdown>
			</view>
			<view class="common-divider-line"></view>
			<view class="uni-flex uni-row common-card-f8f8f8" style="margin-top: 20rpx;">
				<text class="common-tag">第{{ topicIndex + 1 }}题</text>
				<text class="common-tag">{{ topicInfo.topicTypeString }}</text>
				<text class="common-tag">{{ topicDifficultyString }}</text>
			</view>
			<!--题目内容-->
			<view v-if="refreshView">
				<view>
					<view class="common-card-f8f8f8">
						<text class="common-tag">题干</text>
						{{ topicInfo.topicName }}
					</view>
					<!--音频-->
					<view v-if="topicInfo.topicAudioUrl != null && topicInfo.topicAudioUrl.length != 0">
						<uniIcons @click.native="playTopicAudio" type="sound" color="#DD4037" size="30"></uniIcons>
					</view>
				</view>
				<!--——————————————问题-单选题——————————————-->
				<view v-if="topicInfo.topicType == 0" v-for="(item, index) in topicInfo.questionList" :key="index" class="common-card-f8f8f8">
					<view>
						<!--问题名称-->
						<view>{{ index + 1 }}.{{ item.name }}</view>
						<!--问题音频-->
						<uniIcons
							v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
							@click.native="playQuesttionAudio"
							type="sound"
							color="#DD4037"
							size="30"
							:data-newsid="index"
						></uniIcons>
						<!--问题图片-->
						<swiper
							v-if="topicInfo.questionList[index].imageUrl != null && topicInfo.questionList[index].imageUrl.size != 0"
							class="swiper"
							indicator-dots="true"
							autoplay="true"
							interval="5000"
							duration="1000"
						>
							<swiper-item v-for="(item, index) in topicInfo.questionList[index].imageUrl" :key="index">
								<image style="height: 300rpx;" :src="item" mode="aspectFit"></image>
							</swiper-item>
						</swiper>
						<!--选项-->
						<radio-group @change="radioChange" :data-id="index">
							<view class="uni-list-cell uni-list-cell-pd" v-for="(item2, index2) in item.optionList" :key="index2">
								<view v-if="singleAns[index] == getChar(index2)"><radio :value="index2.toString()" checked /></view>
								<view v-else><radio :value="index2.toString()" /></view>
								<view style="width: 100%;">{{ item2 }}</view>
							</view>
						</radio-group>
					</view>
				</view>
				<!--——————————————问题-多选题——————————————-->
				<view v-if="topicInfo.topicType == 1" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id" class="common-card-f8f8f8">
					<view>
						<!--问题描述-->
						<view>{{ index + 1 }}.{{ item.name }}</view>
						<!--问题音频-->
						<uniIcons
							v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
							@click.native="playQuesttionAudio"
							type="sound"
							color="#DD4037"
							size="30"
							:data-newsid="index"
						></uniIcons>
						<!--问题图片-->
						<swiper
							v-if="topicInfo.questionList[index].imageUrl != null && topicInfo.questionList[index].imageUrl.size != 0"
							class="swiper"
							indicator-dots="true"
							autoplay="true"
							interval="5000"
							duration="1000"
						>
							<swiper-item v-for="(item, index) in topicInfo.questionList[index].imageUrl" :key="index">
								<image style="height: 300rpx;" :src="item" mode="aspectFit"></image>
							</swiper-item>
						</swiper>
						<!--选项-->
						<checkbox-group @change="checkboxChange" :data-id="index">
							<view class="uni-list-cell uni-list-cell-pd" v-for="(item, index) in item.optionList" :key="index">
								<view><checkbox :value="index.toString()" :checked="item.checked" /></view>
								<view>{{ item.name }}</view>
							</view>
						</checkbox-group>
					</view>
				</view>
				<!--——————————————问题-填空题——————————————-->
				<view v-if="topicInfo.topicType == 2" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
					<view>
						<view>{{ index + 1 }}.{{ item.name }}</view>
						<!--问题音频-->
						<uniIcons
							v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
							@click.native="playQuesttionAudio"
							type="sound"
							color="#DD4037"
							size="30"
							:data-newsid="index"
						></uniIcons>
						<input class="question_input" placeholder="输入答案" :value="blankAns[index]" @input="blankInput" :data-id="index" />
					</view>
				</view>
				<!--——————————————问题-写汉字题——————————————-->
				<view v-if="topicInfo.topicType == 3" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
					<view>
						<view>{{ index + 1 }}.{{ item.name }}</view>
						<!--问题音频-->
						<uniIcons
							v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
							@click.native="playQuesttionAudio"
							type="sound"
							color="#DD4037"
							size="30"
							:data-newsid="index"
						></uniIcons>
						<!--问题图片-->
						<swiper v-if="item.imageUrl != null && item.imageUrl.size != 0" class="swiper" indicator-dots="true" autoplay="true" interval="5000" duration="1000">
							<swiper-item v-for="(item, index) in item.imageUrl" :key="index"><image style="height: 300rpx;" :src="item" mode="aspectFit"></image></swiper-item>
						</swiper>
						<view v-if="needRefresh">
							<view class="uni-flex uni-row">
								<button class="common-tag" style="flex:1" @click="doss" :data-id="index">写汉字</button>
								<button class="common-tag" style="flex:1" @click="cleanWriteAns" :data-id="index">清除</button>
							</view>
							<view v-if="writeAns[index] != '' && writeAns[index] != null" class="imgs"><image class="img" :src="writeAns[index]" mode="widthFix"></image></view>
							<catSignature canvasId="canvas1" @close="close" @save="save" :visible="isShow" :canvasIndex="index" />
						</view>
					</view>
				</view>
				<!--——————————————问题-作文题——————————————-->
				<view v-if="topicInfo.topicType == 4" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
					<view>
						<view>{{ index + 1 }}.{{ item.name }}</view>
						<!--问题音频-->
						<uniIcons
							v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
							@click.native="playQuesttionAudio"
							type="sound"
							color="#DD4037"
							size="30"
							:data-newsid="index"
						></uniIcons>
						<!--问题图片-->
						<swiper v-if="item.imageUrl != null && item.imageUrl.size != 0" class="swiper" indicator-dots="true" autoplay="true" interval="5000" duration="1000">
							<swiper-item v-for="(item, index) in item.imageUrl" :key="index"><image style="height: 300rpx;" :src="item" mode="aspectFit"></image></swiper-item>
						</swiper>
						<view v-if="needRefresh">
							<view class="uni-flex uni-row">
								<button class="common-tag" style="flex:1" @click="chooseImage" :data-id="index">选择图片</button>
								<button class="common-tag" style="flex:1" @click="cleanEssayAns" :data-id="index">清除</button>
							</view>
							<image v-if="essayAns[index] != null && essayAns[index] != ''" v-bind:src="essayAns[index]" mode="aspectFit"></image>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!--侧滑导航:答题卡-->
		<Drawer style="height: auto;" :visible="showDrawer" mode="right" @close="closeDrawer">
			<view>
				<view class="status_bar"><!-- 状态栏高度 --></view>
				<button class="common-tag" style="margin: 20rpx;" @click="countdownTimeUp('交卷')">交卷</button>
				<view v-for="(item, index) in sheetList.topicIdList" :key="index" style="display: inline-block;flex-direction: row;">
					<view v-if="index == topicIndex" class="drawer_sheet_child_current" @click="switchTopic(index)">{{ index + 1 }}</view>
					<view v-else class="drawer_sheet_child" @click="switchTopic(index)">{{ index + 1 }}</view>
				</view>
			</view>
		</Drawer>
	</view>
</template>

<script>
var innerAudioContext = uni.createInnerAudioContext();
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import WritingArea from '../../components/diy/writingArea';
import catSignature from '../../components/diy/cat-signature.vue';
import { pathToBase64, base64ToPath } from '../../common/image.js';
import Drawer from '../../components/uni-drawer/uni-drawer.vue';
import uniSection from '../../components/uni-section/uni-section.vue';
import uniCountdown from '../../components/uni-countdown/uni-countdown.vue';
import Util from '../../common/util.js';
export default {
	components: {
		NavBar,
		uniIcons,
		Drawer,
		uniSection,
		uniCountdown,
		WritingArea,
		catSignature
	},
	data() {
		return {
			testId: -1,
			topicInfo: {},
			topicDifficultyString: '简单',
			imageUrl: '',
			singleAns: [],
			multipleAns: [],
			blankAns: [],
			writeAns: [],
			essayAns: [],
			//作文题选择图片后刷新视图
			needRefresh: true,
			refreshView: true,
			//写汉字canvas
			isShow: false,
			writeIndex: -1,
			played: false,
			title: '考试页面',
			testDuration: 60,
			topicIndex: -1,
			topicId: 0,
			topicNumber: 0,
			currentModule: '当前模块',
			showDrawer: false,
			screenHeight: 0,
			screenWidth: 0,
			sheetList: {
				testName: '考试页面'
			},
			isFirstClickLast: true,
			//用于判断是否可以直接退出
			canQuit: false,
			startTime: ''
		};
	},
	onLoad: function(e) {
		//考试id
		console.log('考试id：' + e.testId);
		this.testId = e.testId;
		var that = this;
		this.startTime = new Date();
		console.log(this.startTime);
		uni.showLoading({
			title: '加载中...',
			mask: true
		});
		//获取屏幕高度
		uni.getSystemInfo({
			success: res => {
				this.screenHeight = res.screenHeight;
				this.screenWidth = res.screenWidth;
				console.log('页面高度=' + this.screenHeight);
				console.log('页面宽度=' + this.screenWidth);
			}
		});
		uni.request({
			url: ApiManager.getTestData,
			method: 'POST',
			data: {
				testId: parseInt(e.testId)
			},
			success: res => {
				var errorCode = res.data.errCode;
				var errorMsg = res.data.errMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					that.sheetList = content;
					uni.showToast({
						title: '加载成功'
					});
					this.topicNumber = this.sheetList.topicIdList.length;
					this.switchTopic(0);
					//获取题目数据部分
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
				setTimeout(function() {
					that.back();
				}, 500);
			},
			complete: () => {}
		});
	},
	onUnload() {
		var endTime = new Date();
		var msecondOfMinute = 1000 * 60;
		innerAudioContext.stop();
		var learnTime = Math.floor((endTime - this.startTime) / msecondOfMinute);
		console.log(learnTime);
		uni.request({
			url: ApiManager.updataLearnTime,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
				time: parseInt(learnTime)
			},
			success: res => {},
			fail: () => {},
			complete: () => {}
		});
	},
	onBackPress() {
		if (this.canQuit) {
			console.log('直接退出');
			return false;
		}
		if (this.done != 0) {
			uni.showModal({
				title: '确定要退出吗？',
				content: '未交卷退出无法看到考试分数',
				showCancel: true,
				success: res => {
					if (res.cancel) {
						this.canQuit = false;
						return true;
					} else {
						this.canQuit = true;
						this.back();
					}
				},
				fail: () => {},
				complete: () => {}
			});
			return true;
		}
	},
	methods: {
		back() {
			//#ifdef MP-WEIXIN
			uni.showModal({
				title: '确定要退出吗？',
				content: '未交卷退出无法看到考试分数',
				showCancel: true,
				success: res => {
					if (res.confirm) {
						uni.navigateBack({
							delta: 1
						});
					}
				},
				fail: () => {},
				complete: () => {}
			});
			//#endif
			//#ifdef APP-PLUS||H5
			uni.navigateBack({
				delta: 1
			});
			//#endif
		},
		getChar(index2) {
			switch (index2) {
				case 0:
					return 'A';
				case 1:
					return 'B';
				case 2:
					return 'C';
				case 3:
					return 'D';
				default:
					return 'A';
			}
		},
		showModuleInfo() {
			var image = Util.getModuleInfo(this.currentModule);
			if (image == null || image == '') {
				uni.showToast({
					title: '暂无题目说明',
					icon: 'none'
				});
			} else {
				uni.previewImage({
					urls: [image],
					fail: function(err) {
						uni.showToast({
							title: err.errMsg,
							icon: 'none'
						});
					}
				});
			}
		},
		refreshTopic() {
			var that = this;
			this.refreshView = false;
			console.log(this.topicId);
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			//获取题目详情
			uni.request({
				url: ApiManager.getTopicDetail,
				method: 'POST',
				data: {
					topicId: parseInt(this.topicId),
					testId: parseInt(this.testId),
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.topicInfo = content;
						that.topicDifficultyString = that.topicInfo.topicDifficulty == 0 ? '简单' : that.topicInfo.topicDifficulty == 1 ? '中等' : '困难';
						//初始化学生答案数组-单选
						this.singleAns = new Array(content.questionList.length);
						this.blankAns = new Array(content.questionList.length);
						this.writeAns = new Array(content.questionList.length);
						this.essayAns = new Array(content.questionList.length);
						if (content.oldAnswer != null) {
							if (this.singleAns.length == content.oldAnswer.length) {
								this.singleAns = content.oldAnswer;
							}
							if (this.blankAns.length == content.oldAnswer.length) {
								this.blankAns = content.oldAnswer;
							}
							if (this.writeAns.length == content.oldAnswer.length) {
								this.writeAns = content.oldAnswer;
							}
							if (this.essayAns.length == content.oldAnswer.length) {
								this.essayAns = content.oldAnswer;
							}
						}
					}
				},
				fail: () => {},
				complete: () => {
					this.refreshView = true;
					this.getModuleName();
					uni.hideLoading();
				}
			});
		},
		//获取模块名称
		getModuleName(index) {
			var array = this.sheetList.labelList;
			for (var i = array.length - 1; i >= 0; i--) {
				if (array[i].startIndex <= index) {
					return array[i].label;
				}
			}
			return '暂无数据';
		},
		//打开答题卡
		showAnswerSheet() {
			this.showDrawer = true;
		},
		//关闭答题卡
		closeDrawer() {
			this.showDrawer = false;
		},
		//切换题目
		switchTopic(index) {
			if (this.topicIndex != -1) {
				//切换题目停止播放音频
				innerAudioContext.stop();
				//先提交当前题目答案
				this.submit();
			}
			this.topicIndex = index;
			this.topicId = this.sheetList.topicIdList[index];
			this.currentModule = this.getModuleName(index);
			console.log('切换题目 ' + '序号' + index + ' ID' + this.topicId);
			this.closeDrawer();
			this.refreshTopic();
		},
		//切换上一题
		switchLastTopic() {
			if (this.topicIndex == 0) {
				uni.showToast({
					title: '当前已经是第一题',
					icon: 'none'
				});
			} else {
				//切换题目停止播放音频
				innerAudioContext.stop();
				this.played = false;
				this.submit();
				this.topicIndex--;
				this.topicId = this.sheetList.topicIdList[this.topicIndex];
				this.currentModule = this.getModuleName(this.topicIndex);
				this.refreshTopic();
			}
		},
		//切换下一题
		switchNexTopic() {
			var that = this;
			if (this.topicIndex == this.sheetList.topicIdList.length - 1) {
				if (this.isFirstClickLast == true) {
					uni.showModal({
						title: '提示',
						content: '是否现在交卷？打开答题卡也可交卷',
						success: res => {
							that.isFirstClickLast = false;
							if (res.confirm) {
								that.isFirstClickLast = false;
								that.countdownTimeUp('交卷');
							}
						},
						fail: () => {},
						complete: () => {}
					});
				}
				uni.showToast({
					title: '当前已经是最后一题',
					icon: 'none'
				});
			} else {
				//切换题目停止播放音频
				innerAudioContext.stop();
				this.submit();
				this.topicIndex++;
				this.topicId = this.sheetList.topicIdList[this.topicIndex];
				this.currentModule = this.getModuleName(this.topicIndex);
				this.refreshTopic();
			}
		},
		//倒计时到
		countdownTimeUp(type) {
			innerAudioContext.stop();
			var toastString = type == '时间到' ? '时间到，停止答题' : '学生交卷，停止答题';
			var that = this;
			uni.showToast({
				title: toastString,
				mask: true
			});
			this.submit();
			setTimeout(function() {
				console.log(that.testId);
				uni.redirectTo({
					url: 'testCompleted?testId=' + that.testId,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}, 2000);
		},
		//单选题
		radioChange: function(e) {
			var values = e.detail.value;
			console.log(e);
			console.log(e.currentTarget.dataset.id);
			this.singleAns[e.currentTarget.dataset.id] = values;
			console.log(this.singleAns);
		},
		//多选题
		checkboxChange: function(e) {
			var values = e.detail.value;
			console.log(e);
			console.log(e.currentTarget.dataset.id);
			this.multipleAns[e.currentTarget.dataset.id] = values;
			console.log(this.multipleAns);
		},
		//填空题
		blankInput(e) {
			this.blankAns[e.currentTarget.dataset.id] = e.detail.value;
			console.log(this.blankAns);
		},
		//播放题目中的音频
		playTopicAudio(e) {
			var that = this;
			console.log(this.played);
			//如果播放中，那么不响应
			if (this.played == false) {
				innerAudioContext.autoplay = true;
				innerAudioContext.src = this.topicInfo.topicAudioUrl;
				console.log('播放地址:' + that.topicInfo.topicAudioUrl);
				innerAudioContext.onPlay(() => {
					uni.showToast({
						title: '开始播放',
						icon: 'none'
					});
					that.played = true;
				});
				innerAudioContext.onWaiting(function() {
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					});
				});
				innerAudioContext.onError(res => {
					uni.showToast({
						title: '播放错误' + res.errCode + ':' + res.errMsg
					});
					that.played = false;
				});
				innerAudioContext.onEnded(res => {
					uni.showToast({
						title: '播放完成',
						icon: 'none'
					});
					that.played = false;
				});
				innerAudioContext.onStop(function() {
					that.played = false;
				});
			}
		},
		//写汉字题
		//显示canvas
		doss(e) {
			this.writeIndex = e.currentTarget.dataset.id;
			this.isShow = true;
		},
		//清除写汉字答案
		cleanWriteAns(e) {
			this.needRefresh = false;
			this.writeAns[e.currentTarget.dataset.id] = null;
			this.needRefresh = true;
			console.log(this.writeAns);
		},
		//清除作文答案
		cleanEssayAns(e) {
			this.needRefresh = false;
			this.essayAns[e.currentTarget.dataset.id] = null;
			this.needRefresh = true;
			console.log(this.essayAns);
		},
		//关闭canvas
		close() {
			this.isShow = false;
		},
		//保存图片
		save(image) {
			var that = this;
			this.isShow = false;
			this.needRefresh = false;
			var imageUrl = null;
			console.log(image);
			//#ifdef MP-WEIXIN
			console.log('MP-WEIXIN');
			pathToBase64(image)
				.then(base64 => {
					console.log('转base64成功');
					// console.log(base64);
					uni.request({
						url: ApiManager.uploadPicture,
						method: 'POST',
						data: {
							file_byte: base64
						},
						success: res => {
							that.writeAns[that.writeIndex] = res.data.url;
							that.needRefresh = true;
							console.log(that.writeAns);
						},
						fail: () => {
							uni.showToast({
								title: '加载失败',
								icon: 'none'
							});
							that.needRefresh = true;
						},
						complete: () => {}
					});
				})
				.catch(error => {
					console.error(error);
				});
			//#endif
			//#ifdef H5
			console.log('h5');
			uni.request({
				url: ApiManager.uploadPicture,
				method: 'POST',
				data: {
					file_byte: image
				},
				success: res => {
					that.writeAns[that.writeIndex] = res.data.url;
					that.needRefresh = true;
					console.log(that.writeAns);
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
					that.needRefresh = true;
				},
				complete: () => {}
			});
			//#endif
			//#ifdef APP-PLUS
			console.log('app');
			plus.io.resolveLocalFileSystemURL(image, entry => {
				entry.file(file => {
					var fileReader = new plus.io.FileReader();
					fileReader.readAsDataURL(file);
					fileReader.onloadend = evt => {
						uni.request({
							url: ApiManager.uploadPicture,
							data: {
								file_byte: evt.target.result
							},
							method: 'POST',
							success: res2 => {
								console.log('上传成功');
								console.log(res2.data.url);
								that.writeAns[that.writeIndex] = res2.data.url;
								that.needRefresh = true;
							},
							fail() {
								uni.showToast({
									title: '上传失败，请重新写字',
									icon: 'none'
								});
							},
							complete() {
								console.log(that.writeAns);
							}
						});
					};
				});
			});
			//#endif
		},
		//作文题-选择图片
		chooseImage(e) {
			this.needRefresh = false;
			console.log(this.essayAns);
			console.log(e.currentTarget.dataset.id);
			var that = this;
			uni.chooseImage({
				count: 1,
				success: function(res) {
					that.needRefresh = false;
					var image = res.tempFilePaths[0];
					//#ifdef H5||MP-WEIXIN
					console.log('h5');
					pathToBase64(image)
						.then(base64 => {
							console.log('转base64成功');
							// console.log(base64);
							uni.request({
								url: ApiManager.uploadPicture,
								method: 'POST',
								data: {
									file_byte: base64
								},
								success: res => {
									console.log(res.data.url);
									that.essayAns[e.currentTarget.dataset.id] = res.data.url;
									that.needRefresh = true;
									console.log(that.essayAns);
								},
								fail: () => {
									uni.showToast({
										title: '加载失败',
										icon: 'none'
									});
									that.needRefresh = true;
								},
								complete: () => {}
							});
						})
						.catch(error => {
							console.error(error);
						});
					//#endif
					//#ifdef APP-PLUS
					console.log('app');
					plus.io.resolveLocalFileSystemURL(image, entry => {
						entry.file(file => {
							var fileReader = new plus.io.FileReader();
							fileReader.readAsDataURL(file);
							fileReader.onloadend = evt => {
								uni.request({
									url: ApiManager.uploadPicture,
									data: {
										file_byte: evt.target.result
									},
									method: 'POST',
									success: res => {
										console.log('上传成功');
										console.log(res.data.url);
										that.essayAns[e.currentTarget.dataset.id] = res.data.url;
										that.needRefresh = true;
									},
									fail() {
										uni.showToast({
											title: '上传失败，请重新写字',
											icon: 'none'
										});
									},
									complete() {
										console.log(that.essayAns);
									}
								});
							};
						});
					});
					//#endif
				},
				fail: function(res) {
					uni.showToast({
						title: '调用失败',
						icon: 'none'
					});
					that.needRefresh = true;
				}
			});
		},
		//播放问题中的音频
		playQuesttionAudio(e) {
			var that = this;
			console.log(this.played);
			//如果播放中，那么不响应
			if (this.played == false) {
				innerAudioContext.autoplay = true;
				innerAudioContext.src = that.topicInfo.questionList[e.currentTarget.dataset.newsid].audioUrl;
				innerAudioContext.onPlay(() => {
					uni.showToast({
						title: '开始播放',
						icon: 'none'
					});
					that.played = true;
				});
				innerAudioContext.onWaiting(function() {
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					});
				});
				innerAudioContext.onError(res => {
					uni.showToast({
						title: '播放错误' + res.errCode + ':' + res.errMsg
					});
					that.played = false;
				});
				innerAudioContext.onEnded(res => {
					uni.showToast({
						title: '播放完成',
						icon: 'none'
					});
					that.played = false;
				});
				innerAudioContext.onStop(function() {
					that.played = false;
				});
			}
		},
		//提交学生答案
		submit() {
			var that = this;
			var stuAns = new Array(this.topicInfo.questionList.length);
			switch (this.topicInfo.topicType) {
				//单选题
				case 0:
					stuAns = this.singleAns;
					stuAns = Util.translateArray(stuAns);
					break;
				//多选题
				case 1:
					stuAns = this.multipleAns;
					for (var i = 0; i < stuAns.length; i++) {
						var temp = '';
						for (var j = 0; j < stuAns[i].length; j++) {
							temp += stuAns[i][j];
						}
						stuAns[i] = temp;
					}
					stuAns = Util.translateArray(stuAns);
					break;
				//填空题
				case 2:
					stuAns = this.blankAns;
					break;
				case 3:
					stuAns = this.writeAns;
					break;
				//作文题
				case 4:
					stuAns = this.essayAns;
					break;
				default:
					break;
			}
			//正确答案
			var rightAns = new Array(this.topicInfo.questionList.length);
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				rightAns[i] = this.topicInfo.questionList[i].correctAnswer;
			}
			//detailId数组
			var detailId = new Array(this.topicInfo.questionList.length);
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				detailId[i] = this.topicInfo.questionList[i].id;
			}
			console.log('学生答案:' + stuAns.toString());
			console.log('正确答案:' + rightAns.toString());
			console.log('问题ID:' + detailId.toString());
			uni.showLoading({
				title: '提交中...',
				mask: true
			});
			uni.request({
				url: ApiManager.submitTestAnswer,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					testId: parseInt(that.testId),
					topicId: parseInt(that.topicInfo.topicId),
					answer: stuAns,
					correctAns: rightAns,
					detailId: detailId
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
						return false;
					} else {
						return true;
					}
				},
				fail: () => {
					uni.showToast({
						title: '提交失败',
						icon: 'none'
					});
					return false;
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #ffffff;
}
.fab {
	position: fixed;
	bottom: 0;
	left: 0;
	z-index: 500;
	padding: 20rpx;
}
.drawer_sheet_child {
	width: 50rpx;
	height: 50rpx;
	margin: 15rpx;
	background-color: #e5e5e5;
	text-align: center;
}
.drawer_sheet_child_current {
	width: 50rpx;
	height: 50rpx;
	margin: 15rpx;
	background-color: #dd4037;
	text-align: center;
}
.test_class {
	height: auto;
	padding-bottom: 130rpx;
	padding-left: 20rpx;
	padding-right: 20rpx;
}
.uni-list-cell {
	justify-content: flex-start;
}
.question_input {
	height: 50rpx;
	padding: 15rpx 25rpx;
	line-height: 50rpx;
	font-size: 28rpx;
	flex: 1;
	background: #e5e5e5;
}
.swiper {
}
.imgs {
	margin-top: 20rpx;
	width: 100%;
	height: 500rpx;
	display: flex;
	margin: 0 auto;
	flex-wrap: wrap;
	background-color: #f8f8f8;
}
.imgs img {
	width: 100%;
	height: 100%;
}
.choose_button {
	color: #ffffff;
	margin: 10rpx;
	background-color: #dd4037;
}
.submit_class {
	text-align: center;
	font-size: 30rpx;
	padding: 10rpx;
	font-weight: bolder;
}
</style>
