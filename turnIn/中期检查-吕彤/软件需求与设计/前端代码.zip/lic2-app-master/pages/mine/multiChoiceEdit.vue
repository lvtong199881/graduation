<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view slot="right" @click="submit()">提交</view>
		</NavBar>
		<view style="margin-top: 20rpx;background-color: #FFFFFF;">
			<checkbox-group @change="checkboxChange">
				<label class="uni-list-cell uni-list-cell-pd" v-for="item in multiList" :key="item.value">
					<view><checkbox color="#DD4037" :value="item.value" :checked="item.checked" /></view>
					<view>{{ item.name }}</view>
				</label>
			</checkbox-group>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '',
			placeholder: ',',
			inputValue: '',
			multiList: [],
			checkedList: [],
			pageInfo: {
				pageId: 1,
				pageName: ''
			}
		};
	},
	onLoad: function(e) {
		this.pageInfo.pageId = e.pageId;
		this.pageInfo.pageName = e.pageName;
		this.title = '选择' + e.pageName;
		if (e.pageId == 5) {
			//获取兴趣爱好列表
			uni.request({
				url: ApiManager.getHobbyList,
				method: 'GET',
				data: {},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.multiList = content.hobbyList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
		} else {
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		checkboxChange: function(e) {
			var items = this.multiList,
				values = e.detail.value;
			for (var i = 0, lenI = items.length; i < lenI; ++i) {
				const item = items[i];
				if (values.includes(item.value)) {
					this.$set(item, 'checked', true);
				} else {
					this.$set(item, 'checked', false);
				}
			}
		},
		submit() {
			if (this.pageInfo.pageId == 5) {
				this.checkedList = [];
				this.multiList.forEach(item => {
					if (item.checked == true) {
						this.checkedList.push(item);
					}
				});
				uni.request({
					url: ApiManager.changeHobbies,
					method: 'POST',
					data: {
						studentNumber:getApp().globalData.studentInfo.studentNumber,
						hobbyList:this.checkedList
					},
					success: res => {
						var errorCode = res.data.errorCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '修改成功',
								icon: 'none'
							});
							uni.navigateBack({
								delta: 1
							});
						}
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
</style>
