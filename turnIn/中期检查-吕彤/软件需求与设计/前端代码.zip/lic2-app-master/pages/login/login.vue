<template>
	<view class="common-content" style="background-image: url('../../static/bg_login.png');background-size: 100% 100%;">
		<view class="uni-flex uni-column inputPart" style="padding-top: 200rpx; padding-left: 20rpx;padding-right: 20rpx;">
			<image style="width: 100%;" src="../../static/login_logo_03.png" mode="widthFix"></image>
			<view class="uni-flex uni-column input_part">
				<text style="color: #666666;font-size: 26rpx;">学号/工号</text>
				<input placeholder="请输入账号" placeholder-class="input_placeholder" v-model="userName" class="uni-input" @input="onKeyUserNameInput" />
				<view class="common-divider-line"></view>
				<text style="color: #666666;font-size: 26rpx;">密码</text>
				<input password placeholder="请输入密码" placeholder-class="input_placeholder" class="uni-input" v-model="password" @input="onKeyUserPasswordInput" />
				<view class="common-divider-line"></view>
			</view>
			<button class="button_login" @click="goToLogin()">登录</button>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		formItem
	},
	data() {
		return {
				userName: '',
				password: ''
		};
	},
	methods: {
		onKeyUserNameInput: function(event) {
			this.userName = event.target.value;
		},
		onKeyUserPasswordInput: function(event) {
			this.password = event.target.value;
		},
		goToLogin() {
			if (this.userName == '') {
				uni.showModal({
					title: '登录失败',
					content: '账号不能为空',
					showCancel: false
				});
			} else if (this.password == '') {
				uni.showModal({
					title: '登录失败',
					content: '密码不能为空',
					showCancel: false
				});
			}else{
				uni.request({
					url: ApiManager.login,
					method: 'POST',
					data: {
						studentNumber:this.userName,
						studentPassword:this.password
					},
					success: res => {
						var errorCode = res.data.errorCode;
						var errorMsg = res.data.errorMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else{
							getApp().globalData.studentInfo.studentNumber = this.userName;
							uni.reLaunch({
								url:'../mine/mine',
								fail: () => {
									uni.showToast({
										title: '不知道为啥,登录失败了',
										icon: 'none'
									});
								}
							})
						}
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.button_login {
	width: 100%;
	font-size: 30rpx;
	color: #ffffff;
	padding: 10rpx;
	background-color: #dd4037;
}
.input_placeholder {
	color: #000000;
	font-size: 30rpx;
}
.input_part {
	background-color: #ffffff;
	padding: 20rpx;
	margin-bottom: 20rpx;
	border-radius: 10rpx;
}
</style>
