<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view slot="right">
				<text style="margin-right: 20rpx;" @click="submit()">提交</text>
				<text @click="getAnswer()">答案</text>
			</view>
		</NavBar>

		<!--题目内容-->
		<view style="padding: 20rpx;background-color: #FFFFFF;">
			<view class="uni-flex uni-column topic_info_part">
				<!-- <text>topicId：{{ topicInfo.topicId }}</text> -->
				<text>题目名称:{{ topicInfo.topicName }}</text>
				<text>{{ topicInfo.topicDesc }}</text>
				<!-- <text>topicType:{{ topicInfo.topicType }}</text> -->
				<text>题型:{{ topicInfo.topicTypeString }}</text>
				<text>题目难度:简单</text>
				<!--图片-->
				<swiper v-if="topicInfo.topicImaUrl != null" class="swiper" indicator-dots="true" autoplay="true" interval="5000" duration="1000">
					<swiper-item v-for="(item, index) in topicInfo.topicImaUrl" :key="index"><image :src="topicInfo.topicImaUrl[index]" mode="widthFix"></image></swiper-item>
				</swiper>
				<!--音频-->
				<view>
					<uniIcons
						style="margin-right: 20rpx;"
						v-for="(item, index) in topicInfo.topicAudioUrl"
						:key="index"
						type="sound"
						color="#DD4037"
						size="30"
						@click="playTopicAudio"
					></uniIcons>
				</view>
			</view>
			<!--问题-单选题-->
			<view v-if="topicInfo.topicType == 0" hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id">
				<view class="question">
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<radio-group @change="radioChange">
						<label class="uni-list-cell uni-list-cell-pd" v-for="item in item.optionList" :key="item.value">
							<view><radio :value="item.value" :checked="item.checked" /></view>
							<view>{{ item.name }}</view>
						</label>
					</radio-group>
				</view>
			</view>
			<!--问题-多选题-->
			<view v-if="topicInfo.topicType == 1" hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id">
				<view class="question">
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<checkbox-group @change="checkboxChange">
						<label class="uni-list-cell uni-list-cell-pd" v-for="item in item.optionList" :key="item.value">
							<view><checkbox :value="item.value" :checked="item.checked" /></view>
							<view>{{ item.name }}</view>
						</label>
					</checkbox-group>
				</view>
			</view>
			<!--问题-填空题-->
			<view v-if="topicInfo.topicType == 2" hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.questionList" :key="index">
				<view class="question">
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<input class="question_input" placeholder="输入答案" />
				</view>
			</view>
			<!--问题-写汉字题-->
			<view v-if="topicInfo.topicType == 3" hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id">
				<view class="question">
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<WritingArea></WritingArea>
				</view>
			</view>
			<!--问题-作文题-->
			<view v-if="topicInfo.topicType == 4" hover-class="uni-list-cell-hover" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id">
				<view class="question">
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<image src="../../static/1.png"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import WritingArea from '../../components/diy/writingArea';
export default {
	components: {
		NavBar,
		uniIcons,
		WritingArea
	},
	data() {
		return {
			singleAns:[],
			topicInfo: {},
			title: '题目详情',
			showAnswer: true,
			topicInfos: {
				topicId: 1,
				topicName: '题目名称',
				topicDesc:
					'题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干题干',
				topicType: 1,
				topicTypeString: '',
				topicDifficultType: '中等',
				topicImaUrl: [],
				questionList: [
					{
						questionId: 1,
						questionDesc: '问题题干',
						optionList: [
							{
								value: 'A',
								name: '选项A内容'
							},
							{
								value: 'B',
								name: '选项B内容'
							},
							{
								value: 'C',
								name: '选项C内容'
							},
							{
								value: 'D',
								name: '选项D内容'
							}
						]
					}
				]
			}
		};
	},
	onLoad: function(e) {
		console.log(e);
		uni.request({
			url: ApiManager.getTopicDetail,
			method: 'POST',
			data: {
				topicId: e.topicId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.topicInfo = content;
				}
			},
			fail: () => {},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		getAnswer() {
			var rightAns=[];
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				rightAns[i]=this.topicInfo.questionList[i].correctAnswer;
			}
			uni.showModal({
				title: '正确答案',
				content: '正确答案：'+rightAns.toString(),
				showCancel: true,
				success: res => {},
				fail: () => {},
				complete: () => {},
				fail: () => {},
				complete: () => {}
			});
		},
		submit() {
			if(this.topicInfo.topicType==0){
				var rightAns=[];
				for (var i = 0; i < this.topicInfo.questionList.length; i++) {
					rightAns[i]=this.topicInfo.questionList[i].correctAnswer;
				}
			}
			uni.showModal({
				title: '再接再厉',
				content: '你的答案：A,A\n'+'正确答案：'+rightAns.toString(),
				showCancel: true,
				success: res => {},
				fail: () => {},
				complete: () => {
					uni.showModal({
						title: '推荐试题',
						content: '技术是人类用来解决自身...',
						showCancel: true,
						success: res => {
							if(res.confirm){
								uni.navigateTo({
									url: './topicDetail?topicId=' + '0',
									success: res => {},
									fail: () => {},
									complete: () => {}
								});
							}
						},
						fail: () => {},
						complete: () => {}
					});
				}
			});
		},
		checkboxChange: function(e) {
			var items = this.items,
				values = e.detail.value;
			for (var i = 0, lenI = items.length; i < lenI; ++i) {
				const item = items[i];
				if (values.includes(item.value)) {
					this.yourAns[e.index]=A;
					this.$set(item, 'checked', true);
				} else {
					this.$set(item, 'checked', false);
				}
			}
		},
		radioChange: function(e) {
			var items =[];
			var values = e.detail.value;
			items = this.items;
			for (var i = 0; i < items.length; ++i) {
				const item = items[i];
				if (values.includes(item.value)) {
					this.$set(item, 'checked', true);
				} else {
					this.$set(item, 'checked', false);
				}
			}
		},
		playTopicAudio() {}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
.topic_info_part {
	background-color: #ffffff;
}
.question {
	background-color: #ffffff;
	margin-top: 20rpx;
}
.question_input {
	height: 50rpx;
	padding: 15rpx 25rpx;
	line-height: 50rpx;
	font-size: 28rpx;
	flex: 1;
	background: #eeeeee;
}
</style>
