<template>
	<view class="common-content-auto" style="background-color: #FFFFFF;">
		<NavBar left-icon="arrowleft" title="错题本" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<view v-for="(item, index) in topicList" :key="index" @tap="openinfo" :data-newsid="item.topicId">
				<topicItem
					:topicId="item.topicId"
					:topicName="item.topicName"
					:topicKnowledgePoint="item.knowledgePoint"
					showCollect
					showId
					@collect="tryCollect(index)"
					@uncollect="tryUnCollect(index)"
				></topicItem>
			</view>
		</view>
		<view v-if="showLoadMore" class="common-divider-line"></view>
		<uniLoadMore v-if="showLoadMore" :status="status" @clickLoadMore="clickLoadMore"></uniLoadMore>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import uniLoadMore from '../../components/uni-load-more/uni-load-more.vue';
export default {
	components: {
		topicItem,
		NavBar,
		uniLoadMore
	},
	data() {
		return {
			rawData: [],
			topicList: [],
			status: 'more',
			showLoadMore: false
		};
	},
	onLoad: function() {
		this.getWrongBookTopicList();
	},
	onPullDownRefresh() {
		this.getWrongBookTopicList();
		setTimeout(function() {
			uni.stopPullDownRefresh();
		}, 1000);
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		//点击加载更多
		clickLoadMore(e) {
			var that = this;
			if (that.topicList.length >= that.rawData.length) {
				//临时列表大小等于原始数据，无更多数据
				that.status = 'noMore';
			} else {
				//临时列表小于原始数据，concat连接数组
				that.topicList = that.topicList.concat(that.rawData.slice(that.topicList.length, that.topicList.length + 10));
			}
		},
		getWrongBookTopicList() {
			var that = this;
			uni.showLoading({
				title: '加载中....'
			});
			uni.request({
				url: ApiManager.getWrongBookTopic,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.hideLoading();
							that.rawData = content;
							if (that.rawData != null && that.rawData.length != 0) {
								//如果原始数据不为空，则显示加载更多
								that.showLoadMore = true;
								that.topicList = that.rawData.slice(0, 10);
							}
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		openinfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.load_more_class {
	padding: 20rpx;
	background-color: #ffffff;
	color: #999999;
	text-align: center;
}
</style>
