//全局变量
const version = "1.0.1";
// const now = Date.now || function() {
// 	return new Date().getTime();
// };


export default {
	// now,
	version
}
