<template name="formItem">
	<view>
		<view class="form-item">
			<view class="uni-flex uni-row">
				<view style="display: flex; align-items: center;width: 300rpx;">
					<image v-if="showIcon" class="item_image" v-bind:src="labelIconRes" mode="aspectFill"></image>
					<text :style="{ color: textColor }" class="text_label">{{ labelText }}</text>
				</view>
				<text class="text_value" style="-webkit-flex: 1;flex: 1;">{{ value }}</text>
				<view v-if="showBadge" class="badge">
					<text class="badge_text">{{ badge_text }}</text>
				</view>
				<image v-if="showEditIcon" class="image_icon" src="/static/arrow_right.png" mode="aspectFill"></image>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	props: {
		showDivider: {
			type: [Boolean, String],
			default: true
		},
		showIcon: {
			type: [Boolean, String],
			default: false
		},
		labelText: {
			type: String,
			default: 'label'
		},
		value: {
			type: String,
			default: ''
		},
		showEditIcon: {
			type: [Boolean, String],
			default: false
		},
		labelIconRes: {
			type: String,
			default: '/static/logo.png'
		},
		showBadge: {
			type: [Boolean, String],
			default: false
		},
		badge_text: {
			type: String,
			default: ''
		},
		iconSize: {
			type: String,
			default: '52rpx'
		},
		textColor: {
			type: String,
			default: '#000000'
		}
	},
	methods: {}
};
</script>

<style>
.item_image {
	width: 60rpx;
	height: 60rpx;
	margin-right: 20rpx;
}
.text_label {
	font-size: 28rpx;
	justify-content: flex-start;
}
.text_value {
	justify-content: flex-end;
	text-align: right;
	font-size: 28rpx;
}
.image_icon {
	width: 30rpx;
	height: 30rpx;
	padding: 10rpx;
	align-items: center;
}
.form-item {
	padding-top: 24rpx;
	padding-bottom: 24rpx;
	padding-left: 20rpx;
	padding-right: 20rpx;
	background: #FFFFFF;
}
.badge {
	display: flex;
	align-items: center;
}
.badge_text {
	color: #ffffff;
	min-width: 30rpx;
	font-size: 20rpx;
	text-align: center;
	background-color: #dd524d;
	border-radius: 20rpx;
	padding-left: 5rpx;
	padding-right: 5rpx;
}
</style>
