<template>
	<view class="common-content-auto">
		<view class="status_bar"><!-- 这里是状态栏 --></view>
		<!--带课程选择的导航栏-->
		<view class="uni-flex" style="height: 44px; background-color: #DD4037;">
			<view style="background-color: #DD4037;padding-left: 20rpx;">
				<picker @change="bindPickerChange" :value="index" :range="courseList" range-key="courseName">
					<text class="picker_view">{{ courseList[index].courseName }}</text>
					<uniIcons type="arrowdown" color="#ffffff" size="24"></uniIcons>
				</picker>
			</view>
			<view style="display: flex; flex: 1; align-items: center;background: #DD4037;text-align: center;justify-content: center;">
				<text style="color: #FFFFFF;font-size: 32rpx;padding-right: 150rpx;">{{ title }}</text>
			</view>
		</view>
		<!-- 四大子功能-->
		<view class="uni-flex uni-row" style="background-color: #FFFFFF;padding: 0rpx 10rpx 0rpx 10rpx;">
			<!-- 搜索出题-->
			<view hover-class="hover_class" class="uni-flex uni-column sub_class" @click="gotoSearch()">
				<image v-bind:src="subFeaturesArray[0].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[0].text }}</text>
			</view>
			<!-- 知识点出题-->
			<view hover-class="hover_class" class="uni-flex uni-column sub_class" @click="gotoKnowledgePointSearch()">
				<image v-bind:src="subFeaturesArray[1].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[1].text }}</text>
			</view>
			<!-- 随机出题-->
			<view hover-class="hover_class" class="uni-flex uni-column sub_class" @click="gotoRandom()">
				<image v-bind:src="subFeaturesArray[2].iconRes" class="sub_image_class" mode="aspectFit"></image>
				<text style="width: 100%;">{{ subFeaturesArray[2].text }}</text>
			</view>
		</view>
		<!--推荐题目-->
		<view class="uni-flex uni-column">
			<view style="padding: 20rpx;font-weight: bold;">智能推荐</view>
			<view v-for="(item, index) in recommendArray" @click="openinfo" :key="index" :data-newsid="item.topicId">
				<topicItem
					style="-webkit-flex: 1;flex: 1;"
					topicUrl="../../static/ic_topic.png"
					:topicId="item.topicId"
					:topicName="item.topicName"
					:topicKnowledgePoint="item.knowledgePoint"
					showCollect
					@collect="tryCollect(index)"
					@uncollect="tryUnCollect(index)"
				></topicItem>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import topicItem from '../../components/diy/topicItem.vue';
import uniSection from '../../components/uni-section/uni-section.vue';
export default {
	components: {
		uniIcons,
		topicItem,
		uniSection
	},
	data() {
		return {
			title: '发现',
			index: 0,
			courseList: [{ courseId: -1, courseName: '暂无数据' }],
			subFeaturesArray: [
				{
					id: 1,
					text: '搜索出题',
					iconRes: '../../static/find_search.png'
				},
				{
					id: 2,
					text: '知识点出题',
					iconRes: '../../static/find_knowledge_point.png'
				},
				{
					id: 3,
					text: '随机出题',
					iconRes: '../../static/find_random_search.png'
				},
				{
					id: 4,
					text: '智能组卷',
					iconRes: '../../static/find_ai_test.png'
				}
			],
			recommendArray: []
		};
	},
	onLoad() {
		var that = this;
		uni.showLoading({
			title: '加载中...',
			mask: true
		});
		uni.request({
			url: ApiManager.getCourseList,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.hideLoading();
						this.courseList = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	onShow() {
		var that = this;
		uni.request({
			url: ApiManager.getRecommendTopic,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.hideLoading();
						that.recommendArray = content;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		bindPickerChange: function(e) {
			this.index = e.target.value;
			console.log(this.index);
			console.log(this.courseList[this.index].courseId);
			console.log(this.courseList[this.index].courseName);
		},
		gotoSearch() {
			uni.navigateTo({
				url: './onlySearch?courseId=' + this.courseList[this.index].courseId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoKnowledgePointSearch() {
			uni.navigateTo({
				url: './kPointSortOne',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoRandom() {
			uni.navigateTo({
				url: './randomSearch?courseId=' + this.courseList[this.index].courseId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openinfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.sub_class {
	justify-content: center;
	align-items: center;
	flex: 1;
	width: 100%;
	padding-bottom: 20rpx;
	text-align: center;
	font-size: 28rpx;
	font-weight: bold;
	border-radius: 20rpx;
	border-style: solid;
	background-color: #f8f8f8;
	border-width: thin;
	border-color: #f8f8f8;
	margin: 20rpx 10rpx 20rpx 10rpx;
}
.sub_image_class {
	width: 80rpx;
	height: 80rpx;
	padding: 20rpx;
}
.recommend_label {
	margin: 10rpx 20rpx 10rpx 20rpx;
}
.picker_view {
	color: #ffffff;
}
.collect_icon {
	width: 52rpx;
	height: 52rpx;
}
.hover_class {
	background-color: #dd4037;
}
</style>
