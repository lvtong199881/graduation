<template>
	<view class="paper_content">
		<NavBar :title="title" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view class="uni-flex uni-row" slot="left">
				<uniIcons type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
				<uniIcons :type="collectType" color="#ffffff" size="24" @click="tryCollectOrNot"></uniIcons>
			</view>
		</NavBar>
		<button class="start_test_button" :style="{ width: screenWidth - 20 + 'px' }" @click="gotoStartTest()">{{ button_text }}</button>
		<!--成绩部分-->
		<view class="grade_part">
			<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
				<view>
					<image style="width: 30rpx;height: 30rpx;" src="../../static/ic_time.png"></image>
					<text>{{ durtion }}分钟</text>
				</view>
				<view>
					<image style="width: 30rpx;height: 30rpx;" src="../../static/ic_total_score.png"></image>
					<text>{{ totalScore }}分</text>
				</view>
			</view>
			<view v-if="showGrade == 1" style="display: flex;align-items: center;justify-content: center;">
				<view class="grade_text_class">{{ grade }}分</view>
			</view>
		</view>
		<!--试卷内容-->
		<view v-if="partList != null && partList.length != 0" class="test_content common-card">
			<view class="uni-flex uni-column" v-for="(item, index) in partList" :key="index">
				<view class="uni-flex uni-column">
					<view class="uni-flex uni-row test_part">
						<text style="padding-right: 20rpx;flex: 1;font-weight: bold;">{{ item.partName }}</text>
						<text style="padding-right: 20rpx;font-weight: bold;">{{ item.topicNumber }}题</text>
						<text style="padding-right: 20rpx;font-weight: bold;">总分:{{ item.partTotalScore }}</text>
					</view>
					<view v-for="(item, index) in item.subPartList" :key="index">
						<view style="padding-left: 20rpx;">
							<view class="uni-flex uni-row">
								<text style="flex:1">序号：{{ index + 1 }}</text>
								<text style="flex:1">题号：{{ item.subTopicNumber }}</text>
								<text style="flex:1">分数:{{ item.subPartTotalScore }}</text>
								<text v-if="showGrade == 1" style="flex:1">得分:{{ item.subGrade }}</text>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '试卷详情',
			testId: -1,
			button_text: '开始做题',
			durtion: -1,
			totalScore: -1,
			grade: -1,
			showGrade: -1,
			partList: [],
			screenHeight: -1,
			screenWidth: -1,
			collectType: 'star',
			lastClickTime: -1,
			stateCode: 0
		};
	},
	onLoad: function(e) {
		var that = this;
		//获取屏幕高度
		uni.getSystemInfo({
			success: res => {
				this.screenHeight = res.screenHeight;
				this.screenWidth = res.screenWidth;
				console.log('页面高度=' + this.screenHeight);
				console.log('页面宽度=' + this.screenWidth);
			}
		});
		this.testId = e.testId;
		console.log('考试ID=' + this.testId);
		this.title = e.pageName == null || e.pageName == '' ? this.title : e.pageName;
		console.log(this.title);
	},
	onShow() {
		this.refreshData();
	},
	onBackPress() {
		if (this.title != '试卷详情') {
			uni.switchTab({
				url: '../home/home'
			});
			return true;
		}
	},
	methods: {
		back() {
			//#ifdef MP-WEIXIN
			if (this.title != '试卷详情') {
				uni.switchTab({
					url: '../home/home'
				});
			}else {
				uni.navigateBack({
					delta: 1
				});
			}
			//#endif
			//#ifndef MP-WEIXIN
			uni.navigateBack({
				delta: 1
			});
			//#endif
		},
		refreshData() {
			var that = this;
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			uni.request({
				url: ApiManager.getTestDetail,
				method: 'POST',
				data: {
					testId: parseInt(this.testId),
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功'
						});
						this.durtion = content.durtion;
						this.totalScore = content.totalScore;
						this.grade = content.grade;
						this.partList = content.partList;
						this.showGrade = content.showGrade;
						this.stateCode = content.stateCode;
						if (this.stateCode == 0) {
							this.button_text = '考试未开始';
						} else if (this.stateCode == 2) {
							this.button_text = '查看答案';
						} else if (this.stateCode == 1) {
							this.button_text = this.showGrade == 0 ? '开始做题' : '查看答案';
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
					setTimeout(function() {
						that.back();
					}, 1000);
				},
				complete: () => {}
			});
		},
		tryCollectOrNot() {
			//快速点击拦截
			var thisClickTime = new Date().getTime();
			// console.log(thisClickTime.toString());
			if (this.lastClickTime != -1 && thisClickTime - this.lastClickTime < 800) {
				// console.log("点击太快");
				return;
			}
			this.lastClickTime = thisClickTime;
			if (this.collectType == 'star') {
				this.collect();
			} else {
				this.unCollect();
			}
		},
		collect() {
			uni.request({
				url: ApiManager.collect,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					testId: parseInt(this.testId),
					topicId: -1
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '收藏成功',
							icon: 'none'
						});
						this.collectType = 'star-filled';
					}
				},
				fail: () => {
					uni.showToast({
						title: '收藏失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		unCollect() {
			uni.request({
				url: ApiManager.unCollect,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					testId: parseInt(this.testId)
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '取消收藏成功',
							icon: 'none'
						});
						this.collectType = 'star';
					}
				},
				fail: () => {
					uni.showToast({
						title: '取消收藏失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		gotoStartTest() {
			if (this.stateCode == 0) {
				uni.showToast({
					title: '当前考试未开始',
					icon: 'none'
				});
			} else if (this.stateCode == 1) {
				//考试进行中
				if (this.showGrade == 1) {
					//已经交卷
					uni.navigateTo({
						url: './testTopicList?testId=' + this.testId,
						success: res => {},
						fail: () => {},
						complete: () => {}
					});
				} else {
					//没交卷
					uni.showModal({
						title: '提示',
						content: '确定要开始考试吗？',
						showCancel: true,
						cancelText: '取消',
						cancelColor: '#999999',
						confirmText: '确定',
						confirmColor: '#DD4037',
						success: res => {
							if (res.confirm) {
								uni.navigateTo({
									url: './testTopicDetail?testId=' + this.testId,
									success: res => {},
									fail: () => {},
									complete: () => {}
								});
							}
						},
						fail: () => {},
						complete: () => {}
					});
				}
			} else if (this.stateCode == 2) {
				//考试已结束
				uni.navigateTo({
					url: './testTopicList?testId=' + this.testId,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			} else {
				uni.navigateTo({
					url: './testTopicDetail?testId=' + this.testId,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.grade_part {
	padding: 20rpx;
	margin: 20rpx;
	background-color: #ffffff;
	border-radius: 10rpx;
}
.grade_text_class {
	text-align: center;
	color: #dd4037;
	font-size: 52rpx;
	border-radius: 100%;
	border-style: solid;
	background-color: #ffffff;
	border-width: thin;
	border-color: #dd4037;
	padding: 40rpx;
	margin-right: 10rpx;
}
.test_content {
	padding: 20rpx;
	margin: 20rpx;
}
.start_test_button {
	background-color: #dd4037;
	margin: 20rpx;
	color: #ffffff;
	position: fixed;
	bottom: 0;
	left: 0;
	z-index: 500;
}
.test_part {
	background-color: #f8f8f8;
	border-radius: 10rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
}
.paper_content {
	background-color: #f8f8f8;
	height: auto;
	margin-bottom: 100rpx;
}
.icon_collect {
	width: 52rpx;
	height: 52rpx;
}
</style>
