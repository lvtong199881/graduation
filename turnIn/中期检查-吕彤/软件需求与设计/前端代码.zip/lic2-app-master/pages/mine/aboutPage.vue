<template>
	<view class="common-content" style="display: flex;align-items: center;flex-direction: column;">
		<NavBar left-icon="arrowleft" title="关于" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="main uni-flex uni-column" style="margin-top: 200rpx;">
			<image src="../../static/login_logo_03.png" mode="widthFix" style="background-color: #DD4037;"></image>
			<text class="text">当前版本：<text class="code">{{gd.version}}</text> </text>
			<text class="text">《学在华大》华文智能教学辅助系统</text>
			<text class="text">华大智语团队出品</text>
		</view>
		
		<text></text>
	</view>
	
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			gd:{}
		};
	},
	onShow() {
		this.gd = getApp().globalData
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		}
	}
};
</script>

<style>
.image {
	width: 100%;
}
.main{
	padding: 30rpx;
	flex-direction: column;
	justify-content: center;
}
.text{
	text-align: center;
}
.code{
	color: #DD4037;
}
</style>
