<template>
	<view class="common-content">
		<view class="status_bar"><!-- 这里是状态栏 --></view>
		<view class="uni-flex uni-row personalInfo" @click="gotoPersonalInfo()">
			<image v-if='avatarIcon' class="student_avatar" v-bind:src="avatarIcon" @click.stop="openAvatar"></image>
						<image v-else class="student_avatar" src="../../static/student_avatar.png" @click.stop="openAvatar"></image>
			<view style="-webkit-flex: 1;flex: 1;margin: 20rpx;width: 0;">
				<view class="stuedent_data">{{ name }}</view>
				<view class="stuedent_data">{{ number }}</view>
				<view class="stuedent_data">{{ className }}</view>
			</view>
			<image class="student_analysis" src="../../static/student_analysis.png" mode="aspectFill" @click.stop="gotoAnalysis()"></image>
		</view>
		<view class="common-divider-line"></view>
		<view style="margin-top: 20rpx;">
			<formItem showIcon="true" labelText="我做过的" labelIconRes="../../static/mine_question_done.png" showClick="true" @click.native="gotoQuestionDone()"></formItem>
			<formItem showIcon="true" labelText="收藏" labelIconRes="../../static/mine_collection.png" showClick="true" @click.native="gotoCollection()"></formItem>
			<formItem showIcon="true" labelText="错题本" labelIconRes="../../static/mine_wrong_book.png" showClick="true" @click.native="gotoWrongBook()"></formItem>
			<formItem showIcon="true" labelText="识字量在线测试" labelIconRes="../../static/mine_word_test.png" showClick="true" @click.native="gotoWordTest()"></formItem>
			<view style="margin-top: 20rpx;">
				<formItem showIcon="true" labelText="设置" labelIconRes="../../static/mine_settings.png" showClick="true" @click.native="gotoSettings()"></formItem>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		formItem
	},
	data() {
		return {
			analysisIcon: '../../static/student_analysis.png',
			avatarIcon: '../../static/student_avatar.png',
			name: '暂无数据',
			number: '暂无数据',
			className: '暂无数据'
		};
	},
	onShow: function(e) {
		//请求接口获取用户基本信息
		uni.request({
			url: ApiManager.getStudentInfo,
			method: 'POST',
			data: {
				studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
			},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.avatarIcon = content.avatar;
						this.number = content.number;
						this.name = content.name;
						this.className = content.className;
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	methods: {
		gotoAnalysis() {
			//跳转到学生分析页
			uni.navigateTo({
				url: './analysis',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoPersonalInfo() {
			//跳转到个人信息页
			uni.navigateTo({
				url: './personalInfo',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoQuestionDone() {
			//跳转到我做过的页
			uni.navigateTo({
				url: './mineDone',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoCollection() {
			//跳转到收藏页
			uni.navigateTo({
				url: './collection',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoWrongBook() {
			//跳转到错题本页
			uni.navigateTo({
				url: './wrongBook',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoWordTest() {
			//跳转到识字量在线测试页
			uni.navigateTo({
				url: './wordTest',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoSettings() {
			//跳转到设置页
			uni.navigateTo({
				url: './settings',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openAvatar() {
			uni.previewImage({
				urls: [this.avatarIcon],
				fail: function(err) {
					uni.showToast({
						title: err.errMsg,
						icon: 'none'
					});
				}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.personalInfo {
	padding: 80rpx 20rpx 80rpx 20rpx;
	background-color: #dd4037;
	align-items: center;
}
.student_avatar {
	width: 150rpx;
	height: 150rpx;
	background-color: rgba(248, 248, 248, 0.3);
	border-radius: 20rpx;
}
.stuedent_data {
	color: #ffffff;
}
.student_analysis {
	width: 80rpx;
	height: 80rpx;
}
</style>
