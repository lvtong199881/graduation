//识字量在线测试百分数计算，保留两位小数
function formatPercent(dividend, divisor) {
	if (typeof divisor != 'number' || divisor == 0 || typeof divisor != 'number' || divisor == 0) {
		return "0.00%"
	}
	return (dividend * 100 / divisor).toFixed(2) + "%";
}
//手机号合法性判断
function checkPhone(phone) {
	return RegExp(/^1[34578]\d{9}$/).test(phone);
}
//提交答案数据转换
function translateArray(AnswerArray) {
	var tempArray = AnswerArray;
	if (Array.isArray(AnswerArray)) {
		tempArray = AnswerArray.map(function(value, index) {
			if (value != null) {
				value = value.replace('0', 'A').replace('1', 'B').replace('2', 'C').replace('3', 'D');
			}
			return value
		})
	}
	return tempArray;
}
//版本号对比
function compareVersionId(version1, version2) {
	var a1 = version1.toString().split(".");
	var a2 = version2.toString().split(".");
	for (var n = 0; n < Math.max(a1.length, a2.length); n++) {
		var i = (n < a1.length ? parseInt(a1[n]) : 0);
		var j = (n < a2.length ? parseInt(a2[n]) : 0);
		if (i < j) return false;
		else if (i > j) return true;
	}
	return false;
}

function checkUpdate() {
	//#ifdef APP-PLUS
	uni.request({
		url: ApiManager.getNewVersion,
		data: {},
		success: res => {
			if (res.statusCode != 200) {
				uni.showToast({
					title: res.statusCode + ':' + res.errMsg,
					icon: 'none'
				});
			} else {
				var errorCode = res.data.errCode;
				var errorMsg = res.data.errMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					console.log("服务器版本号:" + content.versionId + "当前版本号:" + plus.runtime.version);
					var result = compareVersionId(content.versionId, plus.runtime.version);
					console.log("需要更新：" + result);
					if (result) {
						uni.showModal({
							title: '新版本:' + content.versionId,
							content: '版本信息:\n' + content.versionDesc,
							showCancel: false,
							confirmText: '下载新版本',
							confirmColor: '#DD4037',
							success: res => {
								if (res.confirm) {
									//下载
									uni.showLoading({
										title: '下载中...',
										mask: true
									});
									uni.downloadFile({
										url: content.versionUrl,
										success: res => {
											uni.hideLoading();
											if (res.statusCode != 200) {
												uni.showToast({
													title: 'statusCode!=200',
													icon: 'none'
												});
											} else {
												console.log(res.tempFilePath);
												plus.runtime.install(
													res.tempFilePath, {
														force: false
													},
													function() {
														console.log('install success...');
														plus.runtime.restart();
													},
													function(e) {
														console.error('install fail...');
													}
												);
											}
										},
										fail: () => {
											uni.showToast({
												title: '下载失败',
												icon: 'none'
											});
										}
									});
								}
							}
						});
					} else {
						uni.showToast({
							title: '当前已是最新版本',
							icon: 'none'
						});
					}
				}
			}
		}
	});
	//#endif
}
getModuleInfo
//根据模块名称获取模块图片链接
function getModuleInfo(currentModule) {
	console.log("模块名称=" + currentModule);
	if (currentModule.indexOf("读后填空") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAIKXNAOZ.jpg'
	} else if (currentModule.indexOf("句子匹配") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAJE6DXWT.jpg'
	} else if (currentModule.indexOf("作文") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAJXXJADD.jpg'
	} else if (currentModule.indexOf("理解词语") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAKHNO4HE.jpg'
	} else if (currentModule.indexOf("理解短文") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAKWZHMLE.jpg'
	} else if (currentModule.indexOf("听短对话") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAKODKKGG.jpg'
	} else if (currentModule.indexOf("听讲话") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAL5IXKQY.jpg'
	} else if (currentModule.indexOf("听句子") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUALPGYAIK.jpg'
	} else if (currentModule.indexOf("听长对话") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUALETWEZ7.jpg'
	} else if (currentModule.indexOf("完成句子") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUALVSHC5V.jpg'
	} else if (currentModule.indexOf("写汉字") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAMC5JGW8.jpg'
	} else if (currentModule.indexOf("选词填空") != -1) {
		return 'https://licres.luckyzune.com/photo/1TUAMOIZUSD.jpg'
	} else {
		return ''
	}
}
import ApiManager from '../common/api.js';
module.exports = {
	formatPercent: formatPercent,
	checkPhone: checkPhone,
	translateArray: translateArray,
	compareVersionId: compareVersionId,
	checkUpdate: checkUpdate,
	getModuleInfo: getModuleInfo
}
