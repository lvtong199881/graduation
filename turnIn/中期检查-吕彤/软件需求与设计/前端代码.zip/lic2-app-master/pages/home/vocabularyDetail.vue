<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="word_name">{{ detailInfo.name }}</view>
		<formItem labelText="拼音" :value="detailInfo.pinyin"></formItem>
		<formItem labelText="英语翻译" :value="detailInfo.english"></formItem>
		<formItem :labelText="translateString" :value="detailInfo.translation"></formItem>
		<swiper class="swiper" indicator-dots="true" autoplay="true" duration="500">
			<swiper-item v-for="(item, index) in detailInfo.url" :key="index"><image :src="item" mode="aspectFit" style="width: 100%;"></image></swiper-item>
		</swiper>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		NavBar,
		formItem
	},
	data() {
		return {
			title: '',
			swiperHeight: 300, //外部的高度
			index: 0,
			translateString: '',
			detailInfo: {
				id: -1,
				url: [],
				name: '',
				pinyin: '',
				english: '',
				translation: '',
				languageId: -1,
				languageName: ''
			}
		};
	},
	onLoad: function(e) {
		//请求接口获取字词详情信息
		this.detailInfo.id = e.id;
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getVocabularyDetail,
			method: 'POST',
			data: {
				vocabularyId: this.detailInfo.id,
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.detailInfo = content;
					this.title = content.name;
					this.translateString = content.languageName+"翻译";
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		}
	}
};
</script>

<style>
.swiper {
	width: 100%;
	height: 600rpx;
	margin-top: 20rpx;
}
.word_name {
	background-color: #ffffff;
	width: 100%;
	text-align: center;
	font-size: 192rpx;
}
</style>
