<template>
	<view class="common-content">
		<!-- 状态栏 -->
		<view class="status_bar"></view>
		<!--搜索标题栏栏-->
		<view class="uni-flex uni-row">
			<uniIcons style="background-color: #DD4037;" type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
			<view style="background-color: #DD4037;-webkit-flex: 1;flex: 1;"><searchBar bgColor="#dd4037" clearButton="auto" @confirm="search"></searchBar></view>
		</view>
		<!--排序与筛选组件-->
		<sl-filter :independence="true" :color="titleColor" :themeColor="themeColor" :menuList.sync="menuList" @result="result"></sl-filter>
		<!-- 搜索结果-->
		<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.id">
			<topicItem :topicUrl="item.url" :topicName="item.name" :topicKnowledgePoint="item.knowledgePoint" :topicKeyWord="item.keyWord"></topicItem>
		</view>
	</view>
</template>

<script>
import slFilter from '../../components/songlazy-sl-filter/sl-filter/sl-filter.vue';
import searchBar from '../../components/uni-search-bar/uni-search-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		slFilter,
		searchBar,
		topicItem,
		uniIcons
	},
	data() {
		return {
			replaceString:'',
			topicList: [],
			themeColor: '#dd4037',
			titleColor: '#666666',
			filterResult: '',
			menuList: [
				{
					title: '排序',
					isMutiple: true,
					key: 'sort',
					defaultSelectedIndex: [0],
					detailList: [
						{
							title: '不限',
							value: ''
						},
						{
							title: '字母升序',
							value: 'abc_add'
						},
						{
							title: '字母降序',
							value: 'java'
						}
					]
				},
				{
					title: '筛选',
					key: 'select',
					isMutiple: false,
					detailList: [
						{
							title: '不限',
							value: ''
						},
						{
							title: '容易',
							value: '0'
						},
						{
							title: '中等',
							value: '1'
						},
						{
							title: '困难',
							value: '2'
						}
					]
				}
			]
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		result(val) {
			console.log('filter_result:' + JSON.stringify(val));
			this.filterResult = JSON.stringify(val, null, 2);
		},
		openTopicInfo(e) {
			uni.showToast({
				title: e.currentTarget.dataset.newsid,
				icon: 'none'
			});
		},
		search(res) {
			this.replaceString = res.value.replace(' ', '');
			if (this.replaceString == '') {
				uni.showToast({
					title: '搜索内容为空',
					icon: 'none'
				});
			} else {
				uni.showLoading({
					title: '加载中...',
					mask: false
				});
				this.topicList = [
					{
						id: '1',
						name: '11111',
						url: '../../static/ic_topic.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					},
					{
						id: '2',
						name: '22222',
						url: '../../static/find.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					},
					{
						id: '3',
						name: '333333',
						url: '../../static/find_green.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					},
					{
						id: '4',
						name: '44444',
						url: '../../static/find_green.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					},
					{
						id: '4',
						name: '44444',
						url: '../../static/find_green.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					},
					{
						id: '4',
						name: '44444',
						url: '../../static/find_green.png',
						knowledgePoint: '111111',
						keyWord: '1111111'
					}
				];
				uni.hideLoading();
			}
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.viewPage {
	flex: 1;
	font-size: 28rpx;
	background-color: #ffffff;
	border-radius: 0;
}
</style>
