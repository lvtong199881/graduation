<template>
	<view class="common-content">
		<view class="status_bar"><!-- 这里是状态栏 --></view>
		<view class="uni-flex uni-row" style="padding: 20rpx;background-color: #dd4037;">
			<image class="lessons_image" src="../../static/home_lessons.png" mode="aspectFill"></image>
			<view style="display: flex; align-items: center;margin-left: 20rpx;"><text class="lessons_text">课程列表</text></view>
		</view>
		<view class="uni-list" style="margin-top: 20rpx;">
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in courseList" :key="index" @tap="openCourseInfo" :data-newsid="item.courseId">
				<courseItem :labelIconRes="item.courseUrl" :badge_text="item.numberOfRedDots" :labelText="item.courseName" ></courseItem>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import courseItem from '../../components/diy/courseItem.vue';
export default {
	components: {
		courseItem
	},
	data() {
		return {
			courseList: [],
			
		};
	},
	onLoad: function() {
		uni.showLoading({
			title: '加载中....'
		});
uni.request({
			url: ApiManager.getCourseList,
			method: 'POST',
			data: {
				studentNumber:getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.courseList = content.courseList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	methods: {
		openCourseInfo(e){
			uni.navigateTo({
				url: './course?courseId='+e.currentTarget.dataset.newsid,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.lessons_image {
	width: 64rpx;
	height: 64rpx;
}
.lessons_text {
	color: #ffffff;
	font-size: 30rpx;
}
</style>
