<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" title="设置" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<formItem labelText="退出登录" showClick="true" showEditIcon="true" @click.native="trySignOut()" textColor="#dd4037"></formItem>
			<formItem labelText="修改密码" showClick="true" showEditIcon="true" @click.native="gotoChangePassword()" textColor="#dd4037"></formItem>
			<!--  #ifdef APP-PLUS -->
			<formItem labelText="检查新版本" showClick="true" showEditIcon="true" @click.native="checkNewVersion()"></formItem>
			<!--  #endif -->
			<!--  #ifdef MP-WEIXIN -->
			<formItem labelText="下载APP" showClick="true" showEditIcon="true" @click.native="downloadAPP()"></formItem>
			<!--  #endif -->
			<formItem labelText="关于" showClick="true" showEditIcon="true" @click.native="gotoAboutPage()"></formItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import Util from '../../common/util.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		NavBar,
		formItem
	},
	data() {
		return {
			version: '暂无数据'
		};
	},
	onShow() {},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		downloadAPP() {
			uni.request({
				url: ApiManager.getNewVersion,
				data: {},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showModal({
								title: '版本号:' + content.versionId,
								content: '版本信息:\n' + content.versionDesc + '\n下载链接已复制到剪切版！',
								showCancel: false,
								confirmText: '知道了',
								success: res => {},
								fail: () => {},
								complete: () => {
									console.log(content.versionUrl);
									uni.setClipboardData({
									    data: content.versionUrl,
									    success: function () {
									        console.log('success');
									    }
									});
								}
							});
						}
					}
				}
			});
		},
		checkNewVersion() {
			Util.checkUpdate();
		},
		trySignOut() {
			//尝试退出登录
			uni.showModal({
				title: '提示',
				content: '确定要退出登录吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '确定',
				confirmColor: '#DD4037',
				success: function(res) {
					if (res.confirm) {
						uni.reLaunch({
							url: '../login/login',
							success() {},
							fail() {},
							complete() {}
						});
					}
				},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChangePassword() {
			//跳转到修改密码页
			uni.navigateTo({
				url: './changePassword',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoAboutPage() {
			//跳转到关于页
			uni.navigateTo({
				url: './aboutPage',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
