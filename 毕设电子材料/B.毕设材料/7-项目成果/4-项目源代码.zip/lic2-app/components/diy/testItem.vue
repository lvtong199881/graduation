<template>
	<view class="uni-flex uni-column testCard">
		<view class="uni-flex uni-row testInfo">
			<view style="display: flex; align-items: center;"><image v-bind:src="testIconRes" class="test_icon" mode="aspectFill"></image></view>

			<view class="uni-flex uni-column" style="flex: 1;">
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
					<view class="text_name">{{ testName }}</view>
					<view v-if="testState=='进行中'" class="text_red_tag">{{ testState }}</view>
					<view v-else class="text_tag">{{ testState }}</view>
				</view>
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
					<view class="text_time">{{ testTime }}</view>
					<view class="text">{{ testDurtion }}分钟</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	name: 'testItem',
	data() {
		return {
		};
	},
	props: {
		testIconRes: {
			type: String,
			default: '/static/ic_test.png'
		},
		testName: {
			type: String,
			default: '暂无数据'
		},
		testTime: {
			type: String,
			default: '暂无数据'
		},
		testState: {
			type: String,
			default: '进行中'
		},
		testDurtion: {
			type: String,
			default: '暂无数据'
		},
		showDivider: {
			type: Boolean,
			default: true
		}
	},
	methods: {}
};
</script>

<style>
.test_icon {
	width: 80rpx;
	height: 80rpx;
	padding: 20rpx 0rpx 20rpx 0rpx;
}
.testInfo {
	padding: 20rpx;
}
.text {
	flex: 1;
	text-align: end;
}
.text_name{
	font-weight: bold;
}
.text_time {
	font-size: 22rpx;
	flex: 1;
	color: #666666;
	flex-wrap: wrap;
}
.text_tag{
	border-radius: 10rpx;
	padding: 0rpx 5rpx 0rpx 5rpx;
}
.text_red_tag{
	text-align: center;
	border-radius: 10rpx;
	border-style: solid;
	color: #DD4037;
	background-color: #FFFFFF;
	border-width: thin;
	border-color: #dd4037;
	padding: 0rpx 5rpx 0rpx 5rpx;
	margin-right: 10rpx;
}
.testCard {
	border-radius: 10rpx;
	border-style: solid;
	background-color: #ffffff;
	border-width: thin;
	border-color: #e5e5e5;
	margin: 0rpx 20rpx 20rpx 20rpx;
}
</style>
