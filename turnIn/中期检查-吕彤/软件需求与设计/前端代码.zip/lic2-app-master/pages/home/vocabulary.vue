<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<picker @change="bindPickerChange" :value="index" :range="VbSortList" range-key="name">
			<view class="uni-flex uni-row picker_part">
				<view style="display: flex; align-items: center;">
					<text class="picker_view">{{ VbSortList[index].name }}</text>
				</view>

				<uniIcons type="arrowdown" color="#666666" size="24"></uniIcons>
			</view>
		</picker>

		<view class="uni-list">
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in VbList" :key="index" @tap="openVbInfo" :data-id="item.id" :data-name="item.name">
				<view class="uni-flex uni-row">
					<view style="margin: 20rpx;">{{ item.name }}</view>
					<view style="margin: 20rpx;">{{ item.pinyin }}</view>
					<view style="margin: 20rpx;">{{ item.english }}</view>
				</view>
				<view class="common-divider-line"></view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '字词',
			VbSortList: [],
			VbList: [],
			index: 0,
			courseId: -1
		};
	},
	onLoad: function(e) {
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		this.courseId = e.courseId;
		//获取字词分类
		uni.request({
			url: ApiManager.getVocabularySortList,
			method: 'POST',
			data: {
				courseId: this.courseId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.VbSortList = content.sortList;
				}
			},
			fail: () => {},
			complete: () => {
				this.requestList();
			}
		});
		uni.hideLoading();
	},

	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		requestList(){
			uni.request({
				url: ApiManager.getVocabularyList,
				method: 'POST',
				data: {
					courseId: this.courseId,
					sortId: this.VbSortList[this.index].id
				},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.VbList = content.vocabularyList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
		},
		bindPickerChange: function(e) {
			console.log('picker发送选择改变，携带值为：' + e.target.value);
			this.index = e.target.value;
			this.requestList();
		},
		openVbInfo: function(e) {
			uni.navigateTo({
				url: './vocabularyDetail?id=' + e.currentTarget.dataset.id,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.picker_part {
	justify-content: center;
	background-color: #ffffff;
}
</style>
