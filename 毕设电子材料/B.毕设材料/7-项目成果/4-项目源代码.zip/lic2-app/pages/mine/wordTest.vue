<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" title="识字量在线测试" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-row ">
			<view class="statistical_data">
				<view>练习量</view>
				<text class="emphasize_numbers">{{ done }}</text>
			</view>
			<view class="statistical_data">
				<view>识字量</view>
				<text class="emphasize_numbers">{{ right }}</text>
			</view>
			<view class="statistical_data">
				<view>识字率</view>
				<text class="emphasize_numbers">{{ percent }}</text>
			</view>
		</view>
		<view class="uni-flex uni-column word_part">
			<view class="word_pinyin">{{ wordInfo.pinyin }}</view>
			<view class="word_name">{{ wordInfo.chinese }}</view>
		</view>
		<!--按钮区域-->
		<view class="uni-flex uni-column" style="margin: 20rpx;">
			<view class="uni-flex uni-row">
				<button class="can_not_button_class" @click="isCanNot()">不认识</button>
				<button class="can_button_class" @click="isCan()">认识</button>
			</view>
			<button class="seem_button_class" @click="isSeem()">模糊</button>
		</view>
	</view>
</template>

<script>
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import ApiManager from '../../common/api.js';
import Util from '../../common/util.js';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			//练习量:每次点击+1
			done: 0,
			//识字量:认识+1，模糊+0.5，不认识+0
			right: 0,
			//识字率=识字量/练习量
			percent: '0.00%',
			wordInfo: {},
			//用于判断是否可以直接退出
			canQuit: false
		};
	},
	onLoad() {
		this.refresh();
	},
	onBackPress() {
		if (this.canQuit) {
			return false;
		}
		if (this.done != 0) {
			uni.showModal({
				title: '确定要退出吗？',
				content: '退出后练习数据将重置',
				showCancel: true,
				success: res => {
					if (res.cancel) {
						this.canQuit = false;
						return true;
					} else {
						this.canQuit = true;
						this.back();
					}
				},
				fail: () => {},
				complete: () => {}
			});
			return true;
		}
	},
	methods: {
		back() {
			//#ifdef MP-WEIXIN
			console.log("MP");
			uni.showModal({
				title: '确定要退出吗？',
				content: '退出后练习数据将重置',
				showCancel: true,
				success: res => {
					if (res.confirm) {
						uni.navigateBack({
							delta: 1
						});
					}
				},
				fail: () => {},
				complete: () => {}
			});
			//#endif
			//#ifdef APP-PLUS||H5
			console.log("APP||H5");
			uni.navigateBack({
				delta: 1
			});
			//#endif
		},
		isCanNot() {
			this.done++;
			this.percent = Util.formatPercent(this.right, this.done);
			//请求接口
			this.refresh();
		},
		isCan() {
			this.done++;
			this.right++;
			this.percent = Util.formatPercent(this.right, this.done);
			//请求接口
			this.refresh();
		},
		isSeem() {
			this.done++;
			this.right += 0.5;
			this.percent = Util.formatPercent(this.right, this.done);
			//请求接口
			this.refresh();
		},
		refresh() {
			uni.request({
				url: ApiManager.getVocabulary,
				method: 'GET',
				data: {},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							this.wordInfo = content;
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.can_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-left: 10rpx;
	background-color: #dd4037;
	padding: 10rpx;
	color: #ffffff;
	font-weight: bold;
}
.can_not_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-right: 10rpx;
	background-color: #dd4037;
	padding: 10rpx;
	color: #ffffff;
	font-weight: bold;
}
.seem_button_class {
	flex: 1;
	width: 100%;
	font-size: 28rpx;
	margin-top: 20rpx;
	padding: 10rpx;
	background-color: #dd4037;
	color: #ffffff;
	font-weight: bold;
}
.word_pinyin {
	width: 100%;
	text-align: center;
	font-size: 96rpx;
}
.word_name {
	width: 100%;
	text-align: center;
	font-size: 192rpx;
}
.word_part {
	align-items: center;
	padding-bottom: 100rpx;
	background-color: #ffffff;
}
.emphasize_numbers {
	color: #dd4037;
	font-weight: bold;
}
.statistical_data {
	flex: 1;
	text-align: center;
	padding: 20rpx;
}
</style>
