<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="错题本" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicList" :key="index" @tap="openinfo" :data-newsid="item.topicId">
				<topicItem 
				topicUrl="../../static/ic_topic.png"
				:topicName="item.topicName"
				:topicKnowledgePoint="item.knowledgePoint"
				:topicKeyWord="item.keyWord"
				></topicItem>
			</view>
		</view>
	</view>
</template>

<script>
	import ApiManager from '../../common/api.js';
	import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
	import topicItem from '../../components/diy/topicItem.vue';
	export default {
	components: {
		topicItem,
		NavBar
	},
		data() {
			return {
				topicList: []
			}
		},
		onLoad: function() {
			uni.showLoading({
				title: '加载中....'
			});
			uni.request({
				url: ApiManager.getWrongBookTopic,
				method: 'POST',
				data: {
					studentNumber: getApp().globalData.studentInfo.studentNumber
				},
				success: res => {
					var errorCode = res.data.errorCode;
					var errorMsg = res.data.errorMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						this.topicList = content.topicList;
					}
				},
				fail: () => {},
				complete: () => {}
			});
			uni.hideLoading();
		},
		methods: {
			back() {
				uni.navigateBack({
					delta: 1
				});
			},
			openinfo(e) {
				var topicId = e.currentTarget.dataset.newsid;
				uni.navigateTo({
					url: '../common/topicDetail?topicId='+topicId,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style>

</style>
