<template>
	<view class="uni-flex uni-column materialCard">
		<view class="uni-flex uni-row materialInfo">
			<view style="display: flex; align-items: center;"><image class="icon" v-bind:src="materialUrl" mode="aspectFill"></image></view>
			<view class="uni-flex uni-column" style="flex: 1;margin-left: 20rpx;">
				<text class="text" style="font-weight: bold;">{{ materialName }}</text>
				<text class="text">{{ materialDesc }}</text>
				<text class="text_time">{{ materialTime }}</text>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	name: 'materialItem',
	data() {
		return {};
	},
	props: {
		materialUrl: {
			type: String,
			default: '/static/ic_material.png'
		},
		materialName: {
			type: String,
			default: '暂无数据'
		},
		materialTime: {
			type: String,
			default: '暂无数据'
		},
		materialDesc: {
			type: String,
			default: '暂无数据'
		},
		showDivider: {
			type: Boolean,
			default: true
		}
	},
	methods: {}
};
</script>

<style>
.materialInfo {
	padding: 20rpx;
}
.icon {
	width: 80rpx;
	height: 80rpx;
}
.text {
	flex: 1;
	flex-wrap: wrap;
}
.text_time {
	font-size: 20rpx;
	flex: 1;
	color: #666666;
	flex-wrap: wrap;
}
.materialCard {
	border-radius: 10rpx;
	border-style: solid;
	background-color: #ffffff;
	border-width: thin;
	border-color: #e5e5e5;
	margin: 0rpx 20rpx 20rpx 20rpx;
}
</style>
