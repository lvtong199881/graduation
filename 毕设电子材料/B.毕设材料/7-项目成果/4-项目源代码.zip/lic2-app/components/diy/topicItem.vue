<template>
	<view class="uni-flex uni-column topic">
		<view class="uni-flex uni-row topicInfo">
			<view style="display: flex; align-items: center;"><image class="icon" v-bind:src="topicUrl" mode="aspectFill"></image></view>
			<view class="uni-flex uni-column" style="flex: 1;margin-left: 20rpx;width: 0;">
				<text class="topic_name">
					<text v-if="showId" class="tag">题号:{{ topicId }}</text>
					{{ name }}
				</text>
				<text class="topic_para">
					<text class="tag">知识点</text>
					{{ knowledgePoint }}
				</text>
			</view>
			<view v-if="showCollect" style="display: flex;align-items: center;" @tap.stop="tryCollectOrNot"><image class="icon_collect" :src="collectUrl"></image></view>
		</view>
	</view>
</template>
<script>
import ApiManager from '../../common/api.js';
export default {
	name: 'topicItem',
	data() {
		return {
			lastClickTime: -1,
			collectUrl: '../../static/ic_uncollect.png',
			name: (this.topicName == '') | null ? '题干为空' : this.topicName.length > 50 ? this.topicName.substr(0, 50).replace(/[\r\n]/g,"") + '...'  : this.topicName.replace(/[\r\n]/g,""),
			knowledgePoint:
				(this.topicKnowledgePoint == '') | null
					? '知识点为空'
					: this.topicKnowledgePoint.length > 50
					? this.topicKnowledgePoint.substr(0, 50).replace(/[\r\n]/g,"")  + '...'
					: this.topicKnowledgePoint.replace(/[\r\n]/g,"") ,
			collected:this.isCollected
		};
	},
	props: {
		topicUrl: {
			type: String,
			default: '../../static/ic_topic.png'
		},
		topicName: {
			type: String,
			default: '题干为空'
		},
		topicKnowledgePoint: {
			type: String,
			default: '知识点为空'
		},
		showCollect: {
			type: Boolean,
			default: false
		},
		topicId: {
			type: Number,
			default: 0
		},
		showId: {
			type: Boolean,
			default: false
		},
		isCollected: {
			type: Boolean,
			default: false
		}
	},
	methods: {
		tryCollectOrNot() {
			//快速点击拦截
			var thisClickTime = new Date().getTime();
			// console.log(thisClickTime.toString());
			if (this.lastClickTime != -1 && thisClickTime - this.lastClickTime < 800) {
				return;
			}
			this.lastClickTime = thisClickTime;
			var that = this;
			if (this.collected) {
				//已收藏，需要取消收藏
				uni.request({
					url: ApiManager.unCollect,
					method: 'POST',
					data: {
						studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
						topicId: parseInt(this.topicId),
						testId:-1
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode +":"+ res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '取消收藏成功',
									icon: 'none'
								});
								that.collected = false;
								that.collectUrl = that.collected ? '../../static/ic_collected.png' : '../../static/ic_uncollect.png';
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '取消收藏失败',
							icon: 'none'
						});
					},
					complete: () => {}
				});
				// that.$emit('uncollect');
			} else {
				//未收藏，需要收藏
				uni.request({
					url: ApiManager.collect,
					method: 'POST',
					data: {
						studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
						topicId: parseInt(this.topicId),
						testId:-1
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '收藏成功',
									icon: 'none'
								});
								that.collected = true;
								that.collectUrl = that.collected ? '../../static/ic_collected.png' : '../../static/ic_uncollect.png';
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '收藏失败',
							icon: 'none'
						});
					},
					complete: () => {}
				});
				// that.$emit('collect');
			}
			// console.log("success="+success);
			// if (success) {
			// 	this.collected = !this.collected;
			// 	this.collectUrl = this.collected ? '../../static/ic_collected.png' : '../../static/ic_uncollect.png';
			// }
		}
	}
};
</script>

<style>
.topicInfo {
	padding: 20rpx;
}
.icon {
	width: 80rpx;
	height: 80rpx;
	padding: 20rpx 0rpx 20rpx 0rpx;
}
.icon_collect {
	width: 52rpx;
	height: 52rpx;
}
.topic_para {
	flex: 1;
	flex-wrap: wrap;
}
.topic {
	border-radius: 10rpx;
	border-style: solid;
	background-color: #ffffff;
	border-width: thin;
	border-color: #e5e5e5;
	margin: 0rpx 20rpx 20rpx 20rpx;
}
.tag {
	text-align: center;
	font-size: 24rpx;
	border-radius: 10rpx;
	border-style: solid;
	color: #dd4037;
	background-color: #ffffff;
	border-width: thin;
	border-color: #dd4037;
	padding: 0rpx 10rpx 0rpx 10rpx;
	margin-right: 10rpx;
}
.topic_name {
	font-weight: bold;
}
</style>
