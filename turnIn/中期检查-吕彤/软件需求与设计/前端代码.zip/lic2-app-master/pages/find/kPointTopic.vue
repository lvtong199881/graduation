<template>
	<!--知识点出题题目列表-->
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topicId">
			<topicItem topicUrl="../../static/ic_topic.png" :topicName="item.topicName" :topicKnowledgePoint="item.knowledgePoint" :topicKeyWord="item.keyWord"></topicItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
export default {
	components: {
		NavBar,
		topicItem
	},
	data() {
		return {
			title: '题目列表',
			topicList: []
		};
	},
	onLoad: function() {
		var firstId = getApp().globalData.kpSortIndex.firstIndex;
		var secondId = getApp().globalData.kpSortIndex.secondIndex;
		var thirdId = getApp().globalData.kpSortIndex.thirdIndex;
		var kpointId = getApp().globalData.kpSortIndex.kpointId;
		uni.showToast({
			title: firstId + ' ' + secondId + ' ' + thirdId + ' ' + kpointId,
			icon: 'none'
		});
		uni.showLoading({
			title: '加载中....'
		});
		uni.request({
			url: ApiManager.getKPTopicList,
			method: 'POST',
			data: {
				kpointId: kpointId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.topicList = content.topicList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		openTopicInfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.showToast({
				title: topicId,
				icon: 'none'
			});
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
</style>
