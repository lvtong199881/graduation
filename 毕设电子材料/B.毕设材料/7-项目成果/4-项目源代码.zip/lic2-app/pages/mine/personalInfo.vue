<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" title="个人信息" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<view @click="gotoChangeAvatar">
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;padding: 20rpx;background-color: #FFFFFF;">
					<text style="align-self: center;">头像</text>
					<image
						:src="studentInfo.avatar"
						mode="aspectFit"
						style="width: 80rpx;height: 80rpx;background-color: #F8F8F8;border-radius: 10rpx;align-content: center;"
						@tap.stop="priviewAvatar"
					></image>
				</view>
				<view class="common-divider-line"></view>
			</view>
			<formItem labelText="学号" showClick="true" :value="studentInfo.number"></formItem>
			<formItem labelText="姓名" showClick="true" :value="studentInfo.name" showEditIcon="true" @click.native="gotoEditName()"></formItem>
			<formItem labelText="手机号" showClick="true" :value="studentInfo.phone" showEditIcon="true" @click.native="gotoEditPhone()"></formItem>
			<formItem labelText="班级" showClick="true" :value="studentInfo.className"></formItem>
			<formItem labelText="分科" showClick="true" :value="studentInfo.division"></formItem>
			<formItem labelText="国家或地区" showClick="true" :value="studentInfo.countryName" showEditIcon="true" @click.native="gotoChooseCountry()"></formItem>
			<formItem labelText="语言" showClick="true" :value="studentInfo.languageName" showEditIcon="true" @click.native="gotoChooselanguage()"></formItem>
			<formItem labelText="注册时间" showClick="true" :value="studentInfo.registrationTime"></formItem>
			<formItem labelText="累积学习时间(分)" showClick="true" :value="studentInfo.learnedTime"></formItem>
			<formItem labelText="兴趣爱好" showClick="true" :value="hobbyString" showEditIcon="true" @click.native="gotoChooseHobbies()"></formItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import formItem from '../../components/diy/formItem.vue';
import { pathToBase64, base64ToPath } from '../../common/image.js';
export default {
	components: {
		NavBar,
		formItem
	},
	data() {
		return {
			hobbyString: '暂无数据',
			studentInfo: {}
		};
	},
	onShow: function() {
		this.getStudentInfo();
	},
	onPullDownRefresh() {
		this.getStudentInfo();
		setTimeout(function() {
			uni.stopPullDownRefresh();
		}, 1000);
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		getStudentInfo() {
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			uni.request({
				url: ApiManager.getStudentInfo,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.hideLoading();
							this.studentInfo = content;
							this.hobbyString = this.studentInfo == null || this.studentInfo.hobbies == null ? '' : this.studentInfo.hobbies.toString();
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		},
		gotoChangeAvatar() {
			var that = this;
			uni.chooseImage({
				count: 1,
				success: function(res) {
					var image = res.tempFilePaths[0];
					//#ifdef H5||MP-WEIXIN
					console.log('h5');
					pathToBase64(image)
						.then(base64 => {
							console.log('转base64成功');
							// console.log(base64);
							uni.request({
								url: ApiManager.uploadPicture,
								method: 'POST',
								data: {
									file_byte: base64
								},
								success: res => {
									console.log(res.data.url);
									uni.request({
										url: ApiManager.changePicture,
										method: 'POST',
										data: {
											studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
											icon: res.data.url
										},
										success: res => {
											uni.showToast({
												title: '修改成功',
												icon: 'none'
											});
											that.getStudentInfo();
										},
										fail: () => {
											uni.showToast({
												title: '修改失败',
												icon: 'none'
											});
										},
										complete: () => {}
									});
								},
								fail: () => {
									uni.showToast({
										title: '加载失败',
										icon: 'none'
									});
								},
								complete: () => {}
							});
						})
						.catch(error => {
							console.error(error);
						});
					//#endif
					//#ifdef APP-PLUS
					console.log('app');
					plus.io.resolveLocalFileSystemURL(image, entry => {
						entry.file(file => {
							var fileReader = new plus.io.FileReader();
							fileReader.readAsDataURL(file);
							fileReader.onloadend = evt => {
								uni.request({
									url: ApiManager.uploadPicture,
									data: {
										file_byte: evt.target.result
									},
									method: 'POST',
									success: res => {
										console.log('上传成功');
										console.log(res.data.url);
										uni.request({
											url: ApiManager.changePicture,
											method: 'POST',
											data: {
												studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
												icon: res.data.url
											},
											success: res => {
												uni.showToast({
													title: '修改成功',
													icon: 'none'
												});
												that.getStudentInfo();
											},
											fail: () => {
												uni.showToast({
													title: '修改失败',
													icon: 'none'
												});
											},
											complete: () => {}
										});
									},
									fail() {
										uni.showToast({
											title: '上传失败',
											icon: 'none'
										});
									}
								});
							};
						});
					});
					//#endif
				},
				fail: function(res) {
					uni.showToast({
						title: '调用失败',
						icon: 'none'
					});
				}
			});
		},
		gotoEditName() {
			uni.navigateTo({
				url: './textEdit?pageId=1&pageName=姓名',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoEditPhone() {
			uni.navigateTo({
				url: './textEdit?pageId=2&pageName=手机号',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooseCountry() {
			uni.navigateTo({
				url: './changeCountry',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooselanguage() {
			uni.navigateTo({
				url: './changeLanguage',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooseHobbies() {
			uni.navigateTo({
				url: './multiChoiceEdit?pageId=5&pageName=兴趣爱好',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		priviewAvatar() {
			uni.previewImage({
				urls: [this.studentInfo.avatar],
				fail: function(err) {
					uni.showToast({
						title: err.errMsg,
						icon: 'none'
					});
				}
			});
		}
	}
};
</script>

<style></style>
