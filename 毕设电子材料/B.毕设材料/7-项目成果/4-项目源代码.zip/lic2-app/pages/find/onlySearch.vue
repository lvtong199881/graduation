<template>
	<view class="common-content-auto">
		<!--搜索标题栏-->
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<searchBar clearButton="auto" @confirm="search"></searchBar>
		<view class="common-divider-line"></view>
		<!--排序与筛选组件-->
		<sl-filter :color="titleColor" :themeColor="themeColor" :menuList.sync="menuList" @result="result"></sl-filter>
		<!-- 搜索结果-->
		<view style="padding-top: 20rpx;" v-if="needFresh" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topicId">
			<topicItem
				:topicId="item.topicId"
				:topicName="item.topicName"
				:topicKnowledgePoint="item.knowledgePoint"
				showCollect
				@collect="tryCollect(index)"
				@uncollect="tryUnCollect(index)"
			></topicItem>
		</view>
		<view v-if="resultIsNull" style="background-color: #FFFFFF;text-align: center;align-items: center;">
			<image src="../../static/search_null.png" mode=" aspectFit" style="width: 200rpx;height: 200rpx;"></image>
			<view>搜索结果为空</view>
		</view>
	</view>
</template>

<script>
import slFilter from '../../components/songlazy-sl-filter/sl-filter/sl-filter.vue';
import searchBar from '../../components/uni-search-bar/uni-search-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar,
		slFilter,
		searchBar,
		topicItem,
		uniIcons
	},
	data() {
		return {
			title: '搜索出题',
			searchString: '',
			topicList: [],
			themeColor: '#dd4037',
			titleColor: '#666666',
			resultIsNull: true,
			filter: {
				sortType: -1,
				topicType: 0,
				difficulty: -1
			},
			needFresh: true,
			courseId: -1,
			menuList: [
				{
					title: '排序',
					isMutiple: false,
					key: 'sortType',
					defaultSelectedIndex: 0,
					detailList: [
						{
							title: '不限',
							value: '-1'
						},
						{
							title: '难度升序',
							value: '0'
						},
						{
							title: '难度降序',
							value: '1'
						}
					]
				},
				{
					title: '难度',
					key: 'difficulty',
					isMutiple: false,
					defaultSelectedIndex: 0,
					detailList: [
						{
							title: '不限',
							value: '-1'
						},
						{
							title: '容易',
							value: '0'
						},
						{
							title: '中等',
							value: '1'
						},
						{
							title: '困难',
							value: '2'
						}
					]
				},
				{
					title: '题型',
					key: 'topicType',
					isMutiple: false,
					defaultSelectedIndex: 0,
					detailList: [
						{
							title: '单选',
							value: '0'
						},
						{
							title: '多选',
							value: '1'
						},
						{
							title: '填空',
							value: '2'
						},
						{
							title: '写汉字',
							value: '3'
						},
						{
							title: '作文',
							value: '4'
						}
					]
				}
			]
		};
	},
	onLoad(e) {
		console.log(e.courseId);
		this.courseId = e.courseId == null ? -1 : e.courseId;
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		result(val) {
			this.filter = val;
			console.log(this.filter);
		},
		openTopicInfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		search(res) {
			var that = this;
			console.log(this.filter);
			this.searchString = res.value.replace(/\s+/g, '');
			if (this.searchString == '') {
				uni.showToast({
					title: '搜索内容为空',
					icon: 'none'
				});
			} else {
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				//修改名字
				uni.request({
					url: ApiManager.getSearchTopic,
					method: 'POST',
					data: {
						courseId: parseInt(this.courseId),
						searchString: this.searchString,
						sortType: parseInt(this.filter.sortType),
						topicType: parseInt(this.filter.topicType),
						difficulty: parseInt(this.filter.difficulty)
					},
					success: res => {
						if (res.statusCode != 200) {
							uni.showToast({
								title: res.statusCode + ':' + res.errMsg,
								icon: 'none'
							});
						} else {
							var errorCode = res.data.errCode;
							var errorMsg = res.data.errMsg;
							var version = res.data.version;
							var content = res.data.content;
							if (errorCode != 1) {
								uni.showToast({
									title: errorMsg,
									icon: 'none'
								});
							} else {
								uni.showToast({
									title: '加载成功',
									mask: true
								});
								that.needFresh = false;
								if (content == null || content == '' || content.length == 0) {
									that.resultIsNull = true;
								} else {
									that.resultIsNull = false;
								}
								that.topicList = content;
								setTimeout(function() {
									that.needFresh = true;
								}, 500);
							}
						}
					},
					fail: () => {
						uni.showToast({
							title: '加载失败',
							icon: 'none'
						});
					},
					complete: () => {}
				});
			}
		}
	}
};
</script>

<style>
.status_bar {
	height: var(--status-bar-height);
	width: 100%;
	background-color: #dd4037;
}
.viewPage {
	flex: 1;
	font-size: 28rpx;
	background-color: #ffffff;
	border-radius: 0;
}
</style>
