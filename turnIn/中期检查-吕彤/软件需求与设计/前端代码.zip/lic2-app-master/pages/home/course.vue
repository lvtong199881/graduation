<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view class="vocabulary_class" slot="right" @click="gotoVocabulary">词</view>
		</NavBar>
		<view class="uni-flex uni-row">
			<button class="viewPage" @click="getActivityList()">课程活动</button>
			<button class="viewPage" @click="getMaterialList()">课程资料</button>
		</view>
		<swiper :style="{ height: swiperHeight + 'px' }" class="swiper" circular="true" :current="current" duration="300" @change="onswiperchange">
			<swiper-item item-id="0" style="margin-top: 20rpx;">
				<view class="activity_list_class">
					<view style="padding-left: 20rpx;">任务列表</view>
					<view hover-class="uni-list-cell-hover" v-for="(item, index) in activityList" :key="index" @tap="openTestInfo" :data-newsid="item.id">
						<testItem testIconRes="../../static/ic_test.png" :testName="item.name" :testTime="item.time" :testState="item.stateString" :testDurtion="item.duration"></testItem>
					</view>
				</view>
			</swiper-item>

			<swiper-item item-id="1" style="margin-top: 20rpx;">
				<view class="material_list_class">
					<view hover-class="uni-list-cell-hover" v-for="(item, index) in materialList" :key="index" @tap="openMaterialInfo" :data-newsid="item.id">
						<materialItem materialUrl="../../static/ic_material.png" :materialName="item.name" :materialTime="item.time" :materialDesc="item.description"></materialItem>
					</view>
				</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import testItem from '../../components/diy/testItem.vue';
import materialItem from '../../components/diy/materialItem.vue';
export default {
	components: {
		NavBar,
		testItem,
		materialItem
	},
	data() {
		return {
			courseId: 0,
			title: '课程详情',
			activityList: [],
			materialList: [],
			current: 1,
			swiperHeight: 0 //外部的高度
		};
	},
	onLoad: function(e) {
		this.courseId = e.courseId;
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getCourseActivityList,
			method: 'POST',
			data: {
				studentNumber:getApp().globalData.studentInfo.studentNumber,
				courseId:this.courseId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.activityList = content.activityList
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.request({
			url: ApiManager.getCourseMaterialList,
			method: 'POST',
			data: {
				studentNumber:getApp().globalData.studentInfo.studentNumber,
				courseId:this.courseId
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				}else{
					this.materialList = content.materialList
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	onShow: function() {
		this.current = 0;
	},
	watch: {
		activityList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.activity_list_class');
			});
		},
		materialList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.material_list_class');
			});
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		initSwiperHeight(list) {
			let _this = this;
			let info = uni.createSelectorQuery().select(list);
			info.boundingClientRect(function(data) {
				if (_this.swiperHeight < data.height + 10) {
					_this.swiperHeight = data.height + 10;
				}
			}).exec();
		},
		onswiperchange(e) {
			this.current = e.detail.current;
			if (this.current == 0) {
				this.initSwiperHeight('.activity_list_class');
			} else {
				this.initSwiperHeight('material_list_class');
			}
		},
		getActivityList() {
			this.current = 0;
		},
		getMaterialList() {
			this.current = 1;
		},
		openTestInfo(e) {
			uni.showToast({
				title: e.currentTarget.dataset.newsid,
				icon: 'none'
			});
			var newsid = e.currentTarget.dataset.newsid;
			this.initSwiperHeight('.activity_list_class');
		},
		openMaterialInfo(e) {
			uni.showModal({
				title: '提示',
				content: '确定要下载课程资料:' + this.materialList[e.currentTarget.dataset.newsid - 1].name + '吗？',
				showCancel: true,
				cancelText: '取消',
				confirmText: '下载',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
			// uni.showToast({
			// 	title: e.currentTarget.dataset.newsid,
			// 	icon: 'none'
			// });
			var newsid = e.currentTarget.dataset.newsid;
			this.initSwiperHeight('.material_list_class');
		},
		gotoVocabulary() {
			uni.navigateTo({
				url: './vocabulary?courseId=' + this.courseId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.viewPage {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
}
.swiper {
	display: flex;
}
.vocabulary_class {
	padding: 20rpx;
	font-size: 32rpx;
}
</style>
