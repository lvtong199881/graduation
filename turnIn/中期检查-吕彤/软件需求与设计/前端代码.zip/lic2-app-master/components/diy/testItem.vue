<template>
	<view class="uni-flex uni-column">
		<view class="uni-flex uni-row testInfo">
			<view style="display: flex; align-items: center;"><image v-bind:src="testIconRes" class="test_icon" mode="aspectFill"></image></view>

			<view class="uni-flex uni-column" style="flex: 1;">
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
					<view class="text">{{ testName }}</view>
					<view class="text">{{ testTime }}</view>
				</view>
				<view class="uni-flex uni-row" style="-webkit-justify-content: space-between;justify-content: space-between;">
					<view class="text">{{ testState }}</view>
					<view class="text">{{ testDurtion }}</view>
				</view>
			</view>
		</view>
		<view v-if="showDivider" class="common-divider-line"></view>
	</view>
</template>

<script>
export default {
	name: 'testItem',
	data() {
		return {};
	},
	props: {
		testIconRes: {
			type: String,
			default: '/static/ic_test.png'
		},
		testName: {
			type: String,
			default: '暂无数据'
		},
		testTime: {
			type: String,
			default: '暂无数据'
		},
		testState: {
			type: String,
			default: '暂无数据'
		},
		testDurtion: {
			type: String,
			default: '暂无数据'
		},
		showDivider: {
			type: Boolean,
			default: true
		}
	},
	methods: {}
};
</script>

<style>
.test_icon {
	width: 80rpx;
	height: 80rpx;
}
.testInfo {
	padding: 20rpx;
	background-color: #ffffff;
}
.text {
}
</style>
