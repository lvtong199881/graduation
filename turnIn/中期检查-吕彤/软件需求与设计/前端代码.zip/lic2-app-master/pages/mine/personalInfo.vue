<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="个人信息" @clickLeft="back" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;">
			<formItem labelText="学号" showClick="true" :value="studentInfo.number"></formItem>
			<formItem labelText="姓名" showClick="true" :value="studentInfo.name" showEditIcon="true" @click.native="gotoEditName()"></formItem>
			<formItem labelText="手机号" showClick="true" :value="studentInfo.phone" showEditIcon="true" @click.native="gotoEditPhone()"></formItem>
			<formItem labelText="班级" showClick="true" :value="studentInfo.className"></formItem>
			<formItem labelText="国家或地区" showClick="true" :value="studentInfo.countryName" showEditIcon="true" @click.native="gotoChooseCountry()"></formItem>
			<formItem labelText="语言" showClick="true" :value="studentInfo.languageName" showEditIcon="true" @click.native="gotoChooselanguage()"></formItem>
			<formItem labelText="学院" showClick="true" :value="studentInfo.college"></formItem>
			<formItem labelText="分科" showClick="true" :value="studentInfo.division"></formItem>
			<formItem labelText="注册时间" showClick="true" :value="studentInfo.registrationTime"></formItem>
			<formItem labelText="累积学习时间" showClick="true" :value="studentInfo.learnedTime"></formItem>
			<formItem labelText="兴趣爱好" showClick="true" :value="hobbyString" showEditIcon="true" @click.native="gotoChooseHobbies()"></formItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import formItem from '../../components/diy/formItem.vue';
export default {
	components: {
		NavBar,
		formItem
	},
	data() {
		return {
			hobbyString: '',
			studentInfo: {
				number: '暂无数据',
				name: '暂无数据',
				avatar: '暂无数据',
				phone: '暂无数据',
				countryId: -1,
				countryName: '暂无数据',
				languageId: -1,
				languageName: '暂无数据',
				division: '暂无数据',
				classId: -1,
				className: '暂无数据',
				college: '暂无数据',
				registrationTime: '暂无数据',
				learnedTime: '暂无数据',
				hobbies: []
			}
		};
	},
	onLoad: function() {
		uni.request({
			url: ApiManager.getStudentInfo,
			method: 'POST',
			data: {
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				var studentInfo = content.studentInfo;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.studentInfo.number = studentInfo.number;
					(this.studentInfo.name = studentInfo.name),
						(this.studentInfo.avatar = studentInfo.avatar),
						(this.studentInfo.phone = studentInfo.phone),
						(this.studentInfo.countryId = studentInfo.countryId),
						(this.studentInfo.countryName = studentInfo.countryName),
						(this.studentInfo.languageId = studentInfo.languageId),
						(this.studentInfo.languageName = studentInfo.languageName),
						(this.studentInfo.division = studentInfo.division),
						(this.studentInfo.classId = studentInfo.classId),
						(this.studentInfo.className = studentInfo.className),
						(this.studentInfo.college = studentInfo.college),
						(this.studentInfo.registrationTime = studentInfo.registrationTime),
						(this.studentInfo.learnedTime = studentInfo.learnedTime),
						(this.studentInfo.hobbies = studentInfo.hobbies);

					for (var i = 0; i < this.studentInfo.hobbies.length; i++) {
						this.hobbyString = this.hobbyString + this.studentInfo.hobbies[i].hobbyName + ' ';
					}
				}
			},
			fail: () => {},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		gotoEditName() {
			uni.navigateTo({
				url: './textEdit?pageId=1&pageName=姓名',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoEditPhone() {
			uni.navigateTo({
				url: './textEdit?pageId=2&pageName=手机号',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooseCountry() {
			uni.navigateTo({
				url: './singleChoiceEdit?pageId=3&pageName=国家或地区',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooselanguage() {
			uni.navigateTo({
				url: './singleChoiceEdit?pageId=4&pageName=语言',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		gotoChooseHobbies() {
			uni.navigateTo({
				url: './multiChoiceEdit?pageId=5&pageName=兴趣爱好',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
