<template>
	<view style="height: auto;margin-bottom: 100rpx;">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="start_test_button uni-flex uni-row" :style="{ width: screenWidth - 20 + 'px' }">
			<button style="flex: 1;" @click="submit()">提交</button>
			<button style="flex: 1;" @click="getAnswer()">答案</button>
		</view>
		<!--题目内容-->
		<view style="padding: 20rpx;">
			<view class="uni-flex uni-column">
				<view class="common-card-f8f8f8">
					<text class="common-tag">{{ topicInfo.topicTypeString }}</text>
					<text class="common-tag">{{ topicDifficultyString }}</text>
				</view>
				<view class="common-card-f8f8f8">
					<text class="common-tag">题干</text>
					{{ topicInfo.topicName }}
				</view>
				<!--音频-->
				<view v-if="topicInfo.topicAudioUrl != null && topicInfo.topicAudioUrl.length != 0">
					<uniIcons @click.native="playTopicAudio" type="sound" color="#DD4037" size="30"></uniIcons>
				</view>
			</view>
			<!--—————————————————————————————————问题-单选题—————————————————————————————————-->
			<view v-if="topicInfo.topicType == 0" v-for="(item, index) in topicInfo.questionList" :key="index" class="common-card-f8f8f8">
				<view>
					<!--问题名称-->
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<!--问题音频-->
					<uniIcons
						v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
						@click.native="playQuesttionAudio"
						type="sound"
						color="#DD4037"
						size="30"
						:data-newsid="index"
					></uniIcons>
					<!--问题图片-->
					<swiper
						v-if="topicInfo.questionList[index].imageUrl != null && topicInfo.questionList[index].imageUrl.size != 0"
						class="swiper"
						indicator-dots="true"
						autoplay="true"
						interval="5000"
						duration="1000"
					>
						<swiper-item v-for="(item, index) in topicInfo.questionList[index].imageUrl" :key="index">
							<image style="height: 300rpx;" :src="item" mode="aspectFit"></image>
						</swiper-item>
					</swiper>
					<text v-if="showAnswer">
						<text class="common-tag">正确答案</text>
						{{ item.correctAnswer }}
					</text>
					<!--选项-->
					<radio-group @change="radioChange" :data-id="index">
						<view class="uni-list-cell uni-list-cell-pd" v-for="(item2, index2) in item.optionList" :key="index2">
							<view v-if="singleAns[index] == getChar(index2)"><radio :value="index2.toString()" checked /></view>
							<view v-else><radio :value="index2.toString()" /></view>
							<view style="width: 100%;">{{ item2 }}</view>
						</view>
					</radio-group>
				</view>
			</view>
			<!--—————————————————————————————————问题-多选题—————————————————————————————————-->
			<view v-if="topicInfo.topicType == 1" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index" :data-newsid="item.id">
				<view>
					<!--问题描述-->
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<!--问题音频-->
					<uniIcons
						v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
						@click.native="playQuesttionAudio"
						type="sound"
						color="#DD4037"
						size="30"
						:data-newsid="index"
					></uniIcons>
					<!--问题图片-->
					<swiper
						v-if="topicInfo.questionList[index].imageUrl != null && topicInfo.questionList[index].imageUrl.size != 0"
						class="swiper"
						indicator-dots="true"
						autoplay="true"
						interval="5000"
						duration="1000"
					>
						<swiper-item v-for="(item, index) in topicInfo.questionList[index].imageUrl" :key="index">
							<image style="height: 300rpx;" :src="item" mode="aspectFit"></image>
						</swiper-item>
					</swiper>
					<text v-if="showAnswer">
						<text class="common-tag">正确答案</text>
						{{ item.correctAnswer }}
					</text>
					<!--选项-->
					<checkbox-group @change="checkboxChange" :data-id="index">
						<view class="uni-list-cell uni-list-cell-pd" v-for="(item, index) in item.optionList" :key="index">
							<view><checkbox :value="index.toString()" :checked="item.checked" /></view>
							<view>{{ item }}</view>
						</view>
					</checkbox-group>
				</view>
			</view>
			<!--—————————————————————————————————问题-填空题-—————————————————————————————————-->
			<view v-if="topicInfo.topicType == 2" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
				<view>
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<!--问题音频-->
					<uniIcons
						v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
						@click.native="playQuesttionAudio"
						type="sound"
						color="#DD4037"
						size="30"
						:data-newsid="index"
					></uniIcons>
					<text v-if="showAnswer">
						<text class="common-tag">正确答案</text>
						{{ item.correctAnswer }}
					</text>
					<input class="question_input" placeholder="输入答案" @input="blankInput" :data-id="index" />
				</view>
			</view>
			<!--—————————————————————————————————问题-写汉字题—————————————————————————————————-->
			<view v-if="topicInfo.topicType == 3" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
				<view>
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<!--问题音频-->
					<uniIcons
						v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
						@click.native="playQuesttionAudio"
						type="sound"
						color="#DD4037"
						size="30"
						:data-newsid="index"
					></uniIcons>
					<!--问题图片-->
					<swiper v-if="item.imageUrl != null && item.imageUrl.size != 0" class="swiper" indicator-dots="true" autoplay="true" interval="5000" duration="1000">
						<swiper-item v-for="(item, index) in item.imageUrl" :key="index"><image style="height: 300rpx;" :src="item" mode="aspectFit"></image></swiper-item>
					</swiper>
					<text v-if="showAnswer">
						<text class="common-tag">正确答案</text>
						{{ item.correctAnswer }}
					</text>
					<view v-if="needRefresh">
						<view class="uni-flex uni-row">
							<button class="common-tag" style="flex:1" @click="doss" :data-id="index">写汉字</button>
							<button class="common-tag" style="flex:1" @click="cleanWriteAns" :data-id="index">清除</button>
						</view>
						<view v-if="writeAns[index] != '' && writeAns[index] != null" class="imgs"><image class="img" :src="writeAns[index]" mode="widthFix"></image></view>
						<catSignature canvasId="canvas1" @close="close" @save="save" :visible="isShow" :canvasIndex="index" />
					</view>
				</view>
			</view>
			<!--—————————————————————————————————问题-作文题—————————————————————————————————-->
			<view v-if="topicInfo.topicType == 4" class="common-card-f8f8f8" v-for="(item, index) in topicInfo.questionList" :key="index">
				<view>
					<view>{{ index + 1 }}.{{ item.name }}</view>
					<!--问题音频-->
					<uniIcons
						v-if="topicInfo.questionList[index].audioUrl != null && topicInfo.questionList[index].audioUrl != ''"
						@click.native="playQuesttionAudio"
						type="sound"
						color="#DD4037"
						size="30"
						:data-newsid="index"
					></uniIcons>
					<!--问题图片-->
					<swiper v-if="item.imageUrl != null && item.imageUrl.length != 0" class="swiper" indicator-dots="true" autoplay="true" interval="5000" duration="1000">
						<swiper-item v-for="(item, index) in item.imageUrl" :key="index"><image style="height: 300rpx;" :src="item" mode="aspectFit"></image></swiper-item>
					</swiper>
					<text v-if="showAnswer">
						<text class="common-tag">正确答案</text>
						{{ item.correctAnswer }}
					</text>
					<view v-if="needRefresh">
						<view class="uni-flex uni-row">
							<button class="choose_button" style="flex:1" @click="chooseImage" :data-id="index">选择图片</button>
							<button class="choose_button" style="flex:1" @click="cleanEssayAns" :data-id="index">清除</button>
						</view>
						<image v-if="essayAns[index] != null && essayAns[index] != ''" v-bind:src="essayAns[index]" mode="aspectFit"></image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
var innerAudioContext = uni.createInnerAudioContext();
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import WritingArea from '../../components/diy/writingArea';
import catSignature from '../../components/diy/cat-signature.vue';
import { pathToBase64, base64ToPath } from '../../common/image.js';
import Util from '../../common/util.js';
export default {
	components: {
		NavBar,
		uniIcons,
		WritingArea,
		catSignature
	},
	data() {
		return {
			startTime: '',
			topicInfo: {},
			title: '题目详情',
			imageUrl: '',
			singleAns: [],
			multipleAns: [],
			blankAns: [],
			writeAns: [],
			essayAns: [],
			//作文题选择图片后刷新视图
			needRefresh: true,
			//写汉字canvas
			isShow: false,
			writeIndex: -1,
			played: false,
			topicDifficultyString: '简单',
			showAnswer: false,
			screenHeight: -1,
			screenWidth: -1
		};
	},
	onLoad: function(e) {
		//获取屏幕高度
		uni.getSystemInfo({
			success: res => {
				this.screenHeight = res.screenHeight;
				this.screenWidth = res.screenWidth;
				console.log('页面高度=' + this.screenHeight);
				console.log('页面宽度=' + this.screenWidth);
			}
		});
		this.startTime = new Date();
		console.log(this.startTime);
		uni.showLoading({
			title: '加载中...',
			mask: true
		});
		//题目id
		console.log('题目id=' + e.topicId);
		//是否显示答案
		console.log('是否显示答案=' + e.showAnswer);
		this.showAnswer = e.showAnswer;
		//获取题目详情
		var that = this;
		uni.request({
			url: ApiManager.getTopicDetail,
			method: 'POST',
			data: {
				topicId: parseInt(e.topicId)
			},
			success: res => {
				var errorCode = res.data.errCode;
				var errorMsg = res.data.errMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					that.topicInfo = content;
					uni.hideLoading();
					that.topicDifficultyString = that.topicInfo.topicDifficulty == 0 ? '简单' : that.topicInfo.topicDifficulty == 1 ? '中等' : '困难';
					//初始化学生答案数组-单选
					that.singleAns = new Array(content.questionList.length);
					that.multipleAns = new Array(content.questionList.length);
					that.blankAns = new Array(content.questionList.length);
					that.writeAns = new Array(content.questionList.length);
					that.essayAns = new Array(content.questionList.length);
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	onUnload() {
		var endTime = new Date();
		var msecondOfMinute = 1000 * 60;
		innerAudioContext.stop();
		var learnTime = Math.floor((endTime - this.startTime) / msecondOfMinute);
		console.log(learnTime);
		if (parseInt(learnTime) > 0) {
			uni.request({
				url: ApiManager.updataLearnTime,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
					time: parseInt(learnTime)
				},
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		getChar(index2) {
			switch (index2) {
				case 0:
					return 'A';
				case 1:
					return 'B';
				case 2:
					return 'C';
				case 3:
					return 'D';
				default:
					return 'A';
			}
		},
		//单选题
		radioChange: function(e) {
			var values = e.detail.value;
			console.log(e);
			console.log(e.currentTarget.dataset.id);
			this.singleAns[e.currentTarget.dataset.id] = values;
			console.log(this.singleAns);
		},
		//多选题
		checkboxChange: function(e) {
			var values = e.detail.value;
			console.log(e);
			console.log(e.currentTarget.dataset.id);
			this.multipleAns[e.currentTarget.dataset.id] = values;
			console.log(this.multipleAns);
		},
		//填空题
		blankInput(e) {
			this.blankAns[e.currentTarget.dataset.id] = e.detail.value;
			console.log(this.blankAns);
		},
		//播放题目中的音频
		playTopicAudio(e) {
			var that = this;
			console.log(this.played);
			//如果播放中，那么不响应
			if (this.played == false) {
				innerAudioContext.autoplay = true;
				innerAudioContext.src = this.topicInfo.topicAudioUrl;
				console.log('播放地址:' + that.topicInfo.topicAudioUrl);
				innerAudioContext.onPlay(() => {
					uni.showToast({
						title: '开始播放',
						icon: 'none'
					});
					this.played = true;
				});
				innerAudioContext.onWaiting(function() {
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					});
				});
				innerAudioContext.onError(res => {
					uni.showToast({
						title: '播放错误' + res.errCode + ':' + res.errMsg
					});
					this.played = false;
				});
				innerAudioContext.onEnded(res => {
					uni.showToast({
						title: '播放完成',
						icon: 'none'
					});
					this.played = false;
				});
				innerAudioContext.onStop(function() {
					this.played = false;
				});
			}
		},
		//写汉字题
		//显示canvas
		doss(e) {
			this.writeIndex = e.currentTarget.dataset.id;
			this.isShow = true;
		},
		//清除写汉字答案
		cleanWriteAns(e) {
			this.needRefresh = false;
			this.writeAns[e.currentTarget.dataset.id] = null;
			this.needRefresh = true;
			console.log(this.writeAns);
		},
		//清除写汉字答案
		cleanEssayAns(e) {
			this.needRefresh = false;
			this.essayAns[e.currentTarget.dataset.id] = null;
			this.needRefresh = true;
			console.log(this.essayAns);
		},
		//关闭canvas
		close() {
			this.isShow = false;
		},
		//保存图片
		save(image) {
			var that = this;
			this.isShow = false;
			this.needRefresh = false;
			var imageUrl = null;
			console.log(image);
			//#ifdef MP-WEIXIN
			console.log('MP-WEIXIN');
			pathToBase64(image)
				.then(base64 => {
					console.log('转base64成功');
					// console.log(base64);
					uni.request({
						url: ApiManager.uploadPicture,
						method: 'POST',
						data: {
							file_byte: base64
						},
						success: res => {
							that.writeAns[that.writeIndex] = res.data.url;
							that.needRefresh = true;
							console.log(that.writeAns);
						},
						fail: () => {
							uni.showToast({
								title: '加载失败',
								icon: 'none'
							});
							that.needRefresh = true;
						},
						complete: () => {}
					});
				})
				.catch(error => {
					console.error(error);
				});
			//#endif
			//#ifdef H5
			console.log('h5');
			uni.request({
				url: ApiManager.uploadPicture,
				method: 'POST',
				data: {
					file_byte: image
				},
				success: res => {
					that.writeAns[that.writeIndex] = res.data.url;
					that.needRefresh = true;
					console.log(that.writeAns);
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
					that.needRefresh = true;
				},
				complete: () => {}
			});
			//#endif
			//#ifdef APP-PLUS
			console.log('app');
			plus.io.resolveLocalFileSystemURL(image, entry => {
				entry.file(file => {
					var fileReader = new plus.io.FileReader();
					fileReader.readAsDataURL(file);
					fileReader.onloadend = evt => {
						uni.request({
							url: ApiManager.uploadPicture,
							data: {
								file_byte: evt.target.result
							},
							method: 'POST',
							success: res2 => {
								console.log('上传成功');
								console.log(res2.data.url);
								that.writeAns[that.writeIndex] = res2.data.url;
								that.needRefresh = true;
							},
							fail() {
								uni.showToast({
									title: '上传失败，请重新写字',
									icon: 'none'
								});
							},
							complete() {
								console.log(that.writeAns);
							}
						});
					};
				});
			});
			//#endif
		},
		//作文题-选择图片
		chooseImage(e) {
			this.needRefresh = false;
			console.log(this.essayAns);
			console.log(e.currentTarget.dataset.id);
			var that = this;
			uni.chooseImage({
				count: 1,
				success: function(res) {
					that.needRefresh = false;
					var image = res.tempFilePaths[0];
					//#ifdef H5||MP-WEIXIN
					console.log('h5');
					pathToBase64(image)
						.then(base64 => {
							console.log('转base64成功');
							// console.log(base64);
							uni.request({
								url: ApiManager.uploadPicture,
								method: 'POST',
								data: {
									file_byte: base64
								},
								success: res => {
									console.log(res.data.url);
									that.essayAns[e.currentTarget.dataset.id] = res.data.url;
									that.needRefresh = true;
									console.log(that.essayAns);
								},
								fail: () => {
									uni.showToast({
										title: '加载失败',
										icon: 'none'
									});
									that.needRefresh = true;
								},
								complete: () => {}
							});
						})
						.catch(error => {
							console.error(error);
						});
					//#endif
					//#ifdef APP-PLUS
					console.log('app');
					plus.io.resolveLocalFileSystemURL(image, entry => {
						entry.file(file => {
							var fileReader = new plus.io.FileReader();
							fileReader.readAsDataURL(file);
							fileReader.onloadend = evt => {
								uni.request({
									url: ApiManager.uploadPicture,
									data: {
										file_byte: evt.target.result
									},
									method: 'POST',
									success: res => {
										console.log('上传成功');
										console.log(res.data.url);
										that.essayAns[e.currentTarget.dataset.id] = res.data.url;
										that.needRefresh = true;
									},
									fail() {
										uni.showToast({
											title: '上传失败，请重新写字',
											icon: 'none'
										});
									},
									complete() {
										console.log(that.essayAns);
									}
								});
							};
						});
					});
					//#endif
				},
				fail: function(res) {
					uni.showToast({
						title: '调用失败',
						icon: 'none'
					});
					that.needRefresh = true;
				}
			});
		},
		//播放问题中的音频
		playQuesttionAudio(e) {
			var that = this;
			console.log(this.played);
			//如果播放中，那么不响应
			if (this.played == false) {
				innerAudioContext.autoplay = true;
				innerAudioContext.src = that.topicInfo.questionList[e.currentTarget.dataset.newsid].audioUrl;
				innerAudioContext.onPlay(() => {
					uni.showToast({
						title: '开始播放',
						icon: 'none'
					});
					this.played = true;
				});
				innerAudioContext.onWaiting(function() {
					uni.showToast({
						title: '加载中...',
						icon: 'none'
					});
				});
				innerAudioContext.onError(res => {
					uni.showToast({
						title: '播放错误' + res.errCode + ':' + res.errMsg
					});
					this.played = false;
				});
				innerAudioContext.onEnded(res => {
					uni.showToast({
						title: '播放完成',
						icon: 'none'
					});
					this.played = false;
				});
				innerAudioContext.onStop(function() {
					this.played = false;
				});
			}
		},
		//获取正确答案
		getAnswer() {
			var rightAns = new Array(this.topicInfo.questionList.length);
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				rightAns[i] = this.topicInfo.questionList[i].correctAnswer;
			}
			uni.showModal({
				title: '正确答案',
				content: rightAns.toString(),
				showCancel: false,
				confirmText: '知道了'
			});
		},
		//提交学生答案
		submit() {
			var that = this;
			var stuAns = new Array(this.topicInfo.questionList.length);
			switch (this.topicInfo.topicType) {
				//单选题
				case 0:
					stuAns = this.singleAns;
					stuAns = Util.translateArray(stuAns);
					break;
				//多选题
				case 1:
					stuAns = this.multipleAns;
					for (var i = 0; i < stuAns.length; i++) {
						var temp = '';
						for (var j = 0; j < stuAns[i].length; j++) {
							temp += stuAns[i][j];
						}
						stuAns[i] = temp;
					}
					stuAns = Util.translateArray(stuAns);
					break;
				//填空题
				case 2:
					stuAns = this.blankAns;
					break;
				case 3:
					stuAns = this.writeAns;
					break;
				//作文题
				case 4:
					stuAns = this.essayAns;
					break;
				default:
					break;
			}
			//正确答案
			var rightAns = new Array(this.topicInfo.questionList.length);
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				rightAns[i] = this.topicInfo.questionList[i].correctAnswer;
			}
			//detailId数组
			var detailId = new Array(this.topicInfo.questionList.length);
			for (var i = 0; i < this.topicInfo.questionList.length; i++) {
				detailId[i] = this.topicInfo.questionList[i].id;
			}
			console.log('学生答案:' + stuAns.toString());
			console.log('正确答案:' + rightAns.toString());
			console.log('detailID:' + detailId.toString());
			uni.showModal({
				title: '是否要提交本题答案？',
				content: '你的答案：' + stuAns.toString(),
				success: res => {
					if (res.confirm) {
						uni.showLoading({
							title: '提交中...',
							mask: true
						});
						uni.request({
							url: ApiManager.submitTopicAnswer,
							method: 'POST',
							data: {
								studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber),
								topicId: parseInt(that.topicInfo.topicId),
								answer: stuAns,
								rightAns: rightAns,
								detailId: detailId
							},
							success: res => {
								var errorCode = res.data.errCode;
								var errorMsg = res.data.errMsg;
								var version = res.data.version;
								var content = res.data.content;
								if (errorCode != 1) {
									uni.showToast({
										title: errorMsg,
										icon: 'none'
									});
								} else {
									uni.showToast({
										title: '提交成功'
									});
									var result = stuAns.toString() == rightAns.toString();
									if (that.topicInfo.topicType == 3 || that.topicInfo.topicType == 4) {
										uni.showModal({
											title: '正确答案',
											content: rightAns.toString(),
											showCancel: false,
											confirmText: '知道了'
										});
									} else {
										uni.showModal({
											title: result ? '答对了，真棒' : '答错了，再接再厉',
											content: '你的答案：' + stuAns.toString() + '\n' + '正确答案：' + rightAns.toString(),
											showCancel: false,
											confirmText: '知道了'
										});
									}
								}
							},
							fail: () => {
								uni.showToast({
									title: '提交失败',
									icon: 'none'
								});
							},
							complete: () => {}
						});
					}
				},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style>
.uni-list-cell {
	justify-content: flex-start;
}
.question {
	background-color: #ffffff;
}
.question_input {
	height: 50rpx;
	padding: 15rpx 25rpx;
	line-height: 50rpx;
	font-size: 28rpx;
	flex: 1;
	background: #e5e5e5;
}
.swiper {
}
.imgs {
	margin-top: 20rpx;
	width: 100%;
	height: 500rpx;
	display: flex;
	margin: 0 auto;
	flex-wrap: wrap;
	background-color: #f8f8f8;
}
.imgs img {
	width: 100%;
	height: 100%;
}
.choose_button {
	color: #ffffff;
	margin: 10rpx;
	background-color: #dd4037;
}
.submit_class {
	text-align: center;
	font-size: 30rpx;
	padding: 10rpx;
	font-weight: bolder;
}
.start_test_button {
	margin: 20rpx;
	position: fixed;
	bottom: 0;
	left: 0;
	z-index: 500;
}
</style>
