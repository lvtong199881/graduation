<template>
	<!--知识点出题一级分类-->
	<view class="common-content">
		<NavBar :title="title" background-color="#DD4037" color="#ffffff" status-bar="true">
			<view slot="left">
				<uniIcons style="margin-right: 20rpx;" type="arrowleft" color="#ffffff" size="24" @click="back()"></uniIcons>
				<uniIcons type="home" color="#ffffff" size="24" @click="home()"></uniIcons>
			</view>
		</NavBar>
		<view style="margin-top: 20rpx;">
			<view v-for="(item, index) in sortOneList" :key="index" @tap="openFirstinfo" :data-id="item.id">
				<view style="background-color: #FFFFFF;">
					<view style="padding: 30rpx 30rpx 30rpx 20rpx;font-size: 30rpx;">{{ item.name }}</view>
					<view class="common-divider-line"></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
export default {
	components: {
		NavBar,
		uniIcons
	},
	data() {
		return {
			title: '知识点层次一',
			sortOneList: []
		};
	},
	onLoad: function(e) {
		uni.showLoading({
			title: '加载中...',
			mask: false
		});
		uni.request({
			url: ApiManager.getKPFirstList,
			method: 'POST',
			data: {},
			success: res => {
				if (res.statusCode != 200) {
					uni.showToast({
						title: res.statusCode + ':' + res.errMsg,
						icon: 'none'
					});
				} else {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功'
						});
						this.sortOneList = content;
						// this.sortOneList.unshift({ id: -1, name: '暂无' });
					}
				}
			},
			fail: () => {
				uni.showToast({
					title: '加载失败',
					icon: 'none'
				});
			},
			complete: () => {}
		});
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		home() {
			getApp().globalData.kpSortIndex.firstIndex = '';
			getApp().globalData.kpSortIndex.secondIndex = '';
			getApp().globalData.kpSortIndex.thirdIndex = '';
			uni.switchTab({
				url: './find',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		openFirstinfo(e) {
			// var firstId = e.currentTarget.dataset.id;
			getApp().globalData.kpSortIndex.firstIndex = e.currentTarget.dataset.id;
			uni.navigateTo({
				url: './kPointSortSecond',
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
