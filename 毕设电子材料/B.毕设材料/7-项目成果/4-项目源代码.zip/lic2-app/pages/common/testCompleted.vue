<template>
	<view style="display: flex;align-items: center;flex-direction: column;height: auto;">
		<NavBar :title="title" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="align-content: center;margin-top: 200rpx;">
			<image src="../../static/ic_completed.png" mode="aspectFit"></image>
			<button class="common-tag" style="padding:10rpx;margin-top: 50rpx;" @click="testCompleted">完成考试</button>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar
	},
	data() {
		return {
			title: '考试完成',
			testId: -1
		};
	},
	onLoad(e) {
		console.log(e.testId);
		this.testId = e.testId;
		uni.hideLoading();
	},
	onBackPress() {
		return true;
	},
	methods: {
		testCompleted() {
			var that = this;
			uni.showLoading({
				title: '加载中...',
				mask: true
			});
			uni.request({
				url: ApiManager.completeTest,
				method: 'POST',
				data: {
					testId: parseInt(this.testId),
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					var errorCode = res.data.errCode;
					var errorMsg = res.data.errMsg;
					var version = res.data.version;
					var content = res.data.content;
					if (errorCode != 1) {
						uni.showToast({
							title: errorMsg,
							icon: 'none'
						});
					} else {
						uni.showToast({
							title: '加载成功',
							mask: true
						});
						setTimeout(function() {
							uni.reLaunch({
								url: './testDetail?pageName=试卷分析&testId='+that.testId
							});
						}, 1000);
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
