<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" title="我做过的" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view class="uni-flex uni-row">
			<button class="viewPage" @click="getTopicList()">题目</button>
			<button class="viewPage" @click="getPaperList()">试卷</button>
		</view>
		<swiper :style="{ height: swiperHeight + 'px' }" class="swiper" circular="true" :current="current" duration="300" @change="onswiperchange">
			<swiper-item item-id="0" style="margin-top: 20rpx;">
				<view class="topic_list_class">
					<view hover-class="uni-list-cell-hover" v-for="(item, index) in topicList" :key="index" @tap="openTopicInfo" :data-newsid="item.topicId">
						<topicItem topicUrl="../../static/ic_topic.png" :topicName="item.topicName" :topicKnowledgePoint="item.knowledgePoint" :topicKeyWord="item.keyWord"></topicItem>
					</view>
				</view>
			</swiper-item>

			<swiper-item item-id="1" style="margin-top: 20rpx;">
				<view class="paper_list_class">
					<view hover-class="uni-list-cell-hover" v-for="(item, index) in paperList" :key="index" @tap="openPaperInfo" :data-newsid="item.id">
						<paperItem paperUrl="../../static/ic_paper.png" :paperName="item.testName" :paperTime="item.date"></paperItem>
					</view>
				</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import topicItem from '../../components/diy/topicItem.vue';
import paperItem from '../../components/diy/paperItem.vue';
export default {
	components: {
		topicItem,
		NavBar,
		paperItem
	},
	data() {
		return {
			topicList: [],
			paperList: [],
			current: 1,
			swiperHeight: 0 //外部的高度
			// swiperHight:500
		};
	},
	onLoad: function() {
		uni.showLoading({
			title: '加载中....'
		});
		uni.request({
			url: ApiManager.getMineDoneTopic,
			method: 'POST',
			data: {
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.topicList = content.topicList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.request({
			url: ApiManager.getMineDoneTest,
			method: 'POST',
			data: {
				studentNumber: getApp().globalData.studentInfo.studentNumber
			},
			success: res => {
				var errorCode = res.data.errorCode;
				var errorMsg = res.data.errorMsg;
				var version = res.data.version;
				var content = res.data.content;
				if (errorCode != 1) {
					uni.showToast({
						title: errorMsg,
						icon: 'none'
					});
				} else {
					this.paperList = content.testList;
				}
			},
			fail: () => {},
			complete: () => {}
		});
		uni.hideLoading();
	},
	onShow: function() {
		this.current = 0;
	},
	watch: {
		topicList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.topic_list_class');
			});
		},
		paperList: function() {
			let _this = this;
			this.$nextTick(function() {
				_this.initSwiperHeight('.paper_list_class');
			});
		}
	},
	methods: {
		initSwiperHeight(list) {
			let _this = this;
			let info = uni.createSelectorQuery().select(list);
			info.boundingClientRect(function(data) {
				if (_this.swiperHeight < data.height + 10) {
					_this.swiperHeight = data.height + 10;
				}
			}).exec();
		},
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		onswiperchange(e) {
			this.current = e.detail.current;
			if (this.current == 0) {
				this.initSwiperHeight('.topic_list_class');
			} else {
				this.initSwiperHeight('.paper_list_class');
			}
		},
		openTopicInfo(e) {
			uni.showToast({
				title: e.currentTarget.dataset.newsid,
				icon: 'none'
			});
			var newsid = e.currentTarget.dataset.newsid;
			this.initSwiperHeight('.topic_list_class');
		},
		openPaperInfo(e) {
			uni.showToast({
				title: e.currentTarget.dataset.newsid,
				icon: 'none'
			});
			var newsid = e.currentTarget.dataset.newsid;
			this.initSwiperHeight('.paper_list_class');
		},
		getTopicList() {
			uni.showToast({
				title: '题目',
				icon: 'none'
			});
			//请求接口:获取做过的题目列表
			this.current = 0;
		},
		getPaperList() {
			uni.showToast({
				title: '试卷',
				icon: 'none'
			});
			//请求接口:获取做过的试卷列表
			this.current = 1;
		}
	}
};
</script>

<style>
.viewPage {
	flex: 1;
	font-size: 28rpx;
	padding: 10rpx;
	background-color: #ffffff;
	border-radius: 0;
}
.swiper {
	display: flex;
}
</style>
