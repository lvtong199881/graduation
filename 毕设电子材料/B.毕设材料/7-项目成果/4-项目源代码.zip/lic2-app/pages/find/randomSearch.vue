<template>
	<view class="common-content-auto">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<view style="margin-top: 20rpx;"></view>
		<view v-if="needFresh" v-for="(item, index) in topicList" :key="index" @tap="openinfo" :data-newsid="item.topicId">
			<topicItem
				:topicId="item.topicId"
				:topicName="item.topicName"
				:topicKnowledgePoint="item.knowledgePoint"
				showCollect
				@collect="tryCollect(index)"
				@uncollect="tryUnCollect(index)"
			></topicItem>
		</view>
	</view>
</template>

<script>
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
import uniIcons from '../../components/uni-icons/uni-icons.vue';
import topicItem from '../../components/diy/topicItem.vue';
export default {
	components: {
		NavBar,
		uniIcons,
		topicItem
	},
	data() {
		return {
			title: '随机出题',
			topicList: [],
			needFresh: true
		};
	},
	onLoad: function(e) {
		this.refresh();
	},
	onPullDownRefresh() {
		this.refresh();
		setTimeout(function() {
			uni.stopPullDownRefresh();
		}, 1000);
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		},
		openinfo(e) {
			var topicId = e.currentTarget.dataset.newsid;
			console.log(topicId);
			uni.navigateTo({
				url: '../common/topicDetail?topicId=' + topicId,
				success: res => {},
				fail: () => {},
				complete: () => {}
			});
		},
		refresh() {
			var that = this;
			uni.showLoading({
				title: '加载中...',
				mask: false
			});
			uni.request({
				url: ApiManager.getRandomTopic,
				method: 'POST',
				data: {
					studentNumber: parseInt(getApp().globalData.studentInfo.studentNumber)
				},
				success: res => {
					if (res.statusCode != 200) {
						uni.showToast({
							title: res.statusCode + ':' + res.errMsg,
							icon: 'none'
						});
					} else {
						var errorCode = res.data.errCode;
						var errorMsg = res.data.errMsg;
						var version = res.data.version;
						var content = res.data.content;
						if (errorCode != 1) {
							uni.showToast({
								title: errorMsg,
								icon: 'none'
							});
						} else {
							uni.showToast({
								title: '加载成功',
								mask: true
							});
							that.needFresh = false;
							that.topicList = content;
							setTimeout(function() {
								that.needFresh = true;
							}, 500);
						}
					}
				},
				fail: () => {
					uni.showToast({
						title: '加载失败',
						icon: 'none'
					});
				},
				complete: () => {}
			});
		}
	}
};
</script>

<style></style>
