<template>
	<view class="common-content">
		<NavBar left-icon="arrowleft" :title="title" @clickLeft="back()" background-color="#DD4037" color="#ffffff" status-bar="true"></NavBar>
		<WritingArea></WritingArea>
		<!-- 	<wa2 visible="true"></wa2> -->
	</view>
</template>

<script>
import wa2 from '../../components/diy/wa2.vue';
import WritingArea from '../../components/diy/writingArea';
import ApiManager from '../../common/api.js';
import NavBar from '../../components/uni-nav-bar/uni-nav-bar.vue';
export default {
	components: {
		NavBar,
		WritingArea,
		wa2
	},
	data() {
		return {
			title: '测试'
		};
	},
	methods: {
		back() {
			uni.navigateBack({
				delta: 1
			});
		}
	}
};
</script>

<style></style>
